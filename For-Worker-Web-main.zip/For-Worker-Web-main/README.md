# For-Worker-Web
"For Worker" Web that allows workers to get known fast and easily by getting rated by people who got their service
Our goal for this project to provide various things for our customers 
* Avoiding scams and have fully informations about the prices range.
* Providing for our customers a high quality workers and jobs.
* Providing servers for our customers in less time and with less money.

———————————————————————
* this is the URL for the website : 

# http://www.forwroker.byethost5.com/
