import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import WorkerDataService from "../services/worker.service";
import { ImLocation } from 'react-icons/im';

const styles = {
    container: {
        width: '500px',
        margin: '50px auto',
        textAlign: 'center',
        padding: '40px',
        backgroundColor: '#f9f9f9',
        borderRadius: '8px',
    },
    header: {
        marginBottom: '20px',
        fontSize: '24px',
        color: '#333',
    },
    formGroup: {
        marginBottom: '20px',
        textAlign: 'left'
    },
    label: {
        display: 'block',
        marginBottom: '10px',
        fontSize: '14px',
        color: '#333',
    },
    input: {
        width: '100%',
        padding: '10px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        marginBottom: '10px',
    },
    textArea: {
        width: '100%',
        padding: '10px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        marginBottom: '10px',
        resize: 'none',
        fontSize: '14px'
    },
    checkboxList: {
        maxHeight: '200px',
        overflowY: 'scroll',
        border: '1px solid #ddd',
        borderRadius: '4px',
        padding: '10px',
    },
    checkboxItem: {
        marginBottom: '10px',
    },
    checkboxLabel: {
        marginLeft: '10px',
    },
    button: {
        width: '100%',
        padding: '10px',
        backgroundColor: '#fbbd14',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '14px',
        color: '#000',
        marginTop: '20px',
    },
    errorMessage: {
        color: 'red',
        marginTop: '20px',
        fontSize: '14px',
    },
};

const CompleteProfile = () => {
    const [profileData, setProfileData] = useState({
        profilePicture: null,
        workPictures: [],
        selectedJobs: [],
        selectedLocations: [],
        description: '',
        rate: 0,
    });

    const [jobs, setJobs] = useState([]);
    const [jobSearch, setJobSearch] = useState('');
    const [locations, setLocations] = useState([]);
    const [locationSearch, setLocationSearch] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [specificLocation, setSpecificLocation] = useState('');


    const navigate = useNavigate();

    // Fetch jobs and locations from the backend
    useEffect(() => {
        const fetchData = async () => {
            try {
                const [jobsResponse, locationsResponse] = await Promise.all([
                    axios.get(`${process.env.REACT_APP_API_URL}:8080/api/jobs`),
                    axios.get(`${process.env.REACT_APP_API_URL}:8080/api/locations`)
                ]);

                setJobs(jobsResponse.data);
                setLocations(locationsResponse.data);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        if (name === 'profilePicture') {
            setProfileData({ ...profileData, profilePicture: files[0] });
        } else if (name === 'workPictures') {
            setProfileData({ ...profileData, workPictures: Array.from(files) });
        } else if (name === 'rate') {
            setProfileData({ ...profileData, rate: value });
        } else if (name === 'description') {
            setProfileData({ ...profileData, description: value });
        }
    };

    const handleCheckboxChange = (e, type) => {
        const value = e.target.value;
        let selectedItems;
        if (type === 'jobs') {
            setProfileData({ ...profileData, selectedJobs: [value] });
        } else if (type === 'locations') {
            selectedItems = [...profileData.selectedLocations];
            if (selectedItems.includes(value)) {
                selectedItems = selectedItems.filter(item => item !== value);
            } else {
                selectedItems.push(value);
            }
            setProfileData({ ...profileData, selectedLocations: selectedItems });
        }
    };

    // Function to upload images to S3
    const uploadImageToS3 = async (file) => {
        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await axios.post(`${process.env.REACT_APP_API_URL}:8080/uploads3`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            return response.data.fileUrl; // Return the S3 URL
        } catch (error) {
            console.error('Error uploading file to S3:', error);
            throw error;
        }
    };
    const [schedule, setSchedule] = useState([
        { day: 'Sunday', selected: false, start: '', end: '' },
        { day: 'Monday', selected: false, start: '', end: '' },
        { day: 'Tuesday', selected: false, start: '', end: '' },
        { day: 'Wednesday', selected: false, start: '', end: '' },
        { day: 'Thursday', selected: false, start: '', end: '' },
        { day: 'Friday', selected: false, start: '', end: '' },
        { day: 'Saturday', selected: false, start: '', end: '' }
    ]);

    const toggleDay = (day) => {
        const updatedSchedule = schedule.map(s =>
            s.day === day ? { ...s, selected: !s.selected } : s
        );
        setSchedule(updatedSchedule);
    };
    
    const handleHoursChange = (day, type, value) => {
        const updatedSchedule = schedule.map(s =>
            s.day === day ? { ...s, [type]: value } : s
        );
        setSchedule(updatedSchedule);
    };
    

    

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage(''); // Clear any previous error message

        if (profileData.selectedJobs.length === 0) {
            setErrorMessage('Please select at least one job.');
            return;
        }

        if (profileData.selectedLocations.length === 0) {
            setErrorMessage('Please select at least one location.');
            return;
        }

        const workerPhoneNumber = localStorage.getItem('workerPhoneNumber'); // Get the stored phone number

        try {
            // Upload profile picture to S3
            let profilePictureUrl = '';
            if (profileData.profilePicture) {
                profilePictureUrl = await uploadImageToS3(profileData.profilePicture);
            }

            // Upload work pictures to S3
            const workPicturesUrls = [];
            for (const file of profileData.workPictures) {
                const url = await uploadImageToS3(file);
                workPicturesUrls.push(url);
            }

            // Prepare the data to send
            const profileDataToSend = {
                workerPhoneNumber,
                profilePicture: profilePictureUrl, // S3 URL
                workPictures: workPicturesUrls, // S3 URLs
                jobs: profileData.selectedJobs,
                locations: profileData.selectedLocations,
                description: profileData.description,
                rate: profileData.rate,
                specificLocation:specificLocation,
                schedule: schedule.filter(s => s.selected).map(s => ({ day: s.day, time: `${s.start} to ${s.end}` })),

            };

            // Submit the profile data to the backend
            await WorkerDataService.completeProfile(profileDataToSend);
            navigate('/LoginForm'); // Redirect to a dashboard or appropriate page
        } catch (error) {
            console.error('Error submitting profile:', error);
            setErrorMessage('An error occurred while completing your profile.');
        }
    };

    // Dynamic filtering logic for jobs and locations
    const filteredJobs = jobSearch
        ? jobs.filter(job =>
            job.name.toLowerCase().includes(jobSearch.toLowerCase())
        )
        : jobs; // If search input is empty, display all jobs

    const filteredLocations = locationSearch
        ? locations.filter(location =>
            location.name.toLowerCase().includes(locationSearch.toLowerCase())
        )
        : locations; // If search input is empty, display all locations

    return (
        <div style={styles.container}>
            <h2 style={styles.header}>Complete Your Profile</h2>
            <form onSubmit={handleSubmit}>
                <div style={styles.formGroup}>
                    <label style={styles.label}>Profile Picture</label>
                    <input
                        type="file"
                        name="profilePicture"
                        accept="image/*"
                        onChange={handleChange}
                        style={styles.input}
                    />
                </div>
                <div style={styles.formGroup}>
                    <label style={styles.label}>Work Pictures</label>
                    <input
                        type="file"
                        name="workPictures"
                        accept="image/*"
                        multiple
                        onChange={handleChange}
                        style={styles.input}
                    />
                </div>
                <div style={styles.formGroup}>
                    <label style={styles.label}>
                        <ImLocation style={{ marginRight: '5px', verticalAlign: 'middle' }} />
                        Specific Location (Optional, Special for Business Owners)
                    </label>
                    <input type="text" name="specificLocation" placeholder="Enter a specific location..."  value={specificLocation} onChange={(e) => setSpecificLocation(e.target.value)} style={styles.input}/>
                </div>
                <div style={styles.formGroup}>
                    <label style={styles.label}>Jobs (Select one)</label>
                    <input
                        type="text"
                        name="jobSearch"
                        placeholder="Search jobs..."
                        value={jobSearch}
                        onChange={(e) => setJobSearch(e.target.value)}
                        style={styles.input}
                    />
                    <div style={styles.checkboxList}>
                        {filteredJobs.map(job => (
                            <div key={job.id} style={styles.checkboxItem}>
                                <input
                                    type="checkbox"
                                    name="jobSelection" // Add a name property for radio buttons
                                    value={job.name}
                                    checked={profileData.selectedJobs.includes(job.name)}
                                    onChange={(e) => handleCheckboxChange(e, 'jobs')}
                                />
                                <label style={styles.checkboxLabel}>{job.name}</label>
                            </div>
                        ))}
                    </div>
                </div>
                <div style={styles.formGroup}>
                    <label style={styles.label}>Locations (Select multiple)</label>
                    <input
                        type="text"
                        name="locationSearch"
                        placeholder="Search locations..."
                        value={locationSearch}
                        onChange={(e) => setLocationSearch(e.target.value)}
                        style={styles.input}
                    />
                    <div style={styles.checkboxList}>
                        {filteredLocations.map(location => (
                            <div key={location.id} style={styles.checkboxItem}>
                                <input
                                    type="checkbox"
                                    value={location.name}
                                    checked={profileData.selectedLocations.includes(location.name)}
                                    onChange={(e) => handleCheckboxChange(e, 'locations')}
                                />
                                <label style={styles.checkboxLabel}>{location.name}</label>
                            </div>
                        ))}
                    </div>
                </div>
                <div style={styles.formGroup}>
                    <label style={styles.label}>Work Schedule</label>
                    {schedule.map((s) => (

                        <div key={s.day}>
                            <input
                                type="checkbox"
                                checked={s.selected}
                                onChange={() => toggleDay(s.day)}
                                style={styles.checkbox}
                            />
                            <label style={{ marginRight: '10px' }}>{s.day}</label>
                            {s.selected && (
                                <>
                                    <input
                                        type="time"
                                        value={s.start}
                                        onChange={(e) => handleHoursChange(s.day, 'start', e.target.value)}
                                        style={styles.input}
                                    />
                                    to
                                    <input
                                        type="time"
                                        value={s.end}
                                        onChange={(e) => handleHoursChange(s.day, 'end', e.target.value)}
                                        style={styles.input}
                                    />
                                </>
                            )}
                        </div>
                    ))}
                </div>
                <div style={styles.formGroup}>
                    <label style={styles.label}>Description</label>
                    <textarea
                        name="description"
                        rows="4"
                        placeholder="Tell us about yourself..."
                        value={profileData.description}
                        onChange={handleChange}
                        style={styles.textArea}
                    />
                </div>
                {errorMessage && <div style={styles.errorMessage}>{errorMessage}</div>}
                <button type="submit" style={styles.button}>Complete Profile</button>
            </form>
        </div>
    );
};

export default CompleteProfile;

