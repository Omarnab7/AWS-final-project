import React, { useState } from 'react';
import { Box, TextField, Button, Typography, Link } from '@mui/material';

const VerifyPage = () => {
    const [code, setCode] = useState(Array(6).fill(''));

    const handleChange = (e, index) => {
        const value = e.target.value;
        if (value.length <= 1 && /^[0-9]*$/.test(value)) {
            const newCode = [...code];
            newCode[index] = value;
            setCode(newCode);
            // Move to the next input field if any
            if (value && index < code.length - 1) {
                document.getElementById(`code-${index + 1}`).focus();
            }
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const codeStr = code.join('');
        console.log('Verification Code:', codeStr);
        // Send the verification code to the server
    };

    return (
        <Box
            component="form"
            onSubmit={handleSubmit}
            sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: '100vh',
                backgroundColor: '#eceaff',
                p: 3
            }}
        >
            <Box
                sx={{
                    backgroundColor: 'white',
                    borderRadius: 2,
                    boxShadow: 1,
                    p: 3,
                    textAlign: 'center'
                }}
            >
                <Typography variant="h4" gutterBottom>
                    Verify
                </Typography>
                <Typography variant="body1" gutterBottom>
                    Your code was sent to you via Phone
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                    {code.map((digit, index) => (
                        <TextField
                            key={index}
                            id={`code-${index}`}
                            value={digit}
                            onChange={(e) => handleChange(e, index)}
                            variant="outlined"
                            inputProps={{
                                maxLength: 1,
                                style: { textAlign: 'center' }
                            }}
                            sx={{ mx: 1, width: '50px' }}
                        />
                    ))}
                </Box>
                <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    sx={{ backgroundColor: '#009E9E', '&:hover': { backgroundColor: '#007373' } }}
                >
                    Verify
                </Button>
                <Typography variant="body2" sx={{ mt: 2 }}>
                    Didn't receive code? <Link href="#" onClick={(e) => e.preventDefault()}>Request again</Link>
                </Typography>
            </Box>
        </Box>
    );
};

export default VerifyPage;
