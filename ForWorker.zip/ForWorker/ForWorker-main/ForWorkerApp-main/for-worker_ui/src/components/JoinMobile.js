import React from 'react';
import { MdOutlineReviews } from "react-icons/md";
import { FaLocationArrow } from "react-icons/fa6";
import { CiLogin } from "react-icons/ci";



import appleMobileIcon from './assets/apple-mobile.png';
import androidMobileIcon from './assets/android-mobile.png';
import android from './assets/android.png';

import QRCode from './assets/QRCode.png'

import QR from './assets/QR.png';
const JoinMobile = () => {
    return (
        <div style={styles.container}>
            <div style={styles.qrCode}>
                <img src={QRCode} alt="QR Code" style={styles.qrImage} />
            </div>
            <h1 style={styles.heading}>Heading out? Bring ForWorker with you.</h1>
            <p style={styles.subheading}>Scan the QR code to get started</p>
            <p style={styles.description}>
               <strong>The free ForWorker mobile app is the fastest and easiest way to search for Worker near you.</strong>
            </p>
            <div style={styles.features}>

                <div style={{...styles.featureItem , marginRight:'100px'}}>
                    <MdOutlineReviews style={styles.icon} />
                    <p>Write & read reviews</p>
                </div>

                <div style={{...styles.featureItem,marginRight:'20px'}}>
                    <CiLogin style={styles.icon} />
                    <p>Log-in</p>
                </div>

                <div style={{...styles.featureItem, marginLeft:'100px'}}>
                    <FaLocationArrow style={styles.icon} />
                    <p>Browse nearby</p>
                </div>
            </div>
            <div style={styles.appStore}>

                <img src={appleMobileIcon}  alt="App Store" style={styles.storeLogo} />
                <img src={android} alt="Google Play" style={styles.storeLogo} />
            </div>
        </div>
    );
};

const styles = {
    container: {
        textAlign: 'center',
        padding: '20px',
        fontFamily: 'Arial, sans-serif',
        backgroundColor: '#ffffff',
    },
    qrCode: {
        marginBottom: '20px',
    },
    qrImage: {
        width: '150px',
        height: '150px',
        border: '4px solid #f05454',
    },
    heading: {
        fontSize: '24px',
        margin: '10px 0',
        fontWeight: 'bold',
    },
    subheading: {
        fontSize: '16px',
        color: '#555',
    },
    description: {
        fontSize: '16px',
        color: '#555',
        marginBottom: '20px',
    },
    features: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center',
        marginTop: '20px',
    },
    featureItem: {
        margin: '10px',
        textAlign: 'center',
    },
    icon: {
        width: '50px',
        height: '50px',
        marginBottom: '10px',
    },
    appStore: {
        marginTop: '20px',
    },
    storeLogo: {
        width: '120px',
        margin: '10px',
    },
};

export default JoinMobile;
