import React from 'react';

const Cars = () => {
    return (
        <div>
            <h1>Cars</h1>
            <p>Information and resources about cars.</p>
        </div>
    );
};

export default Cars;