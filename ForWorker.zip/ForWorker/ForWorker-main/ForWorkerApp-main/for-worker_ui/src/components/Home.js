import React from 'react';
import Header from './Header';
import './Categories.css';
import { Link } from 'react-router-dom';

const CategoryCard = ({ title, description, image, link }) => (
    <Link to={link} className="category-card">
        <img src={image} alt={title} className="category-image" />
        <h3>{title}</h3>
        <p>{description}</p>
    </Link>
);

const Home = () => {
    const categories = [
        { title: 'Cars', description: 'Information and resources about cars.', image: require('./assets/Cars.jpg'),link: '/cars' },
        { title: 'Cleaning', description: 'Find cleaning options and tips.', image: require('./assets/Cleaning.jpg') },
        { title: 'Construction', description: 'Construction tips and resources.', image: require('./assets/Constructions.webp') },
        { title: 'Garden', description: 'Everything about gardening.', image: require('./assets/Garden.jpg') },
        { title: 'Home', description: 'Home improvement and maintenance.', image: require('./assets/Home.jpg') },
        { title: 'Sport', description: 'Home improvement and maintenance.', image: require('./assets/Sport.png') },
        { title: 'Weddings', description: 'Home improvement and maintenance.', image: require('./assets/Weddings.webp') },
        { title: 'Education', description: 'Finde Proffesional Teachers.', image: require('./assets/Education.jpeg') },
        { title: 'Tech', description: 'Latest technology and gadgets.', image: require('./assets/Tech.jpg') }
    ];

    return (
        <>
            <Header categories={categories.map(category => category.title)} />
            <div className="categories-container">
                {categories.map((category) => (
                    <CategoryCard
                        key={category.title}
                        title={category.title}
                        description={category.description}
                        image={category.image}
                        link={category.link}

                    />
                ))}
            </div>
        </>
    );
};

export default Home;
