import React from 'react';

const Layout = ({ children }) => {
    return (
        <div style={{
            display: 'flex',
            flexDirection: 'column',
            minHeight: '100vh'
        }}>
            <header style={{
                background: 'black',
                color: 'aliceblue',
                position: 'relative',
                textAlign: 'center',
                margin: 0,
                padding: 0
            }}>
                <a href="" style={{ textDecoration: 'none' }}>
                    <h1 style={{
                        fontSize: 'x-large',
                        fontWeight: 'bold',
                        left: '-50px',
                        bottom: '6px',
                        color: 'white',
                        margin: 0,
                        padding: 0
                    }}>For Worker.</h1>
                </a>
            </header>

            <main style={{
                backgroundColor: '#eceaff',
                flex: '1',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <div className="container">
                    {children}
                </div>
            </main>

            <footer style={{
                background: '#1a1a1a',
                width: '100%',
                padding: '10px 10%',
                position: 'relative',// relative to keep it where is it and not to go when scrollup or down
                bottom: 0,
                display: 'flex',
                justifyContent: 'space-evenly',
                alignItems: 'center'
            }}>
                <li><a href="./AboutUs" style={{ color: 'burlywood' }}>About</a></li>
                <li className="footer-item"><a className="aFooter" style={{ color: 'burlywood' }}><span>&copy; 2024</span></a></li>
                <li><a href="./contact-us" style={{ color: 'burlywood' }}>Contact</a></li>
            </footer>
        </div>
    );
};

export default Layout;
