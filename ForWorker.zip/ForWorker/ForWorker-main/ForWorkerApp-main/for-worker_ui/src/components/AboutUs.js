// src/OriginStory.js
import React from 'react';
import styled from 'styled-components';

const AboutContainer = styled.div`
    font-family: Arial, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
`;

const AboutHeader = styled.header`
    margin-bottom: 20px;
    text-align: center;
`;

const HeaderImage = styled.img`
    width: 100%;
    height: auto;
`;

const MainContent = styled.main`
    line-height: 1.6;
    margin: 0 auto;
    padding: 20px;
    text-align: left;
`;

const Title = styled.h1`
    margin-left: 300px;
    margin-bottom: 20px;
    font-weight: bold;
`;

const SectionTitle = styled.h2`
    margin-top: 20px;
`;

const List = styled.ul`
    margin-left: 20px;
`;

const AboutUs = () => {
    return (
        <AboutContainer>
            {/*<AboutHeader>
                {<HeaderImage src="/path-to-image.jpg" alt="Logo of the website" />}
                <h1>FOR<strong>WORKER.</strong></h1>
            </AboutHeader>*/}
            <MainContent>
                <Title>About Us</Title>
                <p>Welcome to FOR<strong>WORKER.</strong></p>
                <p>At FOR<strong>WORKER.</strong>, our mission is to create a central hub for workers across various industries. We recognized the need for a platform where workers can connect, share experiences, and enhance their professional growth. Our goal is to provide a comprehensive space where both experienced and new workers can come together.</p>
                
                <SectionTitle>Our Vision</SectionTitle>
                <p>We envision a community where workers are not only easily discoverable but also have the opportunity to build their professional reputation.</p>
                
                <SectionTitle>What We Offer</SectionTitle>
                <List>
                    <li><strong>Centralized Platform:</strong> Our website brings together workers from different fields in one convenient location, making it easier for employers to find the right talent and for workers to connect with opportunities.</li>
                    <li><strong>Enhanced Visibility:</strong> For newcomers to the workforce, our platform provides a valuable opportunity to showcase their skills and get noticed by potential employers.</li>
                    <li><strong>Safe and Transparent Job Market:</strong> Workers can rate their experiences and provide feedback on job opportunities, creating a transparent environment where everyone can make informed decisions.</li>
                </List>
                <p>Join us at   <a href="/SignUpForm" style={{ color: '#fbbd14', fontWeight: 'bold', textDecoration: 'none' }}>
    SignUp FOR<strong>WORKER.</strong>
  </a> and be part of a growing community.</p>
                <p>Thank you for being a part of our journey!</p>
                <p>Sincerely,<br />The FOR<strong>WORKER.</strong> Team</p>
            </MainContent>
        </AboutContainer>
    );
};

export default AboutUs;
