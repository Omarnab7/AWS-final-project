import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));

function Main() {
    const [users, setUsers] = useState([
        { id: 1, firstName: 'John', lastName: 'Doe', email: 'john@example.com', coin: 10, allergic_to: 'fish', religion_id: '1', have_history: 'yes' },
        { id: 2, firstName: 'Jane', lastName: 'Smith', email: 'jane@example.com', coin: 15, allergic_to: 'none', religion_id: '2', have_history: 'no' },
    ]);

    const [editUserId, setEditUserId] = useState(null);
    const [editCoin, setEditCoin] = useState('');
    const [searchQuery, setSearchQuery] = useState('');

    const handleDelete = (id) => {
        setUsers(users.filter(user => user.id !== id));
    };

    const handleCoinClick = (id, coin) => {
        setEditUserId(id);
        setEditCoin(coin);
    };

    const handleSaveCoin = () => {
        setUsers(users.map(user =>
            user.id === editUserId ? { ...user, coin: editCoin } : user
        ));
        setEditUserId(null);
        setEditCoin('');
    };

    const handleCoinChange = (e) => {
        setEditCoin(Number(e.target.value));
    };

    const handleCoinBlur = () => {
        handleSaveCoin();
    };

    const handleCoinKeyDown = (e) => {
        if (e.key === 'Enter') {
            handleSaveCoin();
        }
    };

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const filteredUsers = users.filter(user =>
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div style={{ backgroundColor: 'lightblue', minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: '80px' }}>
            <h1 style={{ position: 'fixed', top: '0', width: '100%', backgroundColor: 'lightblue', textAlign: 'center', padding: '10px 0', margin: '0' }}>User Management</h1>
            <hr style={{ width: '80%', border: '1px solid black', margin: '20px 0' }} />
            <Box sx={{ width: '80%', margin: '0 auto', marginBottom: '20px' }}>
                <TextField
                    fullWidth
                    variant="outlined"
                    label="Search by Email"
                    value={searchQuery}
                    onChange={handleSearchChange}
                />
            </Box>
            <TableContainer component={Paper} style={{ width: '80%', margin: '0 auto' }}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>First Name</StyledTableCell>
                            <StyledTableCell>Last Name</StyledTableCell>
                            <StyledTableCell>Allergic To</StyledTableCell>
                            <StyledTableCell>Religion ID</StyledTableCell>
                            <StyledTableCell>Have History</StyledTableCell>
                            <StyledTableCell>Email</StyledTableCell>
                            <StyledTableCell>Coin</StyledTableCell>
                            <StyledTableCell align="center">Actions</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {filteredUsers.map((user) => (
                            <StyledTableRow key={user.id}>
                                <StyledTableCell>{user.firstName}</StyledTableCell>
                                <StyledTableCell>{user.lastName}</StyledTableCell>
                                <StyledTableCell>{user.allergic_to}</StyledTableCell>
                                <StyledTableCell>{user.religion_id}</StyledTableCell>
                                <StyledTableCell>{user.have_history}</StyledTableCell>
                                <StyledTableCell>{user.email}</StyledTableCell>
                                <StyledTableCell>
                                    {editUserId === user.id ? (
                                        <TextField
                                            type="number"
                                            value={editCoin}
                                            onChange={handleCoinChange}
                                            onBlur={handleCoinBlur}
                                            onKeyDown={handleCoinKeyDown}
                                            variant="outlined"
                                            size="small"
                                            autoFocus
                                        />
                                    ) : (
                                        <span onClick={() => handleCoinClick(user.id, user.coin)}>
                                            {user.coin}
                                        </span>
                                    )}
                                </StyledTableCell>
                                <StyledTableCell align="center">
                                    <Button variant="contained" color="error" onClick={() => handleDelete(user.id)}>Delete</Button>
                                </StyledTableCell>
                            </StyledTableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}

export default Main;
