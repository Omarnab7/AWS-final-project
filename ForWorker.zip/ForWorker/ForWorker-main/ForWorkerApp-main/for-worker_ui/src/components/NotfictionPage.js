import React, { useState, useEffect } from 'react';
import {
    Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Checkbox,
    TablePagination, Button, IconButton, Toolbar, Typography, Dialog, DialogActions,
    DialogContent, DialogContentText, DialogTitle
} from '@mui/material';
import {TextField } from "@mui/material";

import RefreshIcon from '@mui/icons-material/Refresh';
import DownloadIcon from '@mui/icons-material/Download';
import moment from 'moment';
import axios from 'axios'; // If you're using axios, otherwise use fetch

function NotfictionPage() {
    const [notifications, setNotifications] = useState([]); // Replace initialUsers with notifications state
    const [selected, setSelected] = useState([]);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [openDialog, setOpenDialog] = useState(false);
    const [currentUserId, setCurrentUserId] = useState(null);

    const [editNotificationId, setEditNotificationId] = useState(null); // ID of the notification being edited
    const [newDate, setNewDate] = useState(""); // New date input
    const [open, setOpen] = useState(false); // Control the modal visibility

    // Fetch notifications from API
    useEffect(() => {
        const fetchNotifications = async () => {
            try {
                const token = localStorage.getItem('token');
 // Retrieve the token from localStorage
                const response = await axios.get('http://localhost:8080/api/notifications', {
                    headers: {
                        Authorization: `Bearer ${token}`, // Include JWT token in the Authorization header
                    },
                });
                response.data.forEach(notification => {

                    // Check for CustomerFirstName within nested objects if necessary
                    const customerFirstName = notification.CustomerFirstName || notification.orderService?.Customer?.CustomerFirstName;
                });
                setNotifications(response.data);


            } catch (error) {
                console.error('Error fetching notifications:', error);
            }
        };

        fetchNotifications(); // Call the fetch function when component mounts
    }, []);

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelecteds = notifications.map((notification) => notification.id);
            setSelected(newSelecteds);
            return;
        }
        setSelected([]);
    };

    const handleSelect = (event, id) => {
        const selectedIndex = selected.indexOf(id);
        let newSelected = [];

        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selected.slice(0, selectedIndex),
                selected.slice(selectedIndex + 1)
            );
        }
        setSelected(newSelected);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleAccept = async (id) => {
        try {
            const token = localStorage.getItem('token');
                const ReviewLinks = await axios.put(`http://localhost:8080/api/notifications/${id}/status`, {}, {
                headers: {
                    Authorization: `Bearer ${token}`, // Include JWT token
                },
            });
            console.log("ReviewLinkReviewLink  ",ReviewLinks.data.reviewLink);

            // Update the state to reflect the change immediately
            setNotifications((prevNotifications) =>
                prevNotifications.map((notification) =>
                    notification.id === id ? { ...notification, status: "1" } : notification
                )
            );
        } catch (error) {
            console.error('Failed to update notification status:', error);
        }
    };

    const handleOpenModal = (id) => {
        setEditNotificationId(id);
        setOpen(true); // Open the modal
    };

    const handleCloseModal = () => {
        setOpen(false); // Close the modal
        setEditNotificationId(null); // Reset editing state
        setNewDate(""); // Clear date input
    };

    const handleEditNotification = async () => {
        try {
            const token = localStorage.getItem("token");
            await axios.put(
                `http://localhost:8080/api/notifications/${editNotificationId}`,
                { date: newDate }, // Send the new date in the request body
                {
                    headers: {
                        Authorization: `Bearer ${token}`, // Include JWT token
                    },
                }
            );

            // Update the state to reflect the change immediately
            setNotifications((prevNotifications) =>
                prevNotifications.map((notification) =>
                    notification.id === editNotificationId ? { ...notification, date: newDate } : notification
                )
            );

            handleCloseModal(); // Close the modal after saving
        } catch (error) {
            console.error("Failed to update notification:", error);
        }
    };

    const handleCancelNotification = (id) => {
        alert(`Notification for user ID ${id} has been canceled.`);
    };

    const handleDone = () => {
        setOpenDialog(false);
        alert('The date has been added to your calendar.');
    };

    const handleCancel = () => {
        setOpenDialog(false);
        alert('Please contact the customer to arrange a suitable date.');
    };

    return (
        <Paper>
            <Toolbar>
                <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                    Notifications
                </Typography>
                <IconButton>
                    <RefreshIcon />
                </IconButton>
                <Button startIcon={<DownloadIcon />}>Export</Button>
            </Toolbar>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell padding="checkbox">
                                <Checkbox
                                    indeterminate={selected.length > 0 && selected.length < notifications.length}
                                    checked={notifications.length > 0 && selected.length === notifications.length}
                                    onChange={handleSelectAllClick}
                                />
                            </TableCell>
                            <TableCell>Id</TableCell>
                            <TableCell>Name</TableCell>
                            <TableCell>Phone Number</TableCell>
                            <TableCell>Service Needed</TableCell>
                            <TableCell>Address</TableCell>
                            <TableCell>Date</TableCell>
                            <TableCell>Notes</TableCell>
                            <TableCell>Sent At</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {notifications.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((notification) => {
                            const isItemSelected = selected.indexOf(notification.id) !== -1;

                            return (
                                <TableRow
                                    key={notification.id}
                                    hover
                                    role="checkbox"
                                    aria-checked={isItemSelected}
                                    tabIndex={-1}
                                    selected={isItemSelected}
                                >
                                    <TableCell padding="checkbox">
                                        <Checkbox
                                            checked={isItemSelected}
                                            onChange={(event) => handleSelect(event, notification.id)}
                                        />
                                    </TableCell>
                                    <TableCell>{notification.id}</TableCell>
                                    <TableCell>{notification.orderService?.Customer?.CustomerFirstName}  {notification.orderService?.Customer?.CustomerLastName} </TableCell>
                                    <TableCell>{notification.customerPhoneNumber}</TableCell>
                                    <TableCell>{notification.orderService?.serviceType}</TableCell>
                                    <TableCell>{notification.address}</TableCell>
                                    <TableCell>{notification.startDate?.substring(0, 10)}</TableCell>
                                    <TableCell>{notification.orderService?.description}</TableCell>
                                    <TableCell>
                                        {notification.SentAt
                                            ? new Date(notification.SentAt).toISOString().replace('T', ' ').split('.')[0]
                                            : ''}
                                    </TableCell>
                                    <TableCell>
                                        {notification.status === "0" ? (
                                            <>
                                                <Button
                                                    variant="contained"
                                                    sx={{ backgroundColor: '#fbbd14', color: 'white', marginRight: 1 }}
                                                    onClick={() => handleAccept(notification.id)}
                                                >
                                                    Accept
                                                </Button>
                                                <Button
                                                    variant="contained"
                                                    sx={{ backgroundColor: 'white', color: 'black', border: '1px solid black' }}
                                                    onClick={() => handleCancelNotification(notification.id)}
                                                >
                                                    Cancel
                                                </Button>
                                                <Button
                                                    variant="contained"
                                                    sx={{
                                                        backgroundColor: "white",
                                                        color: "black",
                                                        border: "1px solid black",
                                                    }}
                                                    onClick={() => handleOpenModal(notification.id)}
                                                >
                                                    Edit
                                                </Button>
                                            </>
                                        ) : (
                                            <Typography variant="body2" color="textSecondary">
                                                Accepted
                                            </Typography>
                                        )}
                                    </TableCell>


                                </TableRow>
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={notifications.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
            <Dialog open={open} onClose={handleCloseModal}>
                <DialogTitle>Edit Notification Date</DialogTitle>
                <DialogContent>
                    <Typography gutterBottom>
                        Edit the date for notification ID: {editNotificationId}
                    </Typography>
                    <TextField
                        label="Enter New Date"
                        type="date"
                        value={newDate}
                        onChange={(e) => setNewDate(e.target.value)}
                        InputLabelProps={{
                            shrink: true, // Ensures the label stays above the input field
                        }}
                        inputProps={{
                            min: new Date().toISOString().split('T')[0], // Only allows selecting today or future dates
                        }}
                        fullWidth
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal} color="secondary">
                        Cancel
                    </Button>
                    <Button
                        onClick={handleEditNotification}
                        variant="contained"
                        color="primary"
                    >
                        Save
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Dialog (Modal) for Done and Cancel buttons */}
            <Dialog open={openDialog} onClose={handleCancel}>
                <DialogTitle>Confirmation</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Is this date appropriate? If not, please call the customer.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleDone} color="primary">
                        Done
                    </Button>
                    <Button onClick={handleCancel} color="secondary">
                        Cancel
                    </Button>
                </DialogActions>
            </Dialog>
        </Paper>
    );
}

export default NotfictionPage;
