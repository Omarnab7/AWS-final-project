import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import CarsImage from './assets/Cars.jpeg';
import CleaningImage from './assets/Cleaning.jpeg';
import ConstructionImage from './assets/Construction.jpeg';
import GardenImage from './assets/Garden.jpeg';
import HomeImage from './assets/House.jpeg';
import SportImage from './assets/Sport.jpeg';
import WeddingImage from './assets/Wedding.jpeg';
import EducationImage from './assets/Education.jpeg';
import Icon1 from './assets/bulding.jpeg';
import Icon2 from './assets/camera.jpeg';
import Icon3 from './assets/clean.jpeg';
import Icon4 from './assets/cook.jpeg';
import Icon5 from './assets/gard.jpeg';

// Styled Components
const PageContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: white;
`;

const Header = styled.h1`
  font-size: 24px;
  margin: 20px 0;
  font-weight: bold;
`;

const SearchContainer = styled.div`
  position: relative;
  display: flex;
  width: 400px;
`;

const SearchInput = styled.input`
  padding: 10px;
  font-size: 16px;
  width: 100%;
  border: 1px solid #ccc;
  border-radius: 4px 0 0 4px;
  z-index: 1;
`;

const SearchButton = styled.button`
  padding: 10px 20px;
  background-color: #ffd700;
  border: none;
  border-radius: 0 4px 4px 0;
  cursor: pointer;
  font-size: 16px;
  z-index: 0;

  &:hover {
    background-color: #ffc700;
  }
`;

const SuggestionList = styled.ul`
  list-style-type: none;
  margin: 0;
  padding: 0;
  max-height: 200px;
  overflow-y: auto;
  border: 1px solid #ccc;
  width: 100%;
  position: absolute;
  background-color: white;
  z-index: 2;
  top: 42px; /* Align with search bar */
`;

const SuggestionItem = styled.li`
  padding: 10px;
  cursor: pointer;
  &:hover {
    background-color: #f0f0f0;
  }
`;

const IconGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr); /* 4 icons per row */
  gap: 40px;
  margin-bottom: 20px;
`;

const IconItem = styled.img`
  width: 60px;
  height: 60px;
  cursor: pointer;
`;

const CategoriesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-top: 20px;
`;

const CategoryCard = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 15px;
  border-radius: 8px;
  width: 120px;
  height: 160px;
  transition: background-color 0.3s ease;
  cursor: pointer;

  &:hover {
    background-color: #ffd700;
  }

  img {
    width: 100%;
    height: auto;
    margin-bottom: 10px;
  }

  p {
    margin: 0;
    font-size: 16px;
  }
`;

const CategoriesForm = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const navigate = useNavigate();

  const categories = [
    { name: 'car', path: '/car', img: CarsImage },
    { name: 'Cleaning', path: '/cleaning', img: CleaningImage },
    { name: 'Construction', path: '/construction', img: ConstructionImage },
    { name: 'garden', path: '/garden', img: GardenImage },
    { name: 'house', path: '/house', img: HomeImage },
    { name: 'Sport', path: '/sport', img: SportImage },
    { name: 'weddings', path: '/weddings', img: WeddingImage },
    { name: 'Education', path: '/education', img: EducationImage },
  ];

  const handleInputChange = (e) => {
    const query = e.target.value;
    setSearchQuery(query);

    if (query.length > 0) {
      const filteredCategories = categories.filter(category =>
        category.name.toLowerCase().includes(query.toLowerCase())
      );
      setSuggestions(filteredCategories);
    } else {
      setSuggestions([]);
    }
  };

  const handleSuggestionClick = (category) => {
    setSearchQuery(category.name);
    setSuggestions([]);
    navigate(`/workers/${category.name.toLowerCase()}`);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && suggestions.length > 0) {
      navigate(suggestions[0].path);
    }
  };

  const handleSearch = () => {
    const foundCategory = categories.find(category =>
      category.name.toLowerCase() === searchQuery.toLowerCase()
    );
    if (foundCategory) {
      navigate(foundCategory.path);
    } else {
      alert('Category not found');
    }
  };

  const handleCategoryClick = (category) => {
    navigate(`/workers/${category.name.toLowerCase()}`);
  };

  return (
    <PageContainer>
      {/* Top Icon Grid */}
      <IconGrid>
        <IconItem src={Icon2} alt="Icon 2" />
        <IconItem src={Icon3} alt="Icon 3" />
        <IconItem src={Icon4} alt="Icon 4" />
        <IconItem src={Icon5} alt="Icon 5" />
      </IconGrid>

      <Header>Connecting You with Trusted Professionals</Header>

      {/* Search Bar with Button */}
      <SearchContainer>
        <SearchInput
          type="text"
          placeholder="Search for a category..."
          value={searchQuery}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
        />
        <SearchButton onClick={handleSearch}>Search</SearchButton>

        {/* Render suggestions as a dropdown */}
        {suggestions.length > 0 && (
          <SuggestionList>
            {suggestions.map((category, index) => (
              <SuggestionItem
                key={index}
                onClick={() => handleSuggestionClick(category)}
              >
                {category.name}
              </SuggestionItem>
            ))}
          </SuggestionList>
        )}
      </SearchContainer>

      {/* Default Category Grid */}
      <CategoriesGrid>
        {categories.map((category) => (
          <CategoryCard key={category.name} onClick={() => handleCategoryClick(category)}>
            <img src={category.img} alt={category.name} />
            <p>{category.name}</p>
          </CategoryCard>
        ))}
      </CategoriesGrid>
    </PageContainer>
  );
};

export default CategoriesForm;
