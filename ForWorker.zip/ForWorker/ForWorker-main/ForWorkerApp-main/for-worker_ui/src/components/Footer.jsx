

function Footer() {
  return (
    <footer className="footer">
      <ul className="footer-list">
        <li className="footer-item"><a className="aFooter" href="/AboutUs">About</a></li>
          <li className="footer-item"><a className="aFooter" href="/ContactUs">Contact</a></li>
      </ul>
    </footer>
  );
};

export default Footer;