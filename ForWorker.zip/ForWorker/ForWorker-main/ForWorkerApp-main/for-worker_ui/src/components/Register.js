import React, { useState, useEffect } from 'react';
import { EyeInvisibleOutlined, EyeOutlined } from "@ant-design/icons";
import {Link, useNavigate} from 'react-router-dom';
import WorkerDataService from "../services/worker.service";
import bcrypt from 'bcryptjs';

function Register() {
    const [inputFields, setInputFields] = useState({
        firstName: '', lastName: '', phoneNumber: '', email: '', password: '', confirmpass: ''
    });
    const [visible, setVisible] = useState(false);
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);
    const navigate = useNavigate();

    const handleChange = (e) => {
        setInputFields({...inputFields, [e.target.name]: e.target.value});
    };

    const handleNameChange = (e) => {
        const value = e.target.value.replace(/[^A-Za-z]/ig, '');
        setInputFields({...inputFields, [e.target.name]: value});
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setErrors({});
        const validationErrors = validateValues(inputFields);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length === 0) {
            const hashedPassword = hashPassword(inputFields.password);
            const dataToSubmit = {...inputFields, password: hashedPassword};

            try {
                await WorkerDataService.create(dataToSubmit);
                console.log('Registration successful');
                navigate("/Login");
            } catch (error) {
                console.error('Error registering:', error.response?.data?.error || error.message);
            }

            setSubmitting(true);
        }
    };

    const validateValues = (inputValues) => {
        let errors = {};
        if (inputValues.firstName.trim().length === 0) {
            errors.firstName = "First name is required";
        }
        if (inputValues.lastName.trim().length === 0) {
            errors.lastName = "Last name is required";
        }
        if (!/^\d{10}$/.test(inputValues.phoneNumber)) {
            errors.phoneNumber = "Phone number must be 10 digits";
        }
        if (!/\S+@\S+\.\S+/.test(inputValues.email)) {
            errors.email = "Email address is invalid";
        }
        if (inputValues.password.length < 6) {
            errors.password = "Password must be at least 6 characters";
        }
        if (inputValues.password !== inputValues.confirmpass) {
            errors.confirmpass = "Passwords do not match";
        }
        return errors;
    };

    const hashPassword = (password) => {
        const saltRounds = 10;
        return bcrypt.hashSync(password, saltRounds);
    };

    useEffect(() => {
        if (Object.keys(errors).length === 0 && submitting) {
            setSubmitting(false);
        }
    }, [errors]);

    useEffect(() => {
        document.title = 'Register';
    }, []);

    return (
        <div>
            <div className="row">
                <div className="col-12 col-sm-8 col-md-6 col-lg-4 offset-sm-2 offset-md-3 offset-lg-4">
                    <h1 className="mb-3 text-center" style={{color: 'black',marginTop:'15px'}}>Create a new account.</h1>
                    <p className="lead" style={{color: 'black', marginTop:'15px' }}>Welcome to For Worker Website.</p>
                    <form onSubmit={handleSubmit}>
                        <div className="row">
                            <div className="form-group col-12 col-sm-6">
                                <label htmlFor="firstName" style={{color: 'black'}}>First name:</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="First name"
                                    name="firstName"
                                    value={inputFields.firstName}
                                    onChange={handleNameChange}
                                    required
                                />
                                {errors.firstName && <div className="text-danger">{errors.firstName}</div>}
                            </div>
                            <div className="form-group col-12 col-sm-6">
                                <label htmlFor="lastName" style={{color: 'black'}}>Last name:</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Last name"
                                    name="lastName"
                                    value={inputFields.lastName}
                                    onChange={handleNameChange}
                                    required
                                />
                                {errors.lastName && <div className="text-danger">{errors.lastName}</div>}
                            </div>
                        </div>
                        <div className="form-group">
                            <label htmlFor="phoneNumber" style={{color: 'black'}}>Phone:</label>
                            <input
                                type="tel"
                                className="form-control"
                                placeholder="05********"
                                name="phoneNumber"
                                value={inputFields.phoneNumber}
                                onChange={handleChange}
                                required
                            />
                            {errors.phoneNumber && <div className="text-danger">{errors.phoneNumber}</div>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="email" style={{color: 'black'}}>Email:</label>
                            <input
                                type="email"
                                className="form-control"
                                placeholder="example@example.com"
                                name="email"
                                value={inputFields.email}
                                onChange={handleChange}
                                required
                            />
                            {errors.email && <div className="text-danger">{errors.email}</div>}
                        </div>
                        <div className="form-group position-relative">
                            <label htmlFor="password" style={{color: 'black'}}>Password:</label>
                            <div
                                className="eye-icon position-absolute"
                                onClick={() => setVisible(!visible)}
                                style={{cursor: 'pointer', right: '10px', top: '50%', transform: 'translateY(10%)'}}
                            >
                                {visible ? <EyeOutlined/> : <EyeInvisibleOutlined/>}
                            </div>
                            <input
                                type={visible ? 'text' : 'password'}
                                className="form-control pl-4"
                                placeholder="Enter Password"
                                value={inputFields.password}
                                onChange={handleChange}
                                name="password"
                                required
                            />
                            {errors.password && <div className="text-danger">{errors.password}</div>}
                        </div>
                        <div className="form-group position-relative">
                            <label htmlFor="confirmpass" style={{color: 'black'}}>Confirm Password:</label>
                            <div
                                className="eye-icon position-absolute"
                                onClick={() => setVisible(!visible)}
                                style={{cursor: 'pointer', right: '10px', top: '50%', transform: 'translateY(10%)'}}
                            >
                                {visible ? <EyeOutlined/> : <EyeInvisibleOutlined/>}
                            </div>
                            <input
                                type={visible ? 'text' : 'password'}
                                className="form-control pl-4"
                                placeholder="Enter Password"
                                value={inputFields.confirmpass}
                                onChange={handleChange}
                                name="confirmpass"
                                required
                            />
                            {errors.confirmpass && <div className="text-danger">{errors.confirmpass}</div>}
                        </div>
                        <button type="submit" className="btn btn-primary btn-block mb-3"
                                style={{backgroundColor: 'rgb(179, 131, 10)'}}>
                            Create account
                        </button>
                        <div className="alert alert-info small" role="alert">
                            By clicking above you agree to our
                            <a href="#" className="alert-link">Terms &amp; Conditions</a> and
                            our <a href="#" className="alert-link">Privacy Policy</a>.
                        </div>
                        <div className="text-center">
                            <p style={{color: 'black'}}>or</p>
                            <Link to="/Login" className="btn btn-success"
                                  style={{backgroundColor: 'rgb(0, 158, 158)', marginBottom: '15px'}}>Login</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Register;
