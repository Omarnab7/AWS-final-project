import React, { useContext, useState, useRef, useEffect } from 'react';
import { AuthContext } from '../context/AuthContext'; // Import AuthContext
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import {Bell} from 'react-bootstrap-icons';
import LogoBrowser from './assets/BrowserLogo.png';



const CreditsOverlay = styled.div`
    position: relative;
    z-index: 2; /* Ensures text appears above the background */
`;

const HeaderContainer = styled.header`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px 20px;
  border-bottom: 1px solid #e0e0e0;
  background-color: #fff;
`;

const TopRow = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const Logo = styled.div`
  h1 {
    font-size: 24px;
    margin: 0;
    font-weight: normal;
    cursor: pointer;
    display: flex;
    align-items: center;

    .bold {
      font-weight: bold;
      margin-left: 5px;
    }
  }
`;

const AuthLinks = styled.div`
  display: flex;
  align-items: center;
  white-space: nowrap;

  a {
    margin-left: 15px;
    text-decoration: none;
    color: #000;
    transition: color 0.3s ease;

    &:hover {
      color: #FFD700;
    }
  }
`;

const ProfileContainer = styled.div`
  display: flex;
  align-items: center;
  position: relative;
  cursor: pointer;
`;

const ProfileImage = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-left: 15px;
`;

const DropdownMenu = styled.div`
  position: absolute;
  top: 50px;
  right: 0;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  display: ${(props) => (props.show ? 'block' : 'none')};
  min-width: 150px;
  z-index: 10;
`;

const DropdownItem = styled.div`
  padding: 10px;
  cursor: pointer;
  &:hover {
    background-color: #f0f0f0;
  }
`;

const Credits = styled.div`
  font-size: 14px;
  color: #555;
`;

const Nav = styled.nav`
  width: 100%;
  margin-top: 10px;
  border-top: 1px solid #e0e0e0;
  border-bottom: 1px solid #e0e0e0;
  padding: 10px 0;
`;

const NavLinks = styled.ul`
  display: flex;
  list-style: none;
  margin: 0;
  padding: 0;
  justify-content: center;
  white-space: nowrap;
`;

const NavItem = styled.li`
  margin: 0 15px;
  cursor: pointer;
  transition: color 0.3s ease;

  &:hover {
    color: #FFD700;
  }
`;
const StyledBell = styled(Bell)`
  transform: translateX(200px);
  transition: transform 0.3s ease; /* Optional: for smooth movement */
`;
const NotificationBadge = styled.span`
  transform: translateX(200px);
  position: absolute;
  top: -5px;
  right: -5px;
  width: 10px;
  height: 10px;
  background-color: red;
  border-radius: 50%;
  z-index: 1;
`;

const NotificationContainer = styled.div`
  position: absolute;
  top: 40px;
  left: 100px;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  width: 250px;
  z-index: 100;
`;

const NotificationItem = styled.div`
  padding: 10px;
  background-color: ${(props) => (props.isOdd ? '#f0f0f0' : '#fff')};
  border-bottom: 1px solid #ddd;
  cursor: pointer;
  &:hover {
    background-color: #e0e0e0;
  }
`;

const ShowMoreButton = styled.div`
  padding: 10px;
  text-align: center;
  background-color: #fff;
  cursor: pointer;
  border-top: 1px solid #ddd;
  &:hover {
    background-color: #f0f0f0;
  }
`;

const categories = [
  { name: 'Cars', path: '/car' },
  { name: 'Cleaning', path: '/cleaning' },
  { name: 'Construction', path: '/construction' },
  { name: 'Garden', path: '/garden' },
  { name: 'House', path: '/house' },
  { name: 'Sport', path: '/sport' },
  { name: 'Wedding', path: '/weddings' },
  { name: 'Education', path: '/education' },
];


const NewHeader = () => {
  const { isLoggedIn, setIsLoggedIn } = useContext(AuthContext); // Use the context
  const [showDropdown, setShowDropdown] = useState(false);
  const [notification, setNotification] = useState(true); // This state determines if there is a notification
  const [showNotifications, setShowNotifications] = useState(false); // Dropdown toggle state for notifications
  const [notifications] = useState([
    'Notification 1',
    'Notification 2',
    'Notification 3',
    'Notification 4',
    'Notification 5',
    'Notification 6',
    'Notification 7',
  ]); // Sample notifications

  const slug = localStorage.getItem("slug"); // Retrieve the slug from localStorage
  const profilePicture = localStorage.getItem("ProfilePicture");
  const notificationRef = useRef(null);
  const profileRef = useRef(null);



  useEffect(() => {
    const handleClickOutside = (event) => {
        // Close notification dropdown if clicked outside
        if (notificationRef.current && !notificationRef.current.contains(event.target)) {
            setShowNotifications(false); // Close the notification dropdown
        }
        
        // Close profile dropdown if clicked outside
        if (profileRef.current && !profileRef.current.contains(event.target)) {
            setShowDropdown(false); // Close the profile dropdown
        }
    };

    // Add event listener to listen for clicks on the document
    document.addEventListener('mousedown', handleClickOutside);

    // Cleanup the event listener when the component unmounts
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
}, [setShowNotifications, setShowDropdown]);


  const navigate = useNavigate();

  const handleProfileClick = () => {
    setShowDropdown(!showDropdown);
  };
  const handleBellClick = () => {
    navigate('/NotfictionPage');
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsLoggedIn(false); // Update the context state
    navigate('/LoginForm');
  };

  const handleShowMore = () => {
    navigate('/NotfictionPage');
  };
  return (
      <HeaderContainer>
        <TopRow>
          <Logo>
            <a href="/" style={{ textDecoration: 'none', color: 'inherit' }}>
              <h1>FOR<span className="bold">WORKER.</span></h1>
            </a>
          </Logo>
          <Credits> This website was created by Tarik Bakir & Mohammad Massalha & Samer Egniem {new Date().getFullYear()} &copy;</Credits>
          {!isLoggedIn ? (
              <AuthLinks>
                <a href="/loginform">Log In</a>
                <a>|</a>
                <a href="/signupform">Sign Up</a>
              </AuthLinks>
          ) : (
              <>
                <div style={{ position: 'relative' }} ref={notificationRef}> {/* Apply ref here */}
                  <StyledBell onClick={handleBellClick} />
                  {notification && <NotificationBadge />} {/* Conditionally render the red ball */}
                  {showNotifications && (
                      <NotificationContainer>
                        {notifications.slice(0, 5).map((notification, index) => (
                            <NotificationItem key={index} isOdd={index % 2 !== 0}>
                              {notification}
                            </NotificationItem>
                        ))}
                        <ShowMoreButton onClick={handleShowMore}>Show More</ShowMoreButton>
                      </NotificationContainer>
                  )}
                </div>
                <ProfileContainer ref={profileRef} onClick={handleProfileClick}>
                  <ProfileImage src={LogoBrowser} alt="Profile" />
                  <DropdownMenu show={showDropdown}>
                    <DropdownItem onClick={() => navigate(`/ProfileForm/${slug}`)}>View Profile</DropdownItem>
                    <DropdownItem onClick={() => navigate('/EditProfileForm')}>Edit Profile</DropdownItem>
                    <DropdownItem onClick={handleLogout}>Log Out</DropdownItem>
                  </DropdownMenu>
                </ProfileContainer>

              </>
          )}
        </TopRow>
        <Nav>
          <NavLinks>
            {categories.map((category, index) => (
                <NavItem key={index} onClick={() => navigate("workers" + category.path)}>
                  {category.name}
                </NavItem>
            ))}
          </NavLinks>
        </Nav>
      </HeaderContainer>
  );
};

export default NewHeader;
