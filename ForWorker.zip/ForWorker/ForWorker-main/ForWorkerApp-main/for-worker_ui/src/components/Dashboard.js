import React, { useEffect, useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import profileImage from './assets/LORELLE.jpeg'; // Default profile image

// Styled Components
const ProfileContainer = styled.div`
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffffff;
  font-family: Arial, sans-serif;
`;

const Header = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  padding-bottom: 20px;
  border-bottom: 1px solid #ddd;
`;

const ProfileImage = styled.img`
  width: 250px;
  height: 250px;
  border-radius: 10px;
  object-fit: cover;
`;

const InfoSection = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  padding-left: 20px;
`;

const ProfileName = styled.h2`
  margin: 0;
  font-size: 36px;
  font-weight: bold;
`;

const ProfileLocation = styled.p`
  color: gray;
  margin-top: 5px;
`;

const RankSection = styled.div`
  display: flex;
  align-items: center;
  margin-top: 10px;
`;

const StarRating = styled.div`
  margin-left: 10px;
`;

const MainContent = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
`;

const LeftColumn = styled.div`
  width: 30%;
`;

const RightColumn = styled.div`
  width: 65%;
`;

const TabContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  margin-top: 20px;
  border-bottom: 1px solid #ddd;
`;

const TabButton = styled.button`
  background: none;
  border: 1px solid #ddd;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 16px;
  color: ${props => props.active ? '#fbbd14' : '#333'};
  border-bottom: ${props => props.active ? '3px solid #fbbd14' : '1px solid #ddd'};
  background-color: ${props => props.active ? '#fff' : '#f9f9f9'};
  margin-right: -1px;

  &:hover {
    color: #fbbd14;
  }
`;

const ContentContainer = styled.div`
  padding: 20px 0;
`;

const Section = styled.div`
  margin-bottom: 30px;
  display: flex;
  align-items: center;

  h3 {
    font-size: 12px;
    color: #333;
    margin: 20px;
    flex-shrink: 0;
    margin-left: 0px;
  }

  &::after {
    content: '';
    flex-grow: 1;
    height: 1px;
    background-color: #ddd;
    margin-left: 10px;
  }

  p, li {
    font-size: 18px;
    color: #333;
    margin: 8px 0;
  }

  ul {
    padding-left: 20px;
    list-style-type: none;
  }

  li {
    font-weight: bold;
  }
`;

const TimelineSection = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  grid-template-rows: repeat(3, auto);
  gap: 10px;

  img {
    width: 100%;
    height: auto;
    object-fit: cover;
    border-radius: 5px;
  }

  img:nth-child(1) {
    grid-column: span 2;
    grid-row: span 2;
  }

  img:nth-child(2) {
    grid-column: 3;
    grid-row: 1 / span 2;
  }

  img:nth-child(3) {
    grid-column: 1;
    grid-row: 3;
  }

  img:nth-child(4) {
    grid-column: 2;
    grid-row: 3;
  }

  img:nth-child(5) {
    grid-column: 3;
    grid-row: 3;
  }

  img:nth-child(6) {
    grid-column: span 3;
    grid-row: 4;
  }
`;

const ContactInfo = styled.div`
  margin-top: 20px;

  h3 {
    margin-bottom: 30px;
  }

  p {
    margin: 5px 0;
    margin-bottom: 30px;
  }
`;

// Dashboard Component
const Dashboard = () => {
  const [workerData, setWorkerData] = useState({
    descrition: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    email: '',
    rate: '', // Added rating field
    location: '', // Added location field
    address: '',  // Added address field
    site: '',     // Added site field
    profilePicture: '' // For profile image if available
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('Timeline');

  useEffect(() => {
    const token = localStorage.getItem('token');

    axios.get('http://localhost:8080/api/dashboard', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => {
        console.log(response.data);
        setWorkerData(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Failed to load dashboard:', error);
        setError('Failed to load dashboard');
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <ProfileContainer>
      <Header>
        <ProfileImage 
          src={workerData.profilePicture || profileImage} 
          alt="Profile" 
        />
        <InfoSection>
          <ProfileName>{workerData.firstName} {workerData.lastName}</ProfileName>
          <ProfileLocation>{workerData.location || 'Location not available'}</ProfileLocation>
          <RankSection>
            <span>Rankings: {workerData.rate}</span>
            <StarRating>⭐⭐⭐⭐☆</StarRating>
          </RankSection>
        </InfoSection>
      </Header>

      <MainContent>
        <LeftColumn>
          <Section>
            <h3>Informations</h3>
          </Section>
          <strong style={{ display: 'block', marginBottom: '10px', fontSize: '26px' }}>
            {workerData.firstName} {workerData.lastName}
          </strong>
          <p style={{ fontSize: '12px' }}>
            {workerData.description}
          </p>
          <Section>
            <h3>Skills</h3>
          </Section>
          <ul>
            <li>Organization and Time Management</li>
            <li>Creativity</li>
            <li>Negotiation Skills</li>
          </ul>
        </LeftColumn>

        <RightColumn>
          <TabContainer>
            <TabButton active={activeTab === 'Timeline'} onClick={() => setActiveTab('Timeline')}>Timeline</TabButton>
            <TabButton active={activeTab === 'About'} onClick={() => setActiveTab('About')}>About</TabButton>
            <TabButton active={activeTab === 'Reviews'} onClick={() => setActiveTab('Reviews')}>Reviews</TabButton>
          </TabContainer>

          <ContentContainer>
            {activeTab === 'Timeline' && (
              <TimelineSection>
                <img src="https://via.placeholder.com/400x400" alt="Event 1" />
                <img src="https://via.placeholder.com/150x460" alt="Event 2" />
                <img src="https://via.placeholder.com/400x200" alt="Event 3" />
                <img src="https://via.placeholder.com/150x150" alt="Event 4" />
                <img src="https://via.placeholder.com/150x150" alt="Event 5" />
              </TimelineSection>
            )}

            {activeTab === 'About' && (
              <ContactInfo>
                <h3>Contact Information</h3>
                <p><strong>Phone:</strong> {workerData.phoneNumber || 'No phone number available'}</p>
                <p><strong>Address:</strong> {workerData.address || 'No address available'}</p>
                <p><strong>Email:</strong> {workerData.email || 'No email available'}</p>
                <p><strong>Site:</strong> {workerData.site || 'No website available'}</p>
              </ContactInfo>
            )}

            {activeTab === 'Reviews' && (
              <div>Reviews Content</div>
            )}
          </ContentContainer>
        </RightColumn>
      </MainContent>
    </ProfileContainer>
  );
};

export default Dashboard;
