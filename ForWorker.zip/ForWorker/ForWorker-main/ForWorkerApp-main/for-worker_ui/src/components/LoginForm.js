import React, { useContext, useState, useEffect } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import WorkerDataService from '../services/worker.service';
import { AuthContext } from '../context/AuthContext';
import Cookies from 'js-cookie';
import '@fortawesome/fontawesome-free/css/all.min.css';

const FormContainer = styled.div`
  width: 400px;
  margin: 100px auto;
  text-align: center;
`;

const Header = styled.h2`
  font-size: 24px;
  color: #333;
  margin-bottom: 30px;
`;

const Input = styled.input`
  width: 90%;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
`;

const Button = styled.button`
  width: 100%;
  padding: 15px;
  background-color: ${(props) => (props.primary ? '#fbbd14' : '#fff')};
  color: ${(props) => (props.primary ? '#000' : '#333')};
  border: ${(props) => (props.primary ? 'none' : '1px solid #ddd')};
  border-radius: 5px;
  font-size: 16px;
  margin-top: 10px;
  cursor: pointer;

  &:hover {
    background-color: ${(props) => (props.primary ? '#eab607' : '#f7f7f7')};
  }
`;

const CheckboxContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  font-size: 14px;
`;

const ToggleButton = styled.button`
  position: absolute;
  right: 10px;
  top: 60%;
  transform: translateY(-50%);
  background: none;
  border: none;
  cursor: pointer;
  font-size: 18px;
  color: #000000;
`;

const PasswordContainer = styled.div`
  position: relative;
  padding-top: 10px;
  margin-bottom: 20px;
`;

const ForgotPasswordLink = styled.a`
  color: #007bff;
  text-decoration: none;
  font-size: 14px;

  &:hover {
    text-decoration: underline;
  }
`;

const LoginForm = () => {
  const { setIsLoggedIn } = useContext(AuthContext);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);

  // Load phone number from a persistent cookie and password if "Remember Me" was previously checked
  useEffect(() => {
    const savedPhoneNumber = Cookies.get('phoneNumber');
    const savedPassword = Cookies.get('password');
    if (savedPhoneNumber) setPhoneNumber(savedPhoneNumber);
    if (savedPassword) setPassword(savedPassword);
  }, []);

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleLogin = async () => {
    setSuccessMessage('');
    setErrorMessage('');

    try {
      const response = await WorkerDataService.login({ phoneNumber, password });
      const { token, slug } = response.data;

      localStorage.setItem('token', token);

      // Save phone number persistently
      Cookies.set('phoneNumber', phoneNumber);

      // Save password in cookie for 30 days if "Remember Me" is checked
      if (rememberMe) {
        Cookies.set('password', password, { expires: 30 });
      } else {
        Cookies.remove('password'); // Remove password cookie if "Remember Me" is unchecked
      }

      setIsLoggedIn(true);
      setSuccessMessage('Login successful! Redirecting...');
      setTimeout(() => navigate(`/ProfileForm/${slug}`), 1500);
    } catch (error) {
      setErrorMessage('Login failed: ' + (error.response?.data?.message || 'An error occurred'));
    }
  };

  const handleSignUp = () => {
    navigate('/signupform');
  };

  const toggleRememberMe = () => {
    setRememberMe(!rememberMe);
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleLogin();
    }
  };

  return (
      <FormContainer>
        <Header>Access to the Best Workers, All in One Place</Header>
        <Input
            type="tel"
            placeholder="Phone Number"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            onKeyPress={handleKeyPress}
        />

        <PasswordContainer>
          <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={handleKeyPress}
          />
          <ToggleButton type="button" onClick={toggleShowPassword}>
            <i className={showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'}></i>
          </ToggleButton>
        </PasswordContainer>

        {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
        {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
        <CheckboxContainer>
          <label>
            <input
                type="checkbox"
                checked={rememberMe}
                onChange={toggleRememberMe}
            /> Remember for 30 days
          </label>
          <ForgotPasswordLink href="./ForgotPasswordForm">Forgot Password?</ForgotPasswordLink>
        </CheckboxContainer>
        <Button primary onClick={handleLogin}>Log In</Button>
        <Button onClick={handleSignUp}>Sign Up</Button>
      </FormContainer>
  );
};

export default LoginForm;
