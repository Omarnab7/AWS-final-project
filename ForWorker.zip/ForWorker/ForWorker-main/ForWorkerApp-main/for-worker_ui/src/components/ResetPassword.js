import React, { useEffect, useState } from 'react';
import WorkerDataService from "../services/worker.service";
import { useNavigate } from 'react-router-dom';

const ResetPassword = () => {
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [resetMessage, setResetMessage] = useState('');
    const navigate = useNavigate();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (name === 'password') {
            setPassword(value);
        } else if (name === 'confirmPassword') {
            setConfirmPassword(value);
        }
    };

    const handleResetPassword = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
            setResetMessage('Passwords do not match');
            return;
        }
        try {
            // Replace with actual reset password logic
            const response = await WorkerDataService.resetPassword(password);
            if (response.data) {
                setResetMessage('Password reset successful!');
                // Additional reset password logic can be added here
            } else {
                setResetMessage('Error resetting password. Please try again.');
            }
        } catch (error) {
            console.error('Error resetting password:', error);
            setResetMessage('Error resetting password. Please try again.');
        }
    };

    useEffect(() => {
        document.title = 'Reset Password';
    }, []);

    return (
        <div>
            <h1 className="mb-3 text-center" style={{ color: '#1a1a1a' }}>Reset Password</h1>
            <form action="/submit" className="mb-3" onSubmit={handleResetPassword} method="post" style={{ maxWidth: '400px', margin: 'auto' }}>
                <div className="form-group">
                    <label htmlFor="Password" style={{ color: '#1a1a1a', display: 'block', marginBottom: '0.5rem' }}>
                        Password <span style={{ color: 'red' }}>*</span>
                    </label>
                    <input
                        type="password"
                        className="form-control"
                        placeholder="Enter new password"
                        name="password"
                        id="Password"
                        value={password}
                        onChange={handleInputChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', boxSizing: 'border-box' }}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="ConfirmPassword" style={{ color: '#1a1a1a', display: 'block', marginBottom: '0.5rem' }}>
                        Confirm Password <span style={{ color: 'red' }}>*</span>
                    </label>
                    <input
                        type="password"
                        className="form-control"
                        placeholder="Confirm new password"
                        name="confirmPassword"
                        id="ConfirmPassword"
                        value={confirmPassword}
                        onChange={handleInputChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', boxSizing: 'border-box' }}
                    />
                </div>
                <button type="submit" className="btn btn-primary btn-block" style={{ backgroundColor: 'rgb(0, 158, 158)', width: '100%', padding: '0.75rem' }}>Reset</button>
                {resetMessage && <p style={{ color: 'red', marginTop: '1rem' }}>{resetMessage}</p>}
            </form>
        </div>
    );
};

export default ResetPassword;