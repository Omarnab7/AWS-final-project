import React from "react";
import styled from "styled-components";

const ContactContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: '#eceaff';
`;

const ContactForm = styled.div`
  display: flex;
  background-color: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
`;

const LeftSection = styled.div`
  background-color: #f3f3f3;
  width: 40%;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const IconEnvelope = styled.div`
  width: 120px;
  height: 120px;
  background-color: #7e57c2; /* Original purple color for the icon */
  border-radius: 10px;
  position: relative;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    width: 60px;
    height: 40px;
    background-color: white;
    border-radius: 2px 2px 0 0;
    transform: rotate(45deg);
  }
`;

const RightSection = styled.div`
  padding: 40px;
  width: 60%;
`;

const Title = styled.h2`
  margin-bottom: 20px;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Input = styled.input`
  margin-bottom: 15px;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
  width: 100%; /* Full width */
`;

const Textarea = styled.textarea`
  resize: none;
  height: 100px;
  margin-bottom: 15px;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
  width: 100%; /* Full width */
`;

const Button = styled.button`
  padding: 10px 20px;
  font-size: 16px;
  color: white;
  background-color: rgb(179, 131, 10); /* Button color */
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: rgb(150, 110, 8); /* Slightly darker on hover */
  }
`;

function ContactUs() {
    return (
        <ContactContainer>
            <ContactForm>
                <LeftSection>
                    <IconEnvelope />
                </LeftSection>
                <RightSection>
                    <Title>Get in touch</Title>
                    <Form>
                        <Input type="text" placeholder="Name" />
                        <Input type="email" placeholder="Email" />
                        <Textarea placeholder="Message" />
                        <Button type="submit">Send</Button>
                    </Form>
                </RightSection>
            </ContactForm>
        </ContactContainer>
    );
}

export default ContactUs;
