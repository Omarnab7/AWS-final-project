import React, { useEffect, useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useParams } from 'react-router-dom'; // <-- Import useParams
import profileImage from './assets/LORELLE.jpeg'; // Default profile image
import WorkerDataService from "../services/worker.service";
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { FaWaze } from "react-icons/fa";
import AWS from '../Config/awsConfig.js'; // Import AWS configuration
import Modal from './Modal';
import { FaPlus } from 'react-icons/fa';

const sns = new AWS.SNS();
const localizer = momentLocalizer(moment);


// Styled Components
const ProfileContainer = styled.div`
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffffff;
  font-family: Arial, sans-serif;
`;

const Header = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  padding-bottom: 20px;
  border-bottom: 1px solid #ddd;
`;

const ProfileImage = styled.img`
  width: 250px;
  height: 250px;
  border-radius: 10px;
  object-fit: cover;
`;

const InfoSection = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  padding-left: 20px;
`;

const WazeLink = styled.a`
  display: flex;
  align-items: center;
  margin-top: 10px;
  color: #1a73e8;
  text-decoration: none;
`;

const WazeIcon = styled(FaWaze)`
  font-size: 24px;
  margin-right: 5px;
`;

const ProfileName = styled.h2`
  margin: 0;
  font-size: 36px;
  font-weight: bold;
`;

const ProfileLocation = styled.p`
  color: gray;
  margin-top: 5px;
`;

const RankSection = styled.div`
  display: flex;
  align-items: center;
  margin-top: 10px;
`;

const StarRating = styled.div`
  margin-left: 10px;
`;

const MainContent = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
`;

const LeftColumn = styled.div`
  width: 30%;
`;

const RightColumn = styled.div`
  width: 65%;
`;

const TabContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  margin-top: 20px;
  border-bottom: 1px solid #ddd;
`;

const TabButton = styled.button`
  background: none;
  border: 1px solid #ddd;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 16px;
  color: ${props => props.active ? '#fbbd14' : '#333'};
  border-bottom: ${props => props.active ? '3px solid #fbbd14' : '1px solid #ddd'};
  background-color: ${props => props.active ? '#fff' : '#f9f9f9'};
  margin-right: -1px;

  &:hover {
    color: #fbbd14;
  }
    // Add margin left for 'Req' tab specifically
  margin-left: ${props => props.children === 'Request a Service' ? '300px' : '0'};

  &:hover {
    color: #fbbd14;
  }
`;

const ContentContainer = styled.div`
  padding: 20px 0;
`;

const Section = styled.div`
  margin-bottom: 30px;
  display: flex;
  align-items: center;

  h3 {
    font-size: 12px;
    color: #333;
    margin: 20px;
    flex-shrink: 0;
    margin-left: 0px;
  }

  &::after {
    content: '';
    flex-grow: 1;
    height: 1px;
    background-color: #ddd;
    margin-left: 10px;
  }

  p, li {
    font-size: 18px;
    color: #333;
    margin: 8px 0;
  }

  ul {
    padding-left: 20px;
    list-style-type: none;
  }

  li {
    font-weight: bold;
  }
`;

const TimelineSection = styled.div`
   display: flex;
  flex-wrap: wrap;
  gap: 10px;
  img {
    width: 150px;
    height: 150px;
    object-fit: cover;
  }
`;

const ContactInfo = styled.div`
  margin-top: 20px;

  h3 {
    margin-bottom: 30px;
  }

  p {
    margin: 5px 0;
    margin-bottom: 30px;
  }
`;
const StyledLabel = styled.label`
  display: block;
  margin-bottom: 5px;
  color: #333;
  font-weight: bold;
`;

const StyledInput = styled.input`
  width: 50%;
  padding: 8px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
`;

const StyledTextArea = styled.textarea`
  width: 50%;
  height: 120px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-bottom: 15px;
`;
const StyledButton = styled.button`
  padding: 10px 20px;
  background-color: #fbbd14; 
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background-color: #45a049;
  }
`;

const StyledSelect = styled.select`
  width: 52%;
  padding: 8px 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: white;
  font-size: 16px;
  color: #333;
  cursor: pointer;

  &:hover {
    border-color: #fbbd14;
  }

  &:focus {
    border-color: #fbbd14;
    outline: none;
  }
`;

const SelectWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const Label = styled.label`
  margin-bottom: 8px;
  font-size: 16px;
  color: #333;
  font-weight: bold;
`;

const AddImageButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #fff;
  border: 2px solid #333;
  border-radius: 5px; /* פחות עיגול בפינות */
  padding: 5px 10px; /* ריווח מתואם */
  cursor: pointer;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);

  &:hover {
    background-color: #e2e2e2;
  }
`;

const AddImageText = styled.span`
  margin-left: 8px; /* ריווח בין הסמל לטקסט */
  font-size: 16px;
  color: #666;
`;

// כאשר אתה משתמש ב-AddImageButton ו-AddImageText כפי שהוגדרו כאן, הם ייווצרו כרכיב אחד עם מראה מלבני




const VerifyButton = styled.button`
  background-color: #fbbd14; 
  color: white;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background-color: #45a049;
  }
`;

const WorkingHoursSection = styled.div`
  margin-top: 20px;

  h3 {
    font-size: 24px;
    margin-bottom: 10px;
  }

  ul {
    list-style: none;
    padding: 0;
  }

  li {
    font-size: 18px;
    display: flex;
    flex-direction: column; // Stack vertically
    align-items: flex-start; // Align items to the start of the flex container
    margin-bottom: 10px; // Space between each day block
  }
`;

const EventForm = ({ selectedEvent, onSave, onClose }) => {
  const [title, setTitle] = useState(selectedEvent?.title || '');
  const [date, setDate] = useState(selectedEvent?.start ? moment(selectedEvent.start).format('YYYY-MM-DD') : '');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const startDateTime = new Date(`${date}T${startTime}`);
    const endDateTime = new Date(`${date}T${endTime}`);
    onSave({ ...selectedEvent, title, start: startDateTime, end: endDateTime });
  };

  

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>Title:</label>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
        
        <label>Date:</label>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />

        <label>Start Time:</label>
        <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} required />

        <label>End Time:</label>
        <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} required />

        <button type="submit">Save</button>
        <button type="button" onClick={onClose}>Cancel</button>
      </form>
    </div>
  );
}

const ImageModal = ({ isOpen, images, currentIndex, onClose, onNext, onPrev }) => {
  if (!isOpen || !images || images.length === 0) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <img src={images[currentIndex]} alt={`Image ${currentIndex + 1}`} style={{ width: '100%', maxHeight: '80vh' }} />
      <button onClick={onPrev} disabled={currentIndex === 0}>Previous</button>
      <button onClick={onNext} disabled={currentIndex === images.length - 1}>Next</button>
    </Modal>
  );
};


// Profile Component
const ProfileForm = () => {
  const { slug } = useParams();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [enteredOTP, setEnteredOTP] = useState('');
  useEffect(() => {
    const fetchedSlug = slug;
    localStorage.setItem("slug", fetchedSlug); // Save the slug in localStorage
  }, []);
  /*const [ReviewData,setReviewData] = useState({
    description:'',
    reliability:'',
    availability:'',
    professionality:'',
  });*/
  const [ReviewData, setReviewData] = useState([]); // Initialize as an array
  const [averageRank, setAverageRank] = useState(0); // State for overall average rank
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);




  const [workerData, setWorkerData] = useState({
    descrition: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    email: '',
    rate: '',
    locations: [],
    address: '',
    jobs: [],
    profilePicture: '',
    images: [],
    specificLocation:[],
    workingHours:[],
    isOpen:'',

  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('Timeline');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [requestFormData, setRequestFormData] = useState({
    slug:slug,
    firstName: '',
    lastName: '',
    phoneNumber: '',
    requestType: '',
    requestDate: '',
    requestDetails: ''
  });

  const [events, setEvents] = useState([]); // Hold calendar events
  const [showEventForm, setShowEventForm] = useState(false); // For form visibility
  const [selectedEvent, setSelectedEvent] = useState(null); // Selected event for edit

  const handleAddEvent = (slotInfo) => {
    setShowEventForm(true);
    setSelectedEvent({
      start: slotInfo.start,
      end: slotInfo.end,
      title: ''
    });
  };

  // Function to handle editing an existing event
  const handleEditEvent = (event) => {
    setShowEventForm(true);
    setSelectedEvent(event);
  };

  // Function to handle deleting an event
  const handleDeleteEvent = (eventId) => {
    setEvents(events.filter(event => event.id !== eventId));
  };

  // Function to save or update an event
  const handleSaveEvent = (newEvent) => {
    setEvents((prevEvents) => {
      if (selectedEvent && selectedEvent.id) {
        return prevEvents.map(event => 
          event.id === selectedEvent.id ? newEvent : event
        );
      } else {
        return [...prevEvents, { ...newEvent, id: Date.now() }];
      }
    });
    setShowEventForm(false);
  };

  // Function to close the event form
  const handleCloseEventForm = () => {
    setShowEventForm(false);
    setSelectedEvent(null);
  };

  const handleSelectDay = ({ start }) => {
    const eventsOnDay = events.filter(event => 
      moment(event.start).isSame(moment(start), 'day')
    );
  
    setSelectedDayEvents(eventsOnDay);
  };
  

  const EventDetailsTable = ({ events }) => {
    return (
      <div style={{ margin: '20px 0' }}>
        {events.map((event, index) => (
          <div key={index} style={{ padding: '10px', borderBottom: '1px solid #ccc' }}>
            <p><strong>Customer Name:</strong> {event.customerName}</p>
            <p><strong>Phone Number:</strong> {event.phoneNumber}</p>
            <p><strong>Service:</strong> {event.serviceType}</p>
            <p><strong>Description:</strong> {event.description}</p>
            <p><strong>Date:</strong> {event.start.toLocaleDateString()}</p>
          </div>
        ))}
      </div>
    );
  };

  const dayPropGetter = (date) => {
    const hasEvent = events.some(event =>
      moment(event.start).isSame(date, 'day')
    );
  
    return {
      style: {
        backgroundColor: hasEvent ? '#FFD700' : 'white', // Yellow if events, white if none
        color: hasEvent ? 'black' : 'gray',
        fontWeight: hasEvent ? 'bold' : 'normal',
        border: hasEvent ? '2px solid #FF4500' : '1px solid #ddd',
      }
    };
  };
  
  const eventPropGetter = (event) => {
    return {
      style: {
        backgroundColor: event.color || 'blue', // Default to blue if no color specified
        color: 'white',
        border: '1px solid black',
      }
    };
  };
  
  
  
  
  
  

  const [selectedDayEvents, setSelectedDayEvents] = useState([]);

const handleSelectEvent = (event) => {
  // נאסוף את כל האירועים לאותו יום
  const eventsOnSameDay = events.filter(e => 
    e.start.toDateString() === event.start.toDateString()
  );
  setSelectedDayEvents(eventsOnSameDay);
};


  
  
  

  const getDateFromHumanReadableMonth = (year, month, day) => {
    return new Date(year, month - 1, day); // Adjust month by subtracting 1
  };
  
  

  // Define the renderStars function
  const renderStars = (rate) => {
    const convertedRate = rate; // Convert 10-point rating to 5-star scale
    const fullStars = Math.floor(convertedRate); // Number of full stars
    const hasHalfStar = convertedRate % 1 !== 0; // Check if there's a half star
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0); // Remaining empty stars

    const stars = [];

    // Push full stars (⭐)
    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={i}>⭐</span>); // Full star (⭐)
    }

    // Push half star (if needed) (⯨)
    if (hasHalfStar) {
      stars.push(<span key={fullStars}>⭐</span>); // You can replace this with a custom half-star symbol if needed
    }

    // Push empty stars (☆)
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={fullStars + i + 1}>☆</span>); // Empty star (☆)
    }

    return stars;
  };

const handleFormSubmit = async (e) => {
  e.preventDefault();

  // Generate a 6-digit OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  setGeneratedOTP(otp);

  // Send OTP to user's phone number
  const customerPhoneNumber = requestFormData.phoneNumber.startsWith('0')
    ? `+972${requestFormData.phoneNumber.slice(1)}`
    : requestFormData.phoneNumber;
  const message = `Your verification code is: ${otp}`;
  console.log(`Message to be sent to ${customerPhoneNumber}:\n${message}`)
  /*const params = {
    Message: message,
    PhoneNumber: customerPhoneNumber,
  };*/

  try {
    //await sns.publish(params).promise();
    setIsModalOpen(true); // Open the verification modal
  } catch (error) {
    console.error('Error sending OTP:', error);
    alert('Failed to send verification code. Please try again.');
  }
};

const handleOTPSubmit = async () => {
  if (enteredOTP === generatedOTP) {
    console.log("OTP Verified Successfully!");
    setIsModalOpen(false);
    console.log("requestFormData",requestFormData);
    try {
      const response = await WorkerDataService.submitRequest({
        requestFormData,
        customerPhoneNumber: requestFormData.phoneNumber, // Customer's phone number
        workerPhoneNumber: workerData.phoneNumber // Worker’s phone number from profile data

      });
      if (response.data.message) {
        alert('Request submitted successfully');
        // Clear form fields after successful submission
        setRequestFormData({
          slug: slug,
          firstName: '',
          lastName: '',
          phoneNumber: '',
          requestType: '',
          requestDate: '',
          requestDetails: ''
        });
      }
        const workerPhoneNumber = workerData.phoneNumber.startsWith('0')
          ? `+972${workerData.phoneNumber.slice(1)}`
          : workerData.phoneNumber;
    
        const message = `Service Request Alert:\nUser Name: ${requestFormData.firstName} ${requestFormData.lastName}\nPhone Number: ${requestFormData.phoneNumber}\nRequest Type: ${requestFormData.requestType}\nRequest Date: ${requestFormData.requestDate}\nRequest Description: ${requestFormData.requestDetails}\nSign in to your profile to accept/deny service.`;
    
        console.log(`Message to be sent to ${workerPhoneNumber}:\n${message}`);
        //The next lines are only used when we want to send SMS!!
        /*const params = {
          Message: message,
          PhoneNumber: workerPhoneNumber,
        };
    
        await sns.publish(params).promise();
        alert('Request submitted and SMS sent successfully!');*/
      
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred while submitting the request.');
    }}else{
      // If OTP doesn't match, show an alert
      alert('Invalid OTP. Please try again.');
    }
};

const handleCancel = () => {
  setIsModalOpen(false);
  // Optionally, reset form or perform other cleanup actions
};


  const [isPublicProfile, setIsPublicProfile] = useState(false);

useEffect(() => {
  const token = localStorage.getItem('token');
  setIsAuthenticated(!!token); // setting the authentication state

  // Check if the profile is public
  const isPublic = window.location.pathname.includes('publicProfile');
  setIsPublicProfile(isPublic); // Update state with the profile type

  const endpoint = isPublic
      ? `${process.env.REACT_APP_API_URL}:8080/api/publicProfile/${slug}`
      : `${process.env.REACT_APP_API_URL}:8080/api/Profile/${slug}`;

  const headers = token && !isPublic ? { Authorization: `Bearer ${token}` } : {};

  axios.get(endpoint, { headers })
      .then((response) => {
        console.log("API Response:", response.data.schedule);
        const imagesArray = response.data.images ? JSON.parse(response.data.images) : [];
        setWorkerData({ ...response.data, images: imagesArray});
        setWorkerData(prevState => ({
          ...prevState, // Retain all other properties
          workingHours: response.data.schedule // Update only the workingHours property
        }));
        setLoading(false);
      })
      .catch((error) => {
        console.error('Failed to load Profile:', error);
        setError('Failed to load Profile');
        setLoading(false);
      });
 // setWorkerData({}); // Reset data to avoid cache problems
}, [slug]);




useEffect(() => {
  // דוגמה לנתונים סטטיים של אירועים
  const staticEvents = [
    {
      id: 1,
      start: new Date(2024, 10, 26), // 26 נובמבר 2024
      end: new Date(2024, 10, 26), // הנחה שזה אירוע ליום שלם
      customerName: "moty",
      serviceType: "car wash",
      description: "wash my car please",
      color: 'blue', // צבע להדגשת ימים עם הזמנות
    },
    {
      id: 2,
      start: new Date(2024, 10, 27), // 27 נובמבר 2024
      end: new Date(2024, 10, 27), // הנחה שזה אירוע ליום שלם
      customerName: "dana",
      serviceType: "window cleaning",
      description: "clean all windows",
      color: 'blue', // צבע להדגשת ימים עם הזמנות
    },
    {
      id: 3,
      start: new Date(2024, 10, 27), // 27 נובמבר 2024
      end: new Date(2024, 10, 27), // הנחה שזה אירוע ליום שלם
      customerName: "dodo",
      serviceType: "home cleaning",
      description: "clean my home",
      color: 'blue', // צבע להדגשת ימים עם הזמנות
    }
  ];

  setEvents(staticEvents);
}, []);


useEffect(() => {
  const fetchReviews = async () => {
    try {
      const phoneNumber = slug.split('-')[0];

      const isPublic = true; // Replace this with your actual condition
      const baseURL = "http://localhost:8080";
      const endpoint = isPublic
          ?`/api/publicProfile/${slug}/reviews?phoneNumber=${phoneNumber}`
          :`/api/profile/${slug}/reviews?phoneNumber=${phoneNumber}` ;

      const response = await axios.get(`${baseURL}${endpoint}`);

      const rowArray = response.data.map((review) => {
        const createdAt = new Date(review.createdAt);
        createdAt.setHours(createdAt.getHours() + 4);
        const updatedAt = new Date(review.updatedAt);
        updatedAt.setHours(updatedAt.getHours() + 4);
        return {
          description: review.description || "No description provided",
          professionalism: review.professionalism || 0,
          reliability: review.reliability || 0,
          availability: review.availability || 0,
          createdAt:new Date(createdAt).toISOString().replace('T', ' ').split('.')[0],
          updatedAt:new Date(updatedAt).toISOString().replace('T', ' ').split('.')[0],
          customerName: review.notification?.orderService?.Customer
            ? `${review.notification.orderService.Customer.CustomerFirstName} ${review.notification.orderService.Customer.CustomerLastName}`
            : "Anonymous",
          averageRating: (
            (review.professionalism || 0) +
            (review.reliability || 0) +
            (review.availability || 0)
          ) / 3,
          showName: review.showName || 0 // ודא ששדה זה נכלל במידע שנשלף מהשרת
        };
      });

      // Set reviews data
      setReviewData(rowArray);
      console.log("the row array is:",rowArray);


      // Calculate overall average rank
      const totalAverage = rowArray.reduce((sum, review) => sum + review.averageRating, 0);
      const calculatedRank = rowArray.length > 0 ? totalAverage / rowArray.length : 0;
      setAverageRank(calculatedRank.toFixed(1)); // Update the state with 1 decimal


      const updateRateResponse = await axios.put('http://localhost:8080/api/updateRate', {
        phoneNumber: phoneNumber,
        averageRank: calculatedRank.toFixed(1),
      });

    } catch (error) {
      console.error("Error fetching reviews:", error);
    }
  };
  fetchReviews();

  const interval = setInterval(fetchReviews, 30000); // 60000ms = 1 minute

  // Clean up the interval when the component is unmounted
  return () => clearInterval(interval);

}, []);


useEffect(() => {
  const fetchNotifications = async () => {
      try {
          const token = localStorage.getItem('token');
          const response = await axios.get('http://localhost:8080/api/notifications', {
              headers: { Authorization: `Bearer ${token}` },
          });

          console.log("Fetched notifications:", response.data);

          const approvedEvents = response.data
              .filter(notification => notification.status === '1')
              .map(notification => ({
                  id: notification.id,
                  title: `${notification.orderService?.Customer?.CustomerFirstName || ''} ${notification.orderService?.Customer?.CustomerLastName || ''}`,
                  start: new Date(notification.startDate || notification.orderService?.serviceDate),
                  end: new Date(notification.endDate || notification.orderService?.serviceDate),
                  description: notification.description || "No description available",
                  serviceType: notification.orderService?.serviceType || "Unknown service", // טיפול ב-null
                  phoneNumber: notification.customerPhoneNumber || "No phone number provided",
                  customerName: `${notification.orderService?.Customer?.CustomerFirstName || 'Anonymous'} ${notification.orderService?.Customer?.CustomerLastName || ''}`,
                  color: 'blue', // Optional: To match the static events' color
              }));

          console.log("Approved events:", approvedEvents);

          setEvents(approvedEvents); // Update the state with dynamic events
      } catch (error) {
          console.error("Error fetching notifications:", error);
      }
  };

  fetchNotifications();
}, []);






  // State for managing pagination
  const [currentPage, setCurrentPage] = useState(0);
  const reviewsPerPage = 4; // Number of reviews to display per page

// Calculate the total number of pages based on the length of ReviewData
  const numPages = Math.ceil(ReviewData.length / reviewsPerPage);

// Slice the ReviewData to get the current page's reviews
  const currentReviews = ReviewData.slice(
      currentPage * reviewsPerPage,
      (currentPage + 1) * reviewsPerPage
  );

// Functions to navigate between pages
  const goToNextPage = () => {
    if (currentPage < numPages - 1) {
      setCurrentPage((prevPage) => prevPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (currentPage > 0) {
      setCurrentPage((prevPage) => prevPage - 1);
    }
  };

  // Function to render star ratings
  const renderReviewStars = (rating) => {
    const stars = [];
    // Add filled stars (gold color) based on the rating
    for (let i = 0; i < rating; i++) {
        stars.push(
            <span key={`filled-${i}`} style={{ color: '#ffc107' }}>⭐</span> // Gold star
        );
    }
    
    return stars;
};

const calculateRankings = (reviews) => {
  if (!reviews || reviews.length === 0) {
    return 0; // אם אין דירוגים, החזר 0
  }

  const totalRatings = reviews.reduce((sum, review) => sum + review.rating, 0);
  return totalRatings / reviews.length; // חישוב ממוצע
};



  function isWorkerOpen(workingHours) {
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    // Get the current day and time
    const now = new Date();
    const currentDay = daysOfWeek[now.getDay()]; // e.g., 'Sunday'
    const currentTime = now.getHours() * 60 + now.getMinutes(); // Convert current time to minutes

    // Find today's working hours
    const todaySchedule = workingHours.find(item => item.day === currentDay);

    if (!todaySchedule || !todaySchedule.time.includes('to')) {
      return false; // No schedule or invalid schedule
    }

    // Parse the start and end times
    const [start, end] = todaySchedule.time.split('to').map(time => time.trim());

    // Convert times to minutes for comparison
    const startMinutes = parseTimeToMinutes(start);
    const endMinutes = parseTimeToMinutes(end);

    if (isNaN(startMinutes) || isNaN(endMinutes)) {
      return false; // Invalid time range
    }

    // Check if the current time falls within the range
    return currentTime >= startMinutes && currentTime <= endMinutes;
  }

  function parseTimeToMinutes(time) {
    if (!time) return NaN; // Handle cases like "10:00 to "
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + (minutes || 0); // Default to 0 minutes if missing
  }





  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
      <ProfileContainer>
        {/* The rest of your component code */}
        <Header>
          <ProfileImage
              src={workerData.profilePicture || profileImage}
              alt="Profile"
          />

          <p style={{
            textAlign: 'center',
            fontSize: '14px',
            color: isWorkerOpen(workerData.workingHours) ? 'green' : 'red',
            marginTop: '268px',
            position: 'relative',
            left: '-150px',
          }}>
            {isWorkerOpen(workerData.workingHours) ? 'Open Now' : 'Closed Now'}
          </p>

          <InfoSection>
            <ProfileName>{workerData.firstName} {workerData.lastName}</ProfileName>
            <ProfileLocation>
              <p><strong>Areas of Work:</strong>
                {workerData.locations && workerData.locations.length > 0 ? (
                    <ul>
                      {workerData.locations.map((location, index) => (
                          <li key={index}>{location}</li>
                      ))}
                    </ul>
                ) : 'No jobs available'}
              </p>
            </ProfileLocation>
            <p style={{ display: workerData.specificLocation ? 'flex' : 'none' }}><strong>My Specific Location:</strong></p>
            <WazeLink href={`${workerData.specificLocation}` } target="_blank" style={{ display: workerData.specificLocation ? 'flex' : 'none' }}>
              <WazeIcon />
              Navigate to {workerData.street} {workerData.houseNumber}
            </WazeLink>
            <RankSection>
              <span>Rankings: {averageRank || 'N/A'}</span>
              <div className="StarRating">
                {renderStars(averageRank || 0)} {/* Use renderStars function */}
              </div>
              <p style={{ marginLeft: '10px' }}>({ReviewData.length})</p> {/* Add this line */}
            </RankSection>
          </InfoSection>
        </Header>
        <MainContent>
        <LeftColumn>
          <Section style={{  marginBottom: '0px'}}>
            <h3 style={{ fontWeight: 'bold', fontSize: '20px' }}>Informations</h3>
          </Section>
          <h4 style={{ display: 'block', marginBottom: '5px', marginTop: '0px', fontSize: '15px' }}>
            {workerData.firstName} {workerData.lastName}
          </h4>
          <WorkingHoursSection>
            <h3 style={{  fontSize: '15px'}}>Working Hours:</h3>
            <ul>
              {workerData.workingHours.length  ? (
                workerData.workingHours.map((hours, index) => (
                  <li key={index}>
                    <span style={{  fontSize: '15px'}}>{hours.day}:</span>
                    <span style={{  fontSize: '15px'}}>{hours.time}</span>
                  </li>
                ))



              ) : (
                <li>No working hours set.</li>
              )}
            </ul>
          </WorkingHoursSection>

          <Section style={{  marginBottom: '0px'}}>
            <h3 style={{ fontWeight: 'bold', fontSize: '20px' }}>Description</h3>
          </Section>
          <p style={{ fontSize: '15px', marginTop: '0px' }}>
            {workerData.description}
          </p>



          
        </LeftColumn>

        <RightColumn>
          <TabContainer>
            <TabButton active={activeTab === 'Timeline'} onClick={() => setActiveTab('Timeline')}>Timeline</TabButton>
            <TabButton active={activeTab === 'About'} onClick={() => setActiveTab('About')}>About</TabButton>
            <TabButton active={activeTab === 'Reviews'} onClick={() => setActiveTab('Reviews')}>Reviews</TabButton>
            {isPublicProfile && (
              <TabButton active={activeTab === 'Req'} onClick={() => setActiveTab('Req')}>Request a Service</TabButton>
            )}
            {!isPublicProfile && (
              <TabButton active={activeTab === 'Calendar'} onClick={() => setActiveTab('Calendar')}>Calendar</TabButton>
            )}

            

          </TabContainer>

          <ContentContainer>
            {activeTab === 'Timeline' && (
              <TimelineSection>
                {console.log(workerData)
                }
                {Array.isArray(workerData.images) && workerData.images.length > 0 ? (
                  workerData.images.map((image, index) => (
                    <img key={index} src={image} alt={`Event ${index + 1}`} onClick={() => {setCurrentImageIndex(index); setIsImageModalOpen(true);}} />
                  ))
                ) : (
                  <p>No images available.</p>
                )}
                {!isPublicProfile && (
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    {/*<AddImageButton>
                      <FaPlus size={20} color="#333" />
                      <AddImageText>Add Pictures</AddImageText>
                    </AddImageButton>
                    */}                    
                  </div>
                )}
              </TimelineSection>
            )}

            {activeTab === 'About' && (
              <ContactInfo>
                <h3>Contact Information</h3>
                {//<p><strong>Phone:</strong> {workerData.phoneNumber || 'No phone number available'}</p>
                }
                <p><strong>Email:</strong> {workerData.email || 'No email available'}</p>
                <p><strong>Jobs:</strong>
                  {workerData.jobs && workerData.jobs.length > 0 ? (
                      <ul>
                        {workerData.jobs.map((job, index) => (
                            <li key={index}>{job}</li>  // Display each job as a list item
                        ))}
                      </ul>
                  ) : 'No jobs available'}
                </p>
              </ContactInfo>
            )}

            {activeTab === 'Reviews' && (
                <div>
                  {ReviewData.length === 0 ? (
                      <p style={{ fontSize: '16px', color: '#555', textAlign: 'center', marginTop: '20px' }}>
                        This worker has not been reviewed yet.
                      </p>
                  ) : (
                      ReviewData.map((review, index) => (
                          <div
                              key={index}
                              style={{
                                marginBottom: '20px',
                                boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
                                padding: '15px',
                                borderRadius: '5px',
                                backgroundColor: 'white',
                                fontFamily: 'Arial, sans-serif',
                              }}
                          >
                            <h4 style={{ fontWeight: 'bold', fontSize: '18px' }}>
                              {review.showName ? review.customerName : "Anonymous"}
                            </h4>
                            <p style={{ fontSize: '16px', color: '#555' }}>
                              {review.description}
                            </p>
                            <div>
                              {renderReviewStars(review.averageRating.toFixed(1))} {/* Stars */}
                              <span style={{ marginLeft: '10px', color: '#333', fontSize: '14px' }}>
              ({review.averageRating.toFixed(1)}/5)
            </span>
                            </div>
                            <p style={{ fontSize: '14px', color: '#888', marginTop: '10px' }}>
                              Added on: {new Date(review.createdAt).toISOString().replace('T', ' ').split('.')[0]}
                            </p>
                            {new Date(review.updatedAt).getTime() > (new Date(review.createdAt).getTime() + 60000) && (
                                <p style={{ fontSize: '12px', color: '#888', fontStyle: 'italic', marginTop: '5px' }}>
                                  Edited on: {new Date(review.updatedAt).toISOString().replace('T', ' ').split('.')[0]}
                                </p>
                            )}
                          </div>
                      ))
                  )}
                </div>
            )}



{activeTab === 'Calendar' && !isPublicProfile && (
  <>
    <Calendar
      localizer={localizer}
      events={events}
      startAccessor="start"
      endAccessor="end"
      style={{ height: 500 }}
      onSelectEvent={handleSelectEvent}
      onSelectSlot={handleSelectDay}
      selectable
      dayPropGetter={dayPropGetter} // Properly apply day styles
      eventPropGetter={eventPropGetter} // Properly apply event styles
    />

    {selectedDayEvents.length > 0 ? (
      <EventDetailsTable events={selectedDayEvents} />
    ) : (
      <p>No events on this day.</p>
    )}
  </>
)}

{showEventForm && (
              <EventForm 
                selectedEvent={selectedEvent} 
                onSave={handleSaveEvent} 
                onClose={handleCloseEventForm} 
              />
            )}




{activeTab === 'Req' && (
              <form onSubmit={handleFormSubmit}>
                <div>
                  <StyledLabel>First Name:</StyledLabel>
                  <StyledInput required type="text" value={requestFormData.firstName} onChange={(e) => setRequestFormData({...requestFormData, firstName: e.target.value})} />
                </div>
                <div>
                  <StyledLabel>Last Name:</StyledLabel>
                  <StyledInput required type="text" value={requestFormData.lastName} onChange={(e) => setRequestFormData({...requestFormData, lastName: e.target.value})} />
                </div>
                <div>
                  <StyledLabel>Phone Number:</StyledLabel>
                  <StyledInput required type="text" value={requestFormData.phoneNumber} onChange={(e) => setRequestFormData({...requestFormData, phoneNumber: e.target.value})} />
                </div>
                <div>
                  <SelectWrapper>
                    <Label htmlFor="requestType">Request Type:</Label>
                    <StyledSelect
                    required
                      id="requestType"
                      value={requestFormData.requestType}
                      onChange={(e) => setRequestFormData({...requestFormData, requestType: e.target.value})}
                    >
                      <option value="" disabled selected>chose your request type</option>
                      {Array.isArray(workerData.jobs) && workerData.jobs.length > 0 ? (
                        workerData.jobs.map((job, index) => (<option key={index} value={job}>{job}</option>))
                      ) : (
                        <option value="">No available jobs</option>
                      )}
                    </StyledSelect>
                  </SelectWrapper>

                </div>
                <div>
                  <StyledLabel>Suitable Request Date:</StyledLabel>
                  <StyledInput  min={new Date().toISOString().split('T')[0]} required type="date" value={requestFormData.requestDate} onChange={(e) => setRequestFormData({...requestFormData, requestDate: e.target.value})} />
                </div>
                <div> 
                  <StyledLabel>Details about the Request:</StyledLabel>
                  <StyledTextArea  value={requestFormData.requestDetails} onChange={(e) => setRequestFormData({...requestFormData, requestDetails: e.target.value})} />
                </div>
                <StyledButton type="submit">Send Request</StyledButton>
              </form>
            )}
                        
          </ContentContainer>
        </RightColumn>
      </MainContent>
      <Modal isOpen={isModalOpen} onClose={handleCancel}>
        <h2>Verify Your Phone Number</h2>
        <p>Please enter the verification code sent to your phone.</p>
        <input
          type="text"
          value={enteredOTP}
          onChange={(e) => setEnteredOTP(e.target.value)}
        />
        <VerifyButton onClick={handleOTPSubmit}>Verify</VerifyButton>
        <button onClick={handleCancel}>Cancel</button>
      </Modal>
      <ImageModal
        isOpen={isImageModalOpen}
        images={workerData.images}
        currentIndex={currentImageIndex}
        onClose={() => setIsImageModalOpen(false)}
        onNext={() => setCurrentImageIndex((prev) => (prev + 1) % workerData.images.length)}
        onPrev={() => setCurrentImageIndex((prev) => (prev - 1 + workerData.images.length) % workerData.images.length)}
      />
      </ProfileContainer>
  );
};

export default ProfileForm;