import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import WorkerDataService from "../services/worker.service";

const styles = {
    signupContainer: {
        width: '500px',
        margin: '50px auto',
        textAlign: 'center',
        padding: '40px',
        backgroundColor: 'none',
    },
    header: {
        marginBottom: '20px',
        fontSize: '24px',
        color: '#333'
    },
    row: {
        display: 'flex',
        justifyContent: 'space-between',
        marginBottom: '10px',
        width: '100%', // Make sure row takes full width
        gap: '10px', // Add gap between input fields

    },
    inputHalf: {
        width: '100%',
        padding: '10px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        boxSizing: 'border-box', // Ensure padding doesn't affect width
    },
    passwordContainer: {
        position: 'relative',
        width: '49%', // Keep this the same width as other inputs
        marginBottom: '10px',
    },
    button: {
        width: '100%',
        padding: '10px',
        backgroundColor: '#fbbd14',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '14px',
        color: '#000',
        marginTop: '20px'
    },
    errorMessage: {
        color: 'red',
        marginTop: '20px',
        fontSize: '14px'
    },
    loginLink: {
        marginTop: '20px',
        fontSize: '12px'
    },
    toggleButton: {
        position: 'absolute',
        right: '10px',
        top: '50%',
        transform: 'translateY(-50%)',
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        fontSize: '18px',
        color: '#000000',
    }
};

const SignupForm = () => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        phoneNumber: '',
        email: '',
        password: '',
        confirmPassword: ''
    });

    const [errorMessage, setErrorMessage] = useState('');
    const [isSignupComplete, setIsSignupComplete] = useState(false);
    const [showPassword, setShowPassword] = useState(false); // State for toggling password visibility
    const [showConfirmPassword, setShowConfirmPassword] = useState(false); // State for toggling confirm password visibility

    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage(''); // Clear any previous error message

        const { firstName, lastName, phoneNumber, email, password, confirmPassword } = formData;

        // Check if any field is empty
        if (!firstName || !lastName || !phoneNumber || !email || !password || !confirmPassword) {
            setErrorMessage('All fields are required.');
            return;
        }

        // Check if passwords match
        if (password !== confirmPassword) {
            setErrorMessage('Passwords do not match.');
            return;
        }

        try {
            await WorkerDataService.create(formData);
            console.log('Registration successful');
            localStorage.setItem('workerPhoneNumber', formData.phoneNumber);
            navigate('/complete-profile'); // Only proceed to next page if signup is successful
        } catch (error) {
            console.error('Error response:', error.response);
            if (error.response && error.response.data && error.response.data.message) {
                if (error.response.data.message.includes('Phone number is already registered')) {
                    setErrorMessage('The phone number is already registered.');
                } else {
                    setErrorMessage('An error occurred during registration. Please try again.');
                }
            } else {
                setErrorMessage('An unexpected error occurred. Please try again.');
            }
        }
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    const toggleConfirmPasswordVisibility = () => {
        setShowConfirmPassword(!showConfirmPassword);
    };

    return (
        <div style={styles.signupContainer}>
            <h2 style={styles.header}>Sign Up and Showcase Your Professional Skills!</h2>
            <form onSubmit={handleSubmit}>
                <div style={styles.row}>
                    <input
                        type="text"
                        name="firstName"
                        placeholder="First Name"
                        style={styles.inputHalf}
                        value={formData.firstName}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="text"
                        name="lastName"
                        placeholder="Last Name"
                        style={styles.inputHalf}
                        value={formData.lastName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div style={styles.row}>
                    <input
                        type="text"
                        name="phoneNumber"
                        placeholder="Phone"
                        style={styles.inputHalf}
                        value={formData.phoneNumber}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="email"
                        name="email"
                        placeholder="Enter your email"
                        style={styles.inputHalf}
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div style={styles.row}>
                    <div style={styles.passwordContainer}>
                        <input
                            type={showPassword ? 'text' : 'password'}
                            name="password"
                            placeholder="Password"
                            style={styles.inputHalf}
                            value={formData.password}
                            onChange={handleChange}
                            required
                        />
                        <button
                            type="button"
                            style={styles.toggleButton}
                            onClick={togglePasswordVisibility}
                        >
                            <i className={showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'}></i>
                        </button>
                    </div>
                    <div style={styles.passwordContainer}>
                        <input
                            type={showConfirmPassword ? 'text' : 'password'}
                            name="confirmPassword"
                            placeholder="Confirm Password"
                            style={styles.inputHalf}
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            required
                        />
                        <button
                            type="button"
                            style={styles.toggleButton}
                            onClick={toggleConfirmPasswordVisibility}
                        >
                            <i className={showConfirmPassword ? 'fas fa-eye-slash' : 'fas fa-eye'}></i>
                        </button>
                    </div>
                </div>
                {errorMessage && <div style={styles.errorMessage}>{errorMessage}</div>}
                <button type="submit" style={styles.button}>Next</button>
            </form>
            <a href='/loginform'>
                <div style={styles.loginLink}>
                    Already have an account?
                </div>
            </a>
        </div>
    );
};

export default SignupForm;
