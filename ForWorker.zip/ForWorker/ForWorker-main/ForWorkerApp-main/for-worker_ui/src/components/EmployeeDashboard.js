import React from 'react';
import styled from 'styled-components';

const Dashboard = styled.div`
  display: flex;
  min-height: 100vh;
  background-color: #f4f6f9;
`;

const Sidebar = styled.div`
  width: 250px;
  background-color: #2c3e50;
  color: #ecf0f1;
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

const SidebarTitle = styled.h2`
  text-align: center;
`;

const SidebarList = styled.ul`
  list-style: none;
  padding: 0;
  flex-grow: 1;
`;

const SidebarListItem = styled.li`
  padding: 10px 0;
  text-align: center;
  cursor: pointer;
  &:hover {
    background-color: #34495e;
  }
`;

const MainContent = styled.div`
  flex: 1;
  padding: 20px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const NewEmployeeButton = styled.button`
  padding: 10px 20px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
`;

const Filter = styled.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  margin-bottom: 20px;
`;

const FilterInput = styled.input`
  padding: 10px;
  width: calc(33% - 10px);
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const FilterSelect = styled.select`
  padding: 10px;
  width: calc(33% - 10px);
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const EmployeeList = styled.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
`;

const TableHead = styled.thead`
  background-color: #f9fafb;
`;

const TableRow = styled.tr`
  border-bottom: 1px solid #e1e1e1;
`;

const TableHeader = styled.th`
  padding: 12px 15px;
  text-align: left;
`;

const TableCell = styled.td`
  padding: 12px 15px;
`;

const Checkbox = styled.input`
  margin-right: 10px;
`;

const EmployeeDashboard = () => {
    return (
        <Dashboard>
            <Sidebar>
                <SidebarTitle>Dashboard</SidebarTitle>
                <SidebarList>
                    <SidebarListItem>Employees</SidebarListItem>
                    <SidebarListItem>Tasks</SidebarListItem>
                    <SidebarListItem>Projects</SidebarListItem>
                    <SidebarListItem>Settings</SidebarListItem>
                    <SidebarListItem>Management</SidebarListItem>
                </SidebarList>
            </Sidebar>
            <MainContent>
                <Header>
                    <h1>Employees</h1>
                    <NewEmployeeButton>New Employee</NewEmployeeButton>
                </Header>
                <Filter>
                    <FilterInput type="text" placeholder="ID" />
                    <FilterInput type="text" placeholder="Name" />
                    <FilterInput type="text" placeholder="E-mail" />
                    <FilterInput type="text" placeholder="By group name" />
                    <FilterSelect>
                        <option>HR Manager</option>
                    </FilterSelect>
                    <FilterInput type="text" placeholder="Contract Duration" />
                    <FilterSelect>
                        <option>CheckTask, Brillion</option>
                    </FilterSelect>
                    <FilterInput type="text" placeholder="Label" />
                </Filter>
                <EmployeeList>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableHeader></TableHeader>
                                <TableHeader>ID</TableHeader>
                                <TableHeader>Name</TableHeader>
                                <TableHeader>Department Role</TableHeader>
                                <TableHeader>Contract Duration</TableHeader>
                                <TableHeader>Projects</TableHeader>
                            </TableRow>
                        </TableHead>
                        <tbody>
                        <TableRow>
                            <TableCell><Checkbox type="checkbox" /></TableCell>
                            <TableCell>#01</TableCell>
                            <TableCell>Carollen Bloome</TableCell>
                            <TableCell>HR Manager</TableCell>
                            <TableCell>13 Mar 2019 - 16 Jan 2022</TableCell>
                            <TableCell>CheckTask, Brillion</TableCell>
                        </TableRow>
                        {/* Repeat as necessary */}
                        </tbody>
                    </Table>
                </EmployeeList>
            </MainContent>
        </Dashboard>
    );
};

export default EmployeeDashboard;
