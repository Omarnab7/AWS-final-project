import React, { useState } from 'react';
import styled from 'styled-components';

// Header Component
const Header = styled.div`
  display: flex;
  align-items: center;
  padding: 20px;
`;

const CompanyLogo = styled.img`
  width: 100px;
  border-radius: 8px;
`;

const CompanyInfo = styled.div`
  margin-left: 20px;
`;

const Title = styled.h1`
  font-size: 24px;
  margin: 0;
`;

const Rating = styled.div`
  color: green;
  font-size: 16px;
`;

// Navigation Bar Component
const NavBar = styled.div`
  display: flex;
  justify-content: center;
  margin-top: -100px;
`;

const NavButton = styled.button`
  background-color: white;
  border: none;
  border-bottom: 2px solid transparent;
  font-size: 16px;
  margin: 0 10px;
  padding: 10px;
  cursor: pointer;
  color: #007bff;

  &:hover {
    border-bottom: 2px solid #007bff;
  }

  &:focus {
    outline: none;
    border-bottom: 2px solid #007bff;
  }
`;

// Main Section
const Section = styled.section`
  padding: 20px;
`;

const Introduction = styled.p`
  font-size: 16px;
  line-height: 1.6;
`;

// Overview and Payment
const Overview = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
`;

const OverviewItem = styled.div`
  width: 48%;
`;

// Photo Gallery Component
const PhotoGallery = () => {
    const [photos, setPhotos] = useState([]);
    const [newPhotoUrl, setNewPhotoUrl] = useState('');

    const handleAddPhoto = () => {
        if (newPhotoUrl) {
            setPhotos([...photos, newPhotoUrl]);
            setNewPhotoUrl('');
        }
    };

    return (
        <div>
            <h3>Photo Gallery</h3>
            <input
                type="text"
                value={newPhotoUrl}
                onChange={(e) => setNewPhotoUrl(e.target.value)}
                placeholder="Enter photo URL"
            />
            <button onClick={handleAddPhoto}>Add Photo</button>
            <PhotoGrid>
                {photos.map((photo, index) => (
                    <PhotoItem key={index}>
                        <img src={photo} alt={`Photo ${index + 1}`} />
                    </PhotoItem>
                ))}
            </PhotoGrid>
        </div>
    );
};

const PhotoGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 10px;
  margin-top: 10px;
`;

const PhotoItem = styled.div`
  img {
    width: 100%;
    border-radius: 8px;
  }
`;

// Main Component
const Profile = () => {
    return (
        <div>
            <div>
                <NavBar>
                    <NavButton>About</NavButton>
                    <NavButton>Photos</NavButton>
                    <NavButton>Reviews</NavButton>
                </NavBar>
            </div>
            <Header>
                <CompanyLogo src="logo-url" alt="profile pic" />
                <CompanyInfo>
                    <Title>First name and last name </Title>
                    <Rating>Very good 4.5 ★★★★★ (100)</Rating>
                </CompanyInfo>
            </Header>

            <Section>
                <Title>About Me </Title>
                <Introduction>
                    Description about the worker
                </Introduction>

                <Overview>
                    <OverviewItem>
                        <h3>Overview</h3>
                        <p>What I am working on</p>
                        <p>Locations</p>
                        <p>Phone Number</p>
                    </OverviewItem>
                </Overview>

                <Overview>
                    <h3>Reviews</h3>
                </Overview>

            </Section>
        </div>
    );
};

export default Profile;
