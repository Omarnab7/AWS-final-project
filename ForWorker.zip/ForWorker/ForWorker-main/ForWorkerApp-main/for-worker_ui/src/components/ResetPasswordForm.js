import React, { useState } from 'react';
import styled from 'styled-components';
import { useLocation } from 'react-router-dom';
import WorkerService from "../services/worker.service";
import { useNavigate } from 'react-router-dom';

const PageContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f9f9f9;
`;

const ResetPasswordContainer = styled.div`
  width: 50%;
  max-width: 400px;
  margin: 50px auto;
  text-align: center;
  padding: 20px;
  border: none;
`;

const InputContainer = styled.div`
  position: relative;
  width: 100%;
`;

const Input = styled.input`
  width: 100%;
  margin: 10px 0;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  box-sizing: border-box;
`;

const ToggleButton = styled.button`
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  cursor: pointer;
  font-size: 14px;
  color: #000;
`;

const Button = styled.button`
  width: 100%;
  margin: 10px 0;
  padding: 10px;
  background-color: #fbbd14;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  color: #000;
  box-sizing: border-box;
`;

const Header = styled.h2`
  margin-bottom: 20px;
  font-weight: bold;
  font-size: 24px;
  color: #333;
`;

const Message = styled.div`
  color: ${props => (props.success ? 'green' : 'red')};
  margin-top: 20px;
`;

const ResetPasswordForm = () => {
    const location = useLocation();
    const [phoneNumber] = useState(location.state?.phoneNumber || '');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [message, setMessage] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const navigate = useNavigate();

    const toggleShowPassword = () => {
        setShowPassword(!showPassword);
    };

    const toggleShowConfirmPassword = () => {
        setShowConfirmPassword(!showConfirmPassword);
    };

    const handleResetPassword = async (e) => {
        e.preventDefault();

        if (password !== confirmPassword) {
            setMessage('Passwords do not match. Please try again.');
            return;
        }

        try {
            const response = await WorkerService.resetPasswordUnauth(phoneNumber, password);
            setMessage(response.data.message);
            setTimeout(() => navigate('/loginform') , 1500);
        } catch (error) {
            setMessage('Error resetting password. Please try again.');
            console.error('Reset password error:', error);
        }
    };


    return (
        <PageContainer>
            <ResetPasswordContainer>
                <Header>Reset your password</Header>
                <form onSubmit={handleResetPassword}>
                    <InputContainer>
                        <Input
                            type={showPassword ? 'text' : 'password'}
                            placeholder="New Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        <ToggleButton type="button" onClick={toggleShowPassword}>
                            <i className={showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'}></i>
                        </ToggleButton>
                    </InputContainer>
                    <InputContainer>
                        <Input
                            type={showConfirmPassword ? 'text' : 'password'}
                            placeholder="Confirm Password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                        />
                        <ToggleButton type="button" onClick={toggleShowConfirmPassword}>
                            <i className={showConfirmPassword ? 'fas fa-eye-slash' : 'fas fa-eye'}></i>
                        </ToggleButton>
                    </InputContainer>
                    <Button type="submit">Reset Password</Button>
                </form>
                {message && <Message>{message}</Message>}
            </ResetPasswordContainer>
        </PageContainer>
    );
};

export default ResetPasswordForm;
