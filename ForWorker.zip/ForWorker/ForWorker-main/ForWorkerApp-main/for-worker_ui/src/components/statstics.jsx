import React, { useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import { ResponsiveChartContainer } from "@mui/x-charts/ResponsiveChartContainer";
import { LinePlot, MarkPlot } from "@mui/x-charts/LineChart";
import { ChartsXAxis } from "@mui/x-charts/ChartsXAxis";
import { ChartsYAxis } from "@mui/x-charts/ChartsYAxis";
import { ChartsGrid } from "@mui/x-charts/ChartsGrid";
import { ChartsTooltip } from "@mui/x-charts/ChartsTooltip";
import Chart from "react-apexcharts";

const dataset = [
  { month: "Jan", users: 20 },
  { month: "Feb", users: 40 },
  { month: "Mar", users: 50 },
  { month: "Apr", users: 70 },
  { month: "May", users: 100 },
  { month: "Jun", users: 150 },
  { month: "Jul", users: 130 },
  { month: "Aug", users: 170 },
  { month: "Sep", users: 160 },
  { month: "Oct", users: 180 },
  { month: "Nov", users: 90 },
  { month: "Dec", users: 50 },
];

const foodData = [
  { name: "seafood", quantity: 30 },
  { name: "beef", quantity: 40 },
  { name: "vegan food", quantity: 45 },
  { name: "pasta", quantity: 50 },
  { name: "pizza", quantity: 49 },
  { name: "bee5", quantity: 60 },
  { name: "raf", quantity: 70 },
  { name: "sheep meat", quantity: 91 },
];

const series = [{ type: "line", dataKey: "users", color: "#577399" }];

function ReverseExampleNoSnap({ data }) {
  const [reverseX, setReverseX] = useState(false);
  const [reverseLeft, setReverseLeft] = useState(false);

  return (
    <Box sx={{ width: "100%" }}>
      <h2 style={{ textAlign: "center" }}>
        Total number of meals in each month
      </h2>
      <ResponsiveChartContainer
        series={[{ type: "line", dataKey: "quantity", color: "#577399" }]}
        xAxis={[
          {
            scaleType: "band",
            dataKey: "name",
            label: "Month",
            reverse: reverseX,
          },
        ]}
        yAxis={[{ id: "leftAxis", reverse: reverseLeft, domain: [0, 200] }]}
        dataset={data}
        height={400}
      >
        <ChartsGrid horizontal />
        <LinePlot />
        <MarkPlot />

        <ChartsXAxis />
        <ChartsYAxis axisId="leftAxis" label="Total number of meals" />
        <ChartsTooltip
          formatter={({ dataKey, value }) => `${dataKey}: ${value}`}
        />
      </ResponsiveChartContainer>
    </Box>
  );
}

function Statistics({ foodData }) {
  const [options] = useState({
    chart: {
      id: "basic-bar",
    },
    xaxis: {
      categories: foodData.map((item) => item.name),
    },
  });

  const [series] = useState([
    {
      name: "series-1",
      data: foodData.map((item) => item.quantity).sort((a, b) => b - a),
    },
  ]);

  return (
    <div style={{ textAlign: "center", backgroundColor: "#f0f0f0" }}>
      <h1>The Food Statistics</h1>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          backgroundColor: "#f0f0f0",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            width: "800px",
            height: "600px",
          }}
        >
          <Chart
            options={options}
            series={series}
            type="bar"
            width="800"
            height="600"
          />
        </div>
      </div>
    </div>
  );
}

function SummaryTable({ onSummaryClick }) {
  const totalUsers = dataset.reduce((sum, item) => sum + item.users, 0);
  const totalFood = foodData.reduce((sum, item) => sum + item.quantity, 0);
  const meals = foodData.reduce((sum, item) => sum + item.quantity, 0); // Total quantity of all food items
  const AVG_cookingtime = 0; // You need to define how to calculate this
  const Total_reset_password = 50; // Example value for total reset password requests

  return (
    <Paper sx={{ width: "100%", padding: 2, marginTop: 2 }}>
      <TableContainer>
        <Table aria-label="summary table">
          <TableHead>
            <TableRow>
              <TableCell
                onClick={() => onSummaryClick("Total Number of Users")}
              >
                Total Number of Users
              </TableCell>
              <TableCell
                onClick={() => onSummaryClick("Total Number generated food")}
              >
                Total Number generated food
              </TableCell>
              <TableCell
                onClick={() => onSummaryClick("Total number of meals")}
              >
                Total number of meals
              </TableCell>
              <TableCell
                onClick={() => onSummaryClick("Average cooking time of meals")}
              >
                Average cooking time of meals
              </TableCell>
              <TableCell
                onClick={() =>
                  onSummaryClick("Total number of password reset requests")
                }
              >
                Total number of password reset requests
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell>{totalUsers}</TableCell>
              <TableCell>{totalFood}</TableCell>
              <TableCell>{meals}</TableCell>
              <TableCell>{AVG_cookingtime}</TableCell>
              <TableCell>{Total_reset_password}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}

function CombinedCharts() {
  const [selectedSummary, setSelectedSummary] = useState("");

  const handleSummaryClick = (summary) => {
    setSelectedSummary(summary);
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "20px",
        padding: "20px",
      }}
    >
      <SummaryTable onSummaryClick={handleSummaryClick} />
      {selectedSummary === "Total Number of Users" && (
        <ReverseExampleNoSnap
          data={dataset.map((item) => ({
            name: item.month,
            quantity: item.users,
          }))}
        />
      )}
      {selectedSummary === "Total Number generated food" && (
        <Statistics foodData={foodData} />
      )}
      {selectedSummary === "Total number of meals" && (
        <ReverseExampleNoSnap data={foodData} />
      )}
      {/* Add similar conditions for other summaries */}
    </div>
  );
}

export default CombinedCharts;
