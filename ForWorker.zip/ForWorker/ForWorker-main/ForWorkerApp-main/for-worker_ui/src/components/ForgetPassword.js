import React, { useState } from 'react';
import WorkerDataService from "../services/worker.service";
import { useNavigate } from 'react-router-dom';

const ForgetPassword = () => {
    const [phoneNumber, setPhoneNumber] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    const handleInputChange = (e) => {
        setPhoneNumber(e.target.value);
    };

    const handleForgetPassword = async (e) => {
        e.preventDefault();
        setSuccessMessage('');
        setErrorMessage('');

        try {
            const response = await WorkerDataService.checkPhoneNumberExists(phoneNumber);
            if (response.data.exists) {
                setSuccessMessage('Phone number is registered! Proceeding to reset password...');
                
                setTimeout(() => {
                    navigate('/ResetPasswordForm', { state: { phoneNumber } });
                }, 1500); // 1.5 seconds delay to allow the success message to display
            } else {
                setErrorMessage(`Phone number ${phoneNumber} does not exist.`);
            }
        } catch (error) {
            if (error.response && error.response.status === 404) {
                setErrorMessage(`Phone number ${phoneNumber} does not exist.`);
            } else {
                console.error('Error checking phone number:', error);
                setErrorMessage('Error checking phone number. Please try again.');
            }
        }
    };

    return (
        <div style={{ maxWidth: '400px', margin: 'auto' }}>
            <h1 className="mb-3 text-center" style={{ color: '#1a1a1a' }}>Reset your password</h1>
            <form onSubmit={handleForgetPassword} className="mb-3">
                <div className="form-group">
                    <label htmlFor="Phone" style={{ color: '#1a1a1a', display: 'block', marginBottom: '0.5rem' }}>Phone:</label>
                    <input
                        type="tel"
                        className="form-control"
                        placeholder="05*-*******"
                        name="phonenumber"
                        id="Phone"
                        value={phoneNumber}
                        onChange={handleInputChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', boxSizing: 'border-box' }}
                    />
                </div>
                <button type="submit" className="btn btn-primary btn-block" style={{ backgroundColor: 'rgb(0, 158, 158)', width: '100%', padding: '0.75rem' }}>Reset</button>
                {errorMessage && <p style={{ color: 'red', marginTop: '1rem' }}>{errorMessage}</p>}
                {successMessage && <p style={{ color: 'green', marginTop: '1rem' }}>{successMessage}</p>}
            </form>
        </div>
    );
};

export default ForgetPassword;
