import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useParams, useLocation } from 'react-router-dom';
import axios from 'axios';
import Switch from "react-switch";
// Styled Components matching the style of your login form
const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
`;
const LabelContainer = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 10px;
  font-size: 16px;
`;

const LabelText = styled.span`
  margin-right: 10px;
`;

const Title = styled.h1`
  font-size: 24px;
  margin-bottom: 20px;
  text-align: center;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  width: 300px;
`;

const Label = styled.label`
  margin-bottom: 10px;
  font-size: 16px;
`;

const Input = styled.input`
  padding: 10px;
  margin-bottom: 20px;
  border-radius: 5px;
  border: 1px solid #ddd;
  font-size: 16px;
`;

const TextArea = styled.textarea`
  padding: 10px;
  margin-bottom: 20px;
  border-radius: 5px;
  border: 1px solid #ddd;
  font-size: 16px;
`;

const Button = styled.button`
  padding: 10px;
  border-radius: 5px;
  border: none;
  background-color: #eab607;
  color: white;
  font-size: 16px;
  cursor: pointer;
  margin-top: 10px;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #e69500;
  }
`;



const ReviewPage = () => {
    const [averageRank, setAverageRank] = useState(0);


    const { serialNumber } = useParams(); // Get serialNumber from URL
    const [jobName, setJobName] = useState(''); // Declare jobName state
    const[WorkerPhoneNumber,SetWorkerPhoneNumber]=useState('');
    const[CustomerName,setCustomerName]=useState('');
    const[workerName,setworkerName]=useState('');
    const [professionality, setProfessionality] = useState(0); // Declare professionalism state
    const [availability, setAvailability] = useState(0); // Declare availability state
    const [reliability, setReliability] = useState(0); // Declare reliability state
    const [description, setDescription] = useState(''); // Declare description state
    const [showName, setShowName] = useState(0);

    const [reviewData, setReviewData] = useState({
        professionalism: 0,
        availability: 0,
        reliability: 0,
        description: '',
    });

    // Fetch existing review data by serialNumber
    useEffect(() => {

        if (serialNumber) {
            console.log("Serial Number:", serialNumber);

            axios.get(`http://localhost:8080/api/review/${serialNumber}`)
                .then((response) => {
                    const data = response.data;
                    console.log("response.dataresponse.data",response.data);
                    if (data) {
                        console.log("Fetched Review Data:", data);
                        setReviewData(data); // Pre-fill form with existing review
                        SetWorkerPhoneNumber(data.workerPhoneNumber);
                        setCustomerName(data.customerfullname);
                        setworkerName(data.workerfullname);
                        setJobName(data.jobName); // Set the jobName to display
                        setProfessionality(data.professionalism);
                        setAvailability(data.availability);
                        setReliability(data.reliability);
                        setDescription(data.description);
                        setShowName(data.showName === 1);
                    }
                })
                .catch((error) => console.error('Error fetching review:', error));
        }
    }, [serialNumber]);

    // Handle form submission to update the review
    const handleSubmit = async (e) => {
        e.preventDefault();
        const updatedReviewData = {
            professionalism: professionality,
            availability: availability,
            reliability: reliability,
            description: description,
            showName: showName ? 1 : 0,
        };
        try {
            // Send the updated review data to the backend using axios
            const response = await axios.put(`http://localhost:8080/api/review/${serialNumber}`, updatedReviewData, {
                headers: {
                    'Content-Type': 'application/json',
                }
                });
            const responsess = await axios.put(`http://localhost:8080/api/review`, {
                phoneNumber: WorkerPhoneNumber,
            });

            if (response.data.success) {
                alert('Review updated successfully!');
            } else {
                alert('Failed to update review');
            }
        } catch (error) {
            console.error('Error updating review:', error);
        }



    };


    return (
        <Container>
            <Title>We Value Your Feedback!</Title>
            <h2>Leave a Review for {jobName}</h2>
            <Form onSubmit={handleSubmit}>
                <LabelContainer>
                    <LabelText>{'Show My Name'}</LabelText>

                    <Switch
                            onChange={() => setShowName(!showName)}
                            checked={showName}
                            onColor="#86d3ff"
                            onHandleColor="#2693e6"
                            handleDiameter={20}
                            uncheckedIcon={false}
                            checkedIcon={false}
                            boxShadow="0px 1px 5px rgba(0, 0, 0, 0.6)"
                            activeBoxShadow="0px 0px 1px 10px rgba(0, 0, 0, 0.2)"
                            height={12}
                            width={30}
                        />
                        
                </LabelContainer>

                {showName && (
                    <>
                    <Label>your Name </Label>
                    <Input
                        type="text"
                        placeholder="your name"
                        value={CustomerName}
                        disabled
                    />
                    </>
                )}
                <Label>the worker Name </Label>
                <Input
                    type="text"
                    placeholder="worker name"
                    value={workerName}
                    disabled  // Make this field non-editable
                />

                <Label>the worker phone number </Label>
                <Input
                    type="text"
                    placeholder="Phone Number"
                    value={WorkerPhoneNumber}
                    disabled  // Make this field non-editable
                />

                <Label>Professionality (out of 5):</Label>
                <Input
                    type="number"
                    value={professionality}
                    onChange={(e) => setProfessionality(e.target.value)}
                    min="1"
                    max="5"
                />

                <Label>Availability (out of 5):</Label>
                <Input
                    type="number"
                    value={availability}
                    onChange={(e) => setAvailability(e.target.value)}
                    min="1"
                    max="5"
                />

                <Label>Reliability (out of 5):</Label>
                <Input
                    type="number"
                    value={reliability}
                    onChange={(e) => setReliability(e.target.value)}
                    min="1"
                    max="5"
                />

                <Label>Write a Review:</Label>
                <TextArea
                    type ="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Write your feedback here..."
                />

                <Button type="submit" style={{ marginBottom: '20px' }}>Send Review</Button>
            </Form>
        </Container>
    );
};

export default ReviewPage;
