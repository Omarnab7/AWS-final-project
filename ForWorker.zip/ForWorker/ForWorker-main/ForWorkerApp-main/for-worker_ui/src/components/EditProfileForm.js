import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

// Styled Components
const PageContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f9f9f9;
  padding: 20px;
`;


const EditProfileContainer = styled.div`
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  text-align: center;
  padding: 40px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`;

const Input = styled.input`
  width: 100%;
  margin: 10px 0;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 16px;
  background-color: ${(props) => (props.disabled ? '#f0f0f0' : '#fff')}; /* Grey out disabled fields */
`;

const TextArea = styled.textarea`
  width: 100%;
  margin: 10px 0;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
  resize: none;
  font-size: 16px;
`;

const CheckboxList = styled.div`
  max-height: 200px;
  overflow-y: scroll;
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 10px;
`;

const CheckboxItem = styled.div`
  margin-bottom: 10px;
`;

const Button = styled.button`
  width: 100%;
  margin: 10px 0;
  padding: 15px;
  background-color: #fbbd14;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  color: #000;
`;

const Header = styled.h2`
  margin-bottom: 20px;
  font-weight: bold;
  font-size: 28px;
  color: #333;
`;

const Message = styled.div`
  color: ${props => props.success ? 'green' : 'red'};
  margin-top: 20px;
`;

const EditProfileForm = () => {
    const slug = localStorage.getItem("slug"); // Retrieve the slug from localStorage
    const [phoneNumber, setPhoneNumber] = useState('');
    const [email, setEmail] = useState('');
    const [specificLocation,setspecificLocation] = useState('');
    const [description, setDescription] = useState('');
    const [message, setMessage] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [profilePicture, setProfilePicture] = useState(null); // Store the selected profile picture
    const [selectedJobs, setSelectedJobs] = useState([]);
    const [selectedLocations, setSelectedLocations] = useState([]);
    const [jobs, setJobs] = useState([]);
    const [locations, setLocations] = useState([]);
    const [jobSearch, setJobSearch] = useState('');
    const [locationSearch, setLocationSearch] = useState('');
    const [schedule,setSchedule]=useState([]);
    const [hasEditedSchedule, setHasEditedSchedule] = useState(false); // Track if the schedule was edited
    const allDays = [
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    ];

    const navigate = useNavigate();

    // Fetch current user data (pre-populate form)
    useEffect(() => {
        const token = localStorage.getItem('token');
        axios.get('http://localhost:8080/api/profile', {
            headers: {
                Authorization: `Bearer ${token}`,
            }
        })
        .then(response => {
            const { phoneNumber, email, profilePicture, firstName, lastName, description, jobs, locations ,specificLocation,schedule} = response.data;
            setPhoneNumber(phoneNumber);
            setEmail(email);
            setFirstName(firstName);
            setLastName(lastName);
            setProfilePicture(profilePicture); // Set profile picture URL
            setDescription(description);
            setSelectedJobs(jobs || []);
            setSelectedLocations(locations || []);
            setspecificLocation(specificLocation || 'no location provided yet');
            setSchedule(schedule||[]);
        })
        .catch(error => {
            console.error('Error fetching profile:', error);
            setMessage('Error loading profile data');
        });

        // Fetch jobs and locations
        const fetchJobsAndLocations = async () => {
            try {
                const [jobsResponse, locationsResponse] = await Promise.all([
                    axios.get('http://localhost:8080/api/jobs'),
                    axios.get('http://localhost:8080/api/locations')
                ]);
                setJobs(jobsResponse.data);
                setLocations(locationsResponse.data);
            } catch (error) {
                console.error('Error fetching jobs and locations:', error);
            }
        };

        fetchJobsAndLocations();
    }, []);

            // Add the file input handling for profile picture

    const handleCheckboxChange = (e, type) => {
        const value = e.target.value;
        let selectedItems;
        if (type === 'jobs') {
            setSelectedJobs([value]);
        } else if (type === 'locations') {
            selectedItems = [...selectedLocations];
            if (selectedItems.includes(value)) {
                selectedItems = selectedItems.filter(item => item !== value);
            } else {
                selectedItems.push(value);
            }
            setSelectedLocations(selectedItems);
        }
    };

    const handleProfilePictureChange = (e) => {
        const file = e.target.files[0];
        setProfilePicture(file); // Update state with the selected file
    };

      // Function to upload the image to S3
  const uploadImageToS3 = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}:8080/uploads3`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      return response.data.fileUrl; // Return the S3 URL
    } catch (error) {
      console.error('Error uploading file to S3:', error);
      throw error;
    }
  };
    const handleUpdateProfile = async (e) => {
      e.preventDefault();
      if (!firstName || !lastName || !description || selectedJobs.length === 0 || selectedLocations.length === 0) {
          setMessage('All fields must be filled and at least one job and one location must be selected.');
          return;
      }

      try {
          const token = localStorage.getItem('token');
          if (!token) {
              setMessage('Authentication required. Please log in.');
              return;
          }
              // Handle profile picture upload
        let profilePictureUrl = profilePicture;
        if (profilePicture instanceof File) {
        profilePictureUrl = await uploadImageToS3(profilePicture);  // This method uploads to S3
        }

          const response = await axios.put('http://localhost:8080/api/edit-profile', {
              firstName,
              lastName,
              profilePicture: profilePictureUrl,
              description,
              selectedJobs,
              selectedLocations,
              specificLocation ,
              schedule,
          }, {
              headers: {
                  Authorization: `Bearer ${token}`
              }
          });
  
          setMessage(response.data.message);  // Success message from backend
          navigate(`/ProfileForm/${slug}`);  // Navigate back to the profile page
      } catch (error) {
          console.error('Error updating profile:', error);
          setMessage('Error updating profile. Please try again.');
      }
  };

    const handleCancel = () => {
        navigate(`/ProfileForm/${slug}`);  // Navigate back to the profile page or dashboard
    };

    // Dynamic filtering logic for jobs and locations
    const filteredJobs = jobSearch
        ? jobs.filter(job =>
            job.name.toLowerCase().includes(jobSearch.toLowerCase())
        )
        : jobs;

    const filteredLocations = locationSearch
        ? locations.filter(location =>
            location.name.toLowerCase().includes(locationSearch.toLowerCase())
        )
        : locations;

    const toggleDay = (day) => {
        setSchedule(prevSchedule => {
            const dayExists = prevSchedule.some(s => s.day === day);

            if (dayExists) {
                return prevSchedule.map(s =>
                    s.day === day ? { ...s, selected: !s.selected } : s
                );
            } else {
                return [...prevSchedule, { day, selected: true, start: "08:00", end: "17:00" }];
            }
        });
    };

    const validSchedule = Array.isArray(schedule) ? schedule : [];

    const handleHoursChange = (day, type, value) => {
        if (!hasEditedSchedule) {
            // Clear the schedule once when the user tries to edit
            setSchedule([]);
            setHasEditedSchedule(true); // Mark as edited
        }
        setSchedule(prevSchedule => {
            return prevSchedule.map(s =>
                s.day === day ? { ...s, [type]: value } : s
            );
        });
    };

    const mergedSchedule = allDays.map(day => {
        const dayFromDb = schedule.find(s => s.day === day); // Updated schedule state

        console.log("dayFromDbbb", dayFromDb);  // Debug the updated state
        let start = "08:00"; // Default start time
        let end = "";   // Default end time

        if (dayFromDb) {
            start = dayFromDb.start || null; // Use start from DB if available
            end = dayFromDb.end || null;       // Use end from DB if available
        }

        return {
            day,
            selected: dayFromDb ? dayFromDb.selected : false,
            start,
            end
        };
    });

    mergedSchedule.sort((a, b) => allDays.indexOf(a.day) - allDays.indexOf(b.day));


    return (
        <PageContainer>
            <EditProfileContainer>
                <Header>Edit your profile</Header>
                <form onSubmit={handleUpdateProfile}>
                    <label>Edit profile picture</label>
                    <Input
                        type="file"
                        name="profilePicture"
                        accept="image/*"
                        onChange={handleProfilePictureChange}  // Handle image selection
                    />
                    <label>Phone Number</label>
                    <Input
                        type="text"
                        placeholder="Phone Number"
                        value={phoneNumber}
                        disabled  // Make this field non-editable
                    />
                    <label>Email</label>
                    <Input
                        type="email"
                        placeholder="Email"
                        value={email}
                        disabled  // Make this field non-editable
                    />
                    <label>Edit First Name</label>
                    <Input
                        type="text"
                        placeholder="First Name"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                    />
                    <label>Edit Last Name</label>
                    <Input
                        type="text"
                        placeholder="Last Name"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                    />
                    <label>Edit Description</label>
                    <TextArea
                        placeholder="Description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                    />
                    <label>Specific Location</label>
                    <TextArea
                        placeholder="Specific Location"
                        value={specificLocation}
                        onChange={(e) => setspecificLocation(e.target.value|| '')}
                    />

                    <div>
                        <label>Jobs (Select one)</label>
                        <Input
                            type="text"
                            placeholder="Search jobs..."
                            value={jobSearch}
                            onChange={(e) => setJobSearch(e.target.value)}
                        />
                        <CheckboxList>
                            {filteredJobs.map(job => (
                                <CheckboxItem key={job.id}>
                                    <input
                                        type="checkbox"
                                        name="jobSelection" // Ensure all radio buttons share the same name
                                        value={job.name}
                                        checked={selectedJobs.includes(job.name)}
                                        onChange={(e) => handleCheckboxChange(e, 'jobs')}
                                    />
                                    <label>{job.name}</label>
                                </CheckboxItem>
                            ))}
                        </CheckboxList>
                    </div>

                    <div>
                        <label>Locations (Select multiple)</label>
                        <Input
                            type="text"
                            placeholder="Search locations..."
                            value={locationSearch}
                            onChange={(e) => setLocationSearch(e.target.value)}
                        />
                        <CheckboxList>
                            {filteredLocations.map(location => (
                                <CheckboxItem key={location.id}>
                                    <input
                                        type="checkbox"
                                        value={location.name}
                                        checked={selectedLocations.includes(location.name)}
                                        onChange={(e) => handleCheckboxChange(e, 'locations')}
                                    />
                                    <label>{location.name}</label>
                                </CheckboxItem>
                            ))}
                        </CheckboxList>
                    </div>
                    <div>
                        <label>Work Schedule(if you make edit here you should refill your weekly Schedule!)</label>
                        <div>
                            {mergedSchedule.map((s) => (
                                <div key={s.day}>
                                    <input
                                        type="checkbox"
                                        checked={s.selected}
                                        onChange={() => toggleDay(s.day)}
                                        style={{ marginRight: '10px' }}
                                    />
                                    <label>{s.day}</label>
                                    {s.selected && (
                                        <>
                                            <input
                                                type="time"
                                                value={s.start}
                                                onChange={(e) => handleHoursChange(s.day, 'start', e.target.value)}
                                                style={{ marginRight: '10px' }}
                                            />
                                            to
                                            <input
                                                type="time"
                                                value={s.end}
                                                onChange={(e) => handleHoursChange(s.day, 'end', e.target.value)}
                                                style={{ marginRight: '10px' }}
                                            />
                                        </>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                    <Button type="submit">Update Profile</Button>
                    <Button type="button" onClick={handleCancel} style={{ backgroundColor: '#ccc' }}>Cancel</Button>
                </form>
                {message && <Message>{message}</Message>}
            </EditProfileContainer>
        </PageContainer>
    );
};

export default EditProfileForm;
