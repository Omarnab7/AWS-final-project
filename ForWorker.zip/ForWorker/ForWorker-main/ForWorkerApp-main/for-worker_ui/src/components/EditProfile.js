import React, { useState } from 'react';
import axios from 'axios';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

const EditProfile = () => {
    const [profile, setProfile] = useState({
        firstName: '',
        lastName: '',
        address: '',
        contactNumber: '',
        city: '',
        state: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setProfile({ ...profile, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Submit the form data to the server
        axios.post(`${process.env.REACT_APP_API_URL}:5000/api/profile`, profile)
            .then(response => {
                console.log(response.data);
            })
            .catch(error => {
                console.error('There was an error updating the profile!', error);
            });
    };

    return (
        <Box
            component="form"
            sx={{
                '& .MuiTextField-root': { m: 1 },
                padding: '20px',
                border: '1px solid #ccc',
                borderRadius: '5px',
                maxWidth: '600px',
                margin: 'auto',
                textAlign: 'left',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center'
            }}
            noValidate
            autoComplete="off"
            onSubmit={handleSubmit}
        >
            <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Edit Profile</h2>

            <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                <TextField
                    id="first-name"
                    label="First Name"
                    name="firstName"
                    value={profile.firstName}
                    onChange={handleChange}
                    variant="outlined"
                    error={profile.firstName === ''}
                    sx={{ flex: 1, marginRight: '10px' }} // Adjust the margin as needed
                />
                <TextField
                    id="last-name"
                    label="Last Name"
                    name="lastName"
                    value={profile.lastName}
                    onChange={handleChange}
                    variant="outlined"
                    error={profile.lastName === ''}
                    sx={{ flex: 1, marginLeft: '10px' }} // Adjust the margin as needed
                />
            </Box>

            <TextField
                id="address"
                label="Address"
                name="address"
                value={profile.address}
                onChange={handleChange}
                variant="outlined"
                fullWidth
                error={profile.address === ''}
            />
            <TextField
                id="contact-number"
                label="Contact Number"
                name="contactNumber"
                value={profile.contactNumber}
                onChange={handleChange}
                variant="outlined"
                fullWidth
                error={profile.contactNumber === ''}
            />
            <TextField
                id="city"
                label="City"
                name="city"
                value={profile.city}
                onChange={handleChange}
                variant="outlined"
                fullWidth
                error={profile.city === ''}
            />
            <TextField
                id="state"
                label="State"
                name="state"
                value={profile.state}
                onChange={handleChange}
                variant="outlined"
                fullWidth
                error={profile.state === ''}
            />
            <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', marginTop: '20px' }}>
                <Button
                    variant="contained"
                    sx={{ backgroundColor: '#009E9E', '&:hover': { backgroundColor: '#007373' } }}
                    onClick={() => setProfile({
                        firstName: '',
                        lastName: '',
                        address: '',
                        contactNumber: '',
                        city: '',
                        state: ''
                    })}
                >
                    Cancel
                </Button>
                <Button
                    variant="contained"
                    sx={{ backgroundColor: '#009E9E', '&:hover': { backgroundColor: '#007373' } }}
                    type="submit"
                >
                    Save
                </Button>
            </Box>
        </Box>
    );
};

export default EditProfile;
