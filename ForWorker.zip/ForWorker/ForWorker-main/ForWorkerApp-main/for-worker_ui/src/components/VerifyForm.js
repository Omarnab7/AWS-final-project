import React, { useState, useRef, useEffect } from 'react';
import styled from 'styled-components';
import { useNavigate, useLocation } from 'react-router-dom';
import icon1 from './assets/vrfy1.png';
import icon2 from './assets/vrfy2.png';
import icon3 from './assets/vrfy3.png';
import icon4 from './assets/vrfy4.png';
import icon5 from './assets/vrfy5.jpeg';
import AWS from '../Config/awsConfig.js'; // Import AWS configuration

const sns = new AWS.SNS();

// Styled components for the layout and design
const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  text-align: center;
  background: white;
`;

const Title = styled.h2`
  margin-bottom: 20px;
`;

const VerificationContainer = styled.div`
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
`;

const Input = styled.input`
  width: 40px;
  height: 40px;
  margin: 0 5px;
  text-align: center;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const Button = styled.button`
  width: 300px;
  padding: 10px 20px;
  background-color: #fbbd14;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 12px;
`;

const Message = styled.p`
  margin-top: 20px;
  font-size: 16px;
  color: ${(props) => (props.success ? 'green' : 'red')};
`;

const FooterImages = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  width: 100%;
  max-width: 800px;
  margin-top: 500px;
`;

const Image = styled.img`
  height: 50px;
`;

const FooterBase = styled.div`
  width: 100%;
  height: 3px;
  margin-top: 0px;
  background-color: black;
`;

const VerifyForm = () => {
  const [code, setCode] = useState(''); // Store the user input code
  const [generatedCode, setGeneratedCode] = useState(''); // Store the generated random code
  const [message, setMessage] = useState(''); // Store the success/fail message
  const smsSentRef = useRef(false); // Ref to track if SMS has been sent
  const inputRefs = useRef([]); // To handle auto focus on inputs
  const navigate = useNavigate();
  const location = useLocation();
  const { phoneNumber } = location.state || {}; // Get phone number passed from ForgotPasswordForm

  // Generate random 6-digit code
  const generateRandomCode = () => {
    const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
    return randomCode;
  };

  // Effect to generate code and send SMS only once
  useEffect(() => {
    if (!smsSentRef.current) { // Only send SMS if it hasn't been sent
      const randomCode = generateRandomCode();
      setGeneratedCode(randomCode);
      console.log('Generated verification code:', randomCode); // Log the random code to the console
      console.log(phoneNumber);
      sendPasswordResetSMS(phoneNumber, randomCode);
      smsSentRef.current = true; // Mark as sent
    }
  }, [phoneNumber]);

  // Handle input change and auto focus for next input
  const handleChange = (e, index) => {
    const value = e.target.value;
    if (value.length === 1 && index < inputRefs.current.length - 1) {
      inputRefs.current[index + 1].focus();
    }
    const updatedCode = code.split('');
    updatedCode[index] = value;
    setCode(updatedCode.join(''));
  };

  // Handle backspace for auto focus to previous input
  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && !e.target.value && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  // Handle form submission
  const handleVerifyCode = () => {
    if (code === generatedCode) {
      setMessage('Code verified successfully!');
      setTimeout(() => {
        navigate('/ResetPasswordForm', { state: { phoneNumber } }); // Navigate to ResetPasswordForm
      }, 1500);
    } else {
      setMessage('Incorrect verification code.');
    }
  };

  // Function to send SMS using AWS SNS
  const sendPasswordResetSMS = async (phoneNumber, code) => {

    if (phoneNumber.startsWith('0')) {
      // Remove the leading 0 and prepend +972
      phoneNumber = '+972' + phoneNumber.slice(1);
      console.log(phoneNumber);
    }

    /*const params = {
      Message: `Your ForWorker password reset code is: ${code}`,
      PhoneNumber: phoneNumber,
    };*/

    try {
      //const result = await sns.publish(params).promise();
      //console.log('Message sent:', result);
    } catch (error) {
      console.error('Error sending SMS:', error);
    }
  };

  return (
    <Container>
     <img src={icon5} alt="Icon 5" style={{ height: '50px', marginBottom: '10px' }} />
            <Title>Verification</Title>
            <p style={{ fontSize: '12px' }}>Enter the Verification Code Sent to Your Email</p>
      <VerificationContainer>
        {[...Array(6)].map((_, index) => (
          <Input
            key={index}
            type="text"
            maxLength="1"
            onChange={(e) => handleChange(e, index)}
            onKeyDown={(e) => handleKeyDown(e, index)}
            ref={(el) => (inputRefs.current[index] = el)}
          />
        ))}
      </VerificationContainer>
      <Button onClick={handleVerifyCode}>Apply</Button>
      {message && <Message success={code === generatedCode}>{message}</Message>}
            <FooterImages>
                <Image src={icon1} alt="Icon 1" style={{ marginRight: 'auto' }} />
                <Image src={icon2} alt="Icon 2" style={{ marginRight: 'auto' }} />
                <Image src={icon3} alt="Icon 3" style={{ marginRight: '10px', marginLeft: 'auto' }} />
                <Image src={icon4} alt="Icon 4" style={{ marginLeft: '0px' , marginRight:'150px' }} />
            </FooterImages>
      <FooterBase />
    </Container>
  );
};

export default VerifyForm;
