import React from 'react';
import styled from 'styled-components';

const FooterContainer = styled.footer`
  background-color: #0b0f14;
  color: #ffffff;
  padding: 2rem;
  text-align: left;
  display: flex;
  flex-direction: column;
`;

const FooterTop = styled.div`
  margin-bottom: 1.5rem;
  text-align: center;
`;

const FooterCategories = styled.div`
  display: flex;
  justify-content: center;
  gap: 10rem;
  flex-wrap: wrap;
`;

const FooterSection = styled.div`
  margin: 0.5rem 0;
`;

const FooterTitle = styled.h4`
  margin-bottom: 0.5rem;
  font-weight: bold;
  color: #ffffff;
`;

const FooterLink = styled.a`
  color: #ffffff;
  text-decoration: none;
  margin-bottom: 0.3rem;
  display: block;

  &:hover {
    text-decoration: underline;
  }
`;

const Footer = () => {
  return (
    <FooterContainer>
      <FooterTop>
        <p>&copy; {new Date().getFullYear()} FOR<span className="bold">WORKER.</span> All Rights Reserved.</p>
      </FooterTop>
      <FooterCategories>
        <FooterSection>
          <FooterTitle>Product</FooterTitle>
          <FooterLink href="/about-us">About</FooterLink>
          <FooterLink href="#">Team</FooterLink>
        </FooterSection>
        <FooterSection>
          <FooterTitle>Support</FooterTitle>
          <FooterLink href="#">How it works</FooterLink>
          <FooterLink href="#">Trust & Safety</FooterLink>
          <FooterLink href="#">Help Centre</FooterLink>
        </FooterSection>
        <FooterSection>
          <FooterTitle>Discover</FooterTitle>
          <FooterLink href="#">Blog</FooterLink>
          <FooterLink href="#">Careers</FooterLink>
          <FooterLink href="#">Contact</FooterLink>
        </FooterSection>
      </FooterCategories>
    </FooterContainer>
  );
};

export default Footer;
