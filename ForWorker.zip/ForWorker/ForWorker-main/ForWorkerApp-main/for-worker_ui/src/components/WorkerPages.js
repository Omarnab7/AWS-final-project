import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import WorkerImage from './assets/LORELLE.jpeg';
import WorkerService from "../services/worker.service";

// Styled Components
const PageContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between; /* Ensure content fills available space */
  padding: 20px;
  background-color: #ffffff;
  min-height: 100vh;
  max-width: 1200px;
  margin: 0 auto;
`;



const Header = styled.h1`
  font-size: 18px;
  margin-bottom: 20px;
  font-weight: normal;
  text-align: center;
`;

const ContentWrapper = styled.div`
  flex-grow: 1; /* Allows content to grow and take up space */
  display: flex;
  gap: 40px;
  align-items: flex-start;
`;

const LeftSection = styled.div`
  display: flex;
  flex-direction: column;
  width: 200px;
`;

const FilterSection = styled.div`
  margin-bottom: 20px;
`;

const FilterTitle = styled.h2`
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 50px;
  border-bottom: 2px solid black;
  padding-bottom: 5px;
`;

const FilterDropdown = styled.select`
  font-size: 14px;
  margin-bottom: 10px;
  padding: 5px;
  width: 100%;
  cursor: pointer;
  border: none;
  background-color: transparent;
  outline: none;
`;

const DropdownWrapper = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  margin-top: 8px;
`;

const DropdownLabel = styled.label`
  font-size: 14px;
  font-weight: bold;
  margin-right: 10px;
`;

const Dropdown = styled.select`
  padding: 8px;
  font-size: 14px;
  width: 150px;
`;

const WorkerGridWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const WorkerGridHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-start;
  margin-bottom: 20px;
`;

const WorkerGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  width: 100%;
`;

const WorkerCard = styled.div`
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
  transition: transform 0.3s ease;
  cursor: pointer;
  background-color: #fff;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-width: 250px;
  height: 300px;

  &:hover {
    transform: translateY(-5px);
  }
`;

const WorkerImageStyled = styled.img`
  width: 100%;
  height: 60%;
  object-fit: cover;
`;

const WorkerInfo = styled.div`
  padding: 10px;
`;

const WorkerName = styled.h3`
  font-size: 14px;
  margin: 0;
  font-weight: bold;
  text-transform: capitalize;
`;

const WorkerRating = styled.span`
  float: right;
  font-size: 14px;
  color: #f0c14b;
`;

const WorkerDescription = styled.p`
  font-size: 12px;
  color: #666;
  margin-top: 5px;
  line-height: 1.4;
`;

const PaginationWrapper = styled.div`
  display: flex;
  justify-content: center;
  margin-top: auto; /* Push pagination to the bottom */
  padding: 20px;
  background-color: #f9f9f9; /* Background color for pagination section */
  width: 100%;
  box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
`;

const PaginationButton = styled.button`
  margin: 0 5px;
  padding: 10px 15px;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  background-color: ${(props) => (props.active ? '#FFD700' : '#f0f0f0')};
  border: ${(props) => (props.active ? '2px solid #FFD700' : '1px solid #ddd')};
  border-radius: 4px;
  color: ${(props) => (props.active ? '#000' : '#333')};
  transition: background-color 0.3s ease, border 0.3s ease;

  &:hover {
    background-color: #ddd;
  }
`;

const ArrowButton = styled(PaginationButton)`
  background-color: #fff;
  border: none;
  color: #000;
  font-size: 18px;
`;

const WorkerPages = () => {
    const { categoryName } = useParams(); // Get category from URL
    const [workers, setWorkers] = useState([]); // Store workers data
    const [currentPage, setCurrentPage] = useState(1);
    const [originalWorkers, setOriginalWorkers] = useState([]);
    const workersPerPage = 8;
    const [sortOrder, setSortOrder] = useState('recommended'); // State to manage sorting order, default is 'recommended'
    const [locations, setLocations] = useState([]);  // State to hold location data
    const [professions, setProfessions] = useState([]);
    const [selectedProfession, setSelectedProfession] = useState("");
    const [selectedLocation, setSelectedLocation] = useState("");



    const navigate = useNavigate(); // <-- Initialize useNavigate

    useEffect(() => {
        // Fetch workers from backend when the category changes
        const fetchWorkers = async () => {
            setWorkers([]); // Set empty workers
            setOriginalWorkers([]);

            try {
                const response = await WorkerService.workersByCategory(categoryName);
                if (response.status !== 200) {
                    throw new Error(response.data.message || 'Failed to fetch workers');
                }

                    setWorkers(response.data.workers);
                    setOriginalWorkers(response.data.workers);

                // Extract professions
            const extractedProfessions = new Set();
            response.data.workers.forEach(worker => {
                worker.jobs.forEach(job => extractedProfessions.add(job.job));
            });
            setProfessions([...extractedProfessions]);

                console.log("this is worker data", response.data.workers);
            } catch (error) {
                console.error("Error fetching worker profiles:(for now this is not an error there no workers in this category)", error);
            }
        };

        const fetchLocations = async () => {
          try {
              const response = await WorkerService.getlocations();
              if (response.status !== 200) {
                  throw new Error(response.data.message || 'Failed to fetch locations');
              }
              setLocations(response.data.map(location => location.name));
          } catch (error) {
              console.error("Error fetching locations:", error);
          }
        };


        fetchWorkers();
        fetchLocations();
    }, [categoryName]);

    // Sorting and filtering logic
    useEffect(() => {
      let filteredWorkers = [...originalWorkers];

      // Apply profession filter if selected
      if (selectedProfession) {
          filteredWorkers = filteredWorkers.filter(worker => 
              worker.jobs.some(job => job.job === selectedProfession));
      }

      // Apply location filter if selected
      if (selectedLocation && selectedLocation !== "all") {
          filteredWorkers = filteredWorkers.filter(worker =>
              worker.locations.some(location => location === selectedLocation));
      }

      // Apply sort order
      if (sortOrder === 'highestRated') {
          filteredWorkers.sort((a, b) => b.worker.profile?.rate - a.worker.profile?.rate);
      } else if (sortOrder === 'lowestRated') {
          filteredWorkers.sort((a, b) => a.worker.profile?.rate - b.worker.profile?.rate);
      }

      setWorkers(filteredWorkers);
  }, [selectedProfession, selectedLocation, sortOrder, originalWorkers]);

  const handleSortChange = (event) => {
    setSortOrder(event.target.value);
  };


  const handleProfessionChange = (event) => {
    const newSelectedProfession = event.target.value;
    setSelectedProfession(newSelectedProfession);
  };

  const handleLocationChange = (event) => {
    const newSelectedLocation = event.target.value;
    setSelectedLocation(newSelectedLocation);
  };




    const indexOfLastWorker = currentPage * workersPerPage;
    const indexOfFirstWorker = indexOfLastWorker - workersPerPage;
    const currentWorkers = workers.slice(indexOfFirstWorker, indexOfLastWorker);



    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    // Function to handle card click and navigate to the worker's profile
    const handleCardClick = (slug) => {
        navigate(`/publicProfile/${slug}`); // Navigate to the worker's public profile using their slug
    };

    return (
        <PageContainer>
            <Header>Workers in {categoryName} Category</Header>
            <ContentWrapper>
                <LeftSection>
                    <FilterSection>
                        <FilterTitle>Filters</FilterTitle>
                        <FilterDropdown onChange={handleLocationChange} value={selectedLocation}>
                        <option value="all">All Locations</option>
                          {locations.map((location, index) => (
                            <option key={index} value={location}>{location}</option>
                            ))}
                        </FilterDropdown>
                        
                        <FilterDropdown onChange={handleProfessionChange} value={selectedProfession}>
                          <option value="">All Professions</option>
                          {professions.map((profession, index) => (<option key={index} value={profession}>{profession}</option>))}
                        </FilterDropdown>
                    </FilterSection>
                </LeftSection>
                <WorkerGridWrapper>
                    <WorkerGridHeader>
                        <DropdownWrapper>
                            <Dropdown onChange={handleSortChange}>
                                <option value="recommended">Recommended</option>
                                <option value="highestRated">Highest Rated</option>
                                <option value="lowestRated">Lowest Rated</option>
                            </Dropdown>
                        </DropdownWrapper>
                    </WorkerGridHeader>
                    <WorkerGrid>
                        {workers && workers.length > 0 ? (
                            workers.map((workerObj, index) => {
                                const profileDescription = workerObj.worker.profile?.description || 'No description available';
                                const { firstName, lastName } = workerObj.worker;
                                const slug = workerObj.worker.profile?.slug;
                                const jobName = workerObj.jobs[0]?.job;

                                return (
                                    <WorkerCard key={index} onClick={() => slug && handleCardClick(slug)}>
                                        <WorkerImageStyled src={workerObj.worker.profilePicture || WorkerImage} alt="Worker" />
                                        <WorkerInfo>
                                            <WorkerName>
                                                {firstName} {lastName} <WorkerRating>({workerObj.worker.profile?.rate ? `${workerObj.worker.profile.rate}/5` : 'No Rating'})</WorkerRating>
                                            </WorkerName>
                                            <WorkerDescription><strong>Job: </strong>{jobName || 'No Job Listed'}</WorkerDescription>
                                            <WorkerDescription>{profileDescription}</WorkerDescription>
                                        </WorkerInfo>
                                    </WorkerCard>
                                );
                            })
                        ) : (
                            <p>No workers in this category for now.</p>
                            )}


                    </WorkerGrid>
                </WorkerGridWrapper>
            </ContentWrapper>
            <PaginationWrapper>
                <ArrowButton onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1}>
                    &laquo;
                </ArrowButton>
                {Array.from({ length: Math.ceil(workers.length / workersPerPage) }, (_, index) => (
                    <PaginationButton
                        key={index + 1}
                        onClick={() => paginate(index + 1)}
                        active={currentPage === index + 1}
                    >
                        {index + 1}
                    </PaginationButton>
                ))}
                <ArrowButton
                    onClick={() => paginate(currentPage + 1)}
                    disabled={currentPage === Math.ceil(workers.length / workersPerPage)}
                >
                    &raquo;
                </ArrowButton>
            </PaginationWrapper>
        </PageContainer>
    );
};

export default WorkerPages;
