import React, { useEffect, useState } from 'react';
import { EyeInvisibleOutlined, EyeOutlined } from "@ant-design/icons";
import WorkerDataService from "../services/worker.service";
import ResetPassword from "./ResetPassword";
import ForgetPassword from "./ForgetPassword";

const Login = () => {
    const [phoneNumber, setPhoneNumber] = useState('');
    const [phoneNumberExists, setPhoneNumberExists] = useState(false);
    const [password, setPassword] = useState('');
    const [visible, setVisible] = useState(false);
    const [loginMessage, setLoginMessage] = useState('');

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (name === 'phonenumber') {
            setPhoneNumber(value);
        } else if (name === 'password') {
            setPassword(value);
        }
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await WorkerDataService.checkPhoneNumberExists(phoneNumber);
            if (response.data) {
                setLoginMessage('Login successful!');
            } else {
                setLoginMessage(`Phone number ${phoneNumber} does not exist`);
            }
        } catch (error) {
            if (error.response && error.response.status === 404) {
                setLoginMessage(`Phone number ${phoneNumber} does not exist`);
            } else {
                console.error('Error checking phone number:', error);
                setLoginMessage('Error checking phone number. Please try again.');
            }
        }
    };

    useEffect(() => {
        document.title = 'Login';
    }, []);

    return (
        <div style={{ maxWidth: '300px', margin: 'auto' }}>
            <h1 className="mb-3 text-center" style={{ color: '#1a1a1a' }}>Log in</h1>
            <form action="/submit" className="mb-3" onSubmit={handleLogin} method="post">
                <div className="form-group">
                    <label htmlFor="Phone" style={{ color: '#1a1a1a', display: 'block', marginBottom: '0.5rem' }}>Phone:</label>
                    <input
                        type="tel"
                        className="form-control"
                        placeholder="05*-*******"
                        name="phonenumber"
                        id="Phone"
                        value={phoneNumber}
                        onChange={handleInputChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', boxSizing: 'border-box' }}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password" style={{ color: '#1a1a1a', display: 'block', marginBottom: '0.5rem' }}>Password:</label>
                    <input
                        type={visible ? "text" : "password"}
                        className="form-control"
                        placeholder="Enter your password"
                        name="password"
                        id="password"
                        value={password}
                        onChange={handleInputChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', boxSizing: 'border-box' }}
                    />


                </div>
                <button type="submit" className="btn btn-primary btn-block" style={{ backgroundColor: 'rgb(0, 158, 158)', width: '100%', padding: '0.75rem' }}>Login</button>
                {loginMessage && <p style={{ color: 'red', marginTop: '1rem' }}>{loginMessage}</p>}
            </form>
            <div className="text-center">
                <p style={{ color: '#1a1a1a' }}>or</p>
                <a href="./Register" className="btn btn-success" style={{ backgroundColor: 'rgb(179, 131, 10)', width: '100%', padding: '0.75rem', marginBottom: '1rem' }}>Create account</a>
                <p className="small">
                    <a href="./ForgetPassword">Have you forgotten your account details?</a>
                </p>
            </div>
        </div>
    );
};

export default Login;
