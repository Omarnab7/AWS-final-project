import React, { useEffect, useState } from 'react';
import { EyeInvisibleOutlined, EyeOutlined } from "@ant-design/icons";

const AdminLogin = () => {
    const [formData, setFormData] = useState({
        username: '', Password: '',

    });

    function handleClick() {
        //please read more about it maybe we will not use it
        // Handle click event here
    }

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            formData, [name]: value,
        });
    };

    const [showPassword, setShowpassword] = useState(false);
    const [visible, setVisible] = useState(false);

    const handleLogin = (e) => {
        if (e.username && e.password) {
            // Submit the data to the backend for authentication in the future should be between 1 dec
        } else {
            alert('Both fields are required!');
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        console.log('Form data submitted:', formData);
    };

    useEffect(() => {
        document.title = 'Login for admin';
    }, []);

    return (<div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <div style={{ width: '100%', maxWidth: '400px' }}>
            <h1 className="mb-3 text-center" style={{ color: '#1a1a1a' }}>Log in Admin</h1>
            <form action="/submit" className="mb-3" onSubmit={handleSubmit} method="post">
                <div className="form-group">
                    <label htmlFor="username" style={{ color: '#1a1a1a' }}>username:</label>
                    <input
                        type="tel"
                        className="form-control"
                        placeholder="username"
                        name="username"
                        id="username"
                        value={formData.username}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password" style={{ color: '#1a1a1a' }}>Password:</label>
                    <input
                        type={visible ? "text" : "password"}
                        className="form-control"
                        placeholder="enter your password"
                        name="password"
                        id="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        required
                    />
                    <div style={{ cursor: 'pointer'/*, position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)'*/ }} onClick={() => setVisible(!visible)}>
                        {visible ? <EyeOutlined /> : <EyeInvisibleOutlined />}
                    </div>
                </div>
                <button onClick={handleClick} type="submit" className="btn btn-primary btn-block" style={{ backgroundColor: 'rgb(0, 0, 0)' }}>Login</button>
            </form>
            <div className="text-center">
                <p style={{ color: '#1a1a1a' }}>or</p>
                <p className="small">
                    <a href="#">Have you forgotten your account details?</a>
                </p>
            </div>
        </div>
    </div>);
};

export default AdminLogin;
