import React, { useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import WorkerDataService from "../services/worker.service";

const PageContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f9f9f9;
`;

const ForgotPasswordContainer = styled.div`
  width: 50%;
  max-width: 400px;
  margin: 50px auto;
  text-align: center;
  border: none;
  padding: 20px;
`;

const Input = styled.input`
  width: 100%;
  margin-top: 20px;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  box-sizing: border-box;
`;

const Button = styled.button`
  width: 100%;
  margin-top: 20px;
  padding: 10px;
  background-color: #fbbd14;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  color: #000;
`;

const Header = styled.h2`
  margin-bottom: 30px;
  font-weight: bold;
  font-size: 24px;
  color: #333;
`;

const ForgotPasswordForm = () => {
    const [phoneNumber, setPhoneNumber] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    const handleInputChange = (e) => {
        setPhoneNumber(e.target.value);
    };

    const handleForgetPassword = async (e) => {
        e.preventDefault();
        setSuccessMessage('');
        setErrorMessage('');

        try {
            const response = await WorkerDataService.checkPhoneNumberExists(phoneNumber);
            if (response.data.exists) {
                setSuccessMessage('Phone number is registered! Proceeding to reset password...');
                setTimeout(() => {
                    navigate('/VerifyForm', { state: { phoneNumber } });
                }, 1500);
            } else {
                setErrorMessage(`Phone number ${phoneNumber} does not exist.`);
            }
        } catch (error) {
            if (error.response && error.response.status === 404) {
                setErrorMessage(`Phone number ${phoneNumber} does not exist.`);
            } else {
                console.error('Error checking phone number:', error);
                setErrorMessage('Error checking phone number. Please try again.');
            }
        }
    };

    return (
        <PageContainer>
            <ForgotPasswordContainer>
                <Header>Reset your password</Header>
                <form onSubmit={handleForgetPassword}>
                    <Input
                        type="tel"
                        placeholder="Enter your Phone Number"
                        value={phoneNumber}
                        onChange={handleInputChange}
                    />
                    <Button type="submit">Reset</Button>
                </form>
                <div>
                    {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
                    {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
                </div>
            </ForgotPasswordContainer>
        </PageContainer>
    );
};

export default ForgotPasswordForm;
