import React, { Component } from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import NewHeader from './components/NewHeader';
import LoginForm from './components/LoginForm';
import NewFooter from './components/NewFooter';
import SignupForm from './components/SignupForm';
import ReviewPage from './components/ReviewPage';
import VerifyForm from './components/VerifyForm';
import ForgotPasswordForm from './components/ForgotPasswordForm';
import ResetPasswordForm from './components/ResetPasswordForm';
import ProfileForm from './components/ProfileForm';
import NotfictionPage from './components/NotfictionPage';
import EditProfileForm from "./components/EditProfileForm";
import Dashboard from './components/Dashboard';
import CategoriesForm from './components/CategoriesForm';
import WorkerPages from "./components/WorkerPages";
import styled from 'styled-components';
import background1 from './components/assets/1.png';
import background2 from './components/assets/2.png';
import background3 from './components/assets/3.png';
import background4 from './components/assets/4.png';
import background5 from './components/assets/5.png';
import background6 from './components/assets/6.png';
import LogoBrowser from './components/assets/BrowserLogo.png';
import CompleteProfile from './components/CompleteProfile';


import { AuthProvider } from './context/AuthContext';
import AboutUs from "./components/AboutUs";


const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`;

const BackgroundContainer = styled.div`
  position: relative;
  width: 100%;
  flex-grow: 1;
  background-color: #fff;
  display: flex;
  flex-direction: column;

  &::before {
    content: '';
    position: absolute;
    top: 20px;
    left: 200px;
    background: url(${background1}) no-repeat;
    width: 100.6px;
    height: 100.59px;
    background-size: cover;
  }

  &::after {
    content: '';
    position: absolute;
    top: 20px;
    right: 200px;
    background: url(${background4}) no-repeat;
    width: 100.6px;
    height: 100.59px;
    background-size: cover;
  }

  .middle-left {
    position: absolute;
    top: 50%;
    left: 20px;
    transform: translateY(-50%);
    background: url(${background2}) no-repeat;
    width: 100.6px;
    height: 100.59px;
    background-size: cover;
  }

  .bottom-left {
    position: absolute;
    bottom: 20px;
    left: 200px;
    background: url(${background3}) no-repeat;
    width: 100.6px;
    height: 100.59px;
    background-size: cover;
  }

  .middle-right {
    position: absolute;
    top: 50%;
    right: 20px;
    transform: translateY(-50%);
    background: url(${background5}) no-repeat;
    width: 100.6px;
    height: 100.59px;
    background-size: cover;
  }

  .bottom-right {
    position: absolute;
    bottom: 20px;
    right: 200px;
    background: url(${background6}) no-repeat;
    width: 100.6px;
    height: 100.59px;
    background-size: cover;
  }
`;

const Content = styled.main`
  flex-grow: 1;
  overflow-y: auto;
  position: relative;
`;

class App extends Component {
    componentDidMount() {
        const link = document.querySelector("link[rel*='icon']") || document.createElement('link');
        link.type = 'image/png';
        link.rel = 'icon';
        link.href = LogoBrowser;
        document.getElementsByTagName('head')[0].appendChild(link);
    }

    render() {
        return (
    <AuthProvider>
            <Router>
                <AppContainer>
                    <NewHeader />
                    <BackgroundContainer>
                        <div className="middle-left"></div>
                        <div className="bottom-left"></div>
                        <div className="middle-right"></div>
                        <div className="bottom-right"></div>
                        <Content>
                            <Routes>
                                <Route path="/" element={<CategoriesForm />} />
                                <Route path="/LoginForm" element={<LoginForm />} />
                                <Route path="/SignupForm" element={<SignupForm />} />
                                <Route path="/VerifyForm" element={<VerifyForm />} />
                                <Route path="/dashboard" element={<Dashboard />} />
                                <Route path={"ReviewPage"} element ={<ReviewPage/>}/>
                                <Route path="/ForgotPasswordForm" element={<ForgotPasswordForm />} />
                                <Route path="/ResetPasswordForm" element={<ResetPasswordForm />} />
                                <Route path="/publicProfile/:slug" element={<ProfileForm />} />
                                <Route path="/ProfileForm/:slug" element={<ProfileForm />} />
                                <Route path="/workers/:categoryName" element={<WorkerPages />} />
                                <Route path="/review/:serialNumber" element={<ReviewPage/>} />
                                <Route path="/complete-profile" element={<CompleteProfile />} />
                                <Route path="/EditProfileForm" element={<EditProfileForm />} />
                                <Route path="/CategoriesForm" element={<CategoriesForm />} />
                                <Route path="/about-us" element={<AboutUs />} />
                                <Route path="/NotfictionPage" element ={<NotfictionPage/>}/>
                                <Route path="/WorkerPages" element={<WorkerPages />} />
                                <Route path="/RatingForm" element={<WorkerPages />} />
                                {/* Add more routes as needed */}
                            </Routes>
                        </Content>
                    </BackgroundContainer>
                    <NewFooter />
                </AppContainer>
            </Router>
        </AuthProvider>
        );
    }
}

export default App;
