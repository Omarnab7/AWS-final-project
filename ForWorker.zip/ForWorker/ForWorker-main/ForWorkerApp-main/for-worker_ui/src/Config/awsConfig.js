const AWS = require('aws-sdk');

// Update AWS configuration
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID || "AKIA5QP6RU44TATYMZB5",
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "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",
  region: process.env.AWS_REGION || "us-east-1"
});

module.exports = AWS;
