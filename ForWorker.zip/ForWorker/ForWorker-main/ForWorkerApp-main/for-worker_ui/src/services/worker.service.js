import http from "../http-common";

class WorkerDataService {
    getAll() {
        return http.get("/workers");
    }

    get(id) {
        return http.get(`/workers/${id}`);
    }

    create(data) {
        return http.post("/workers", data);
    }

    completeProfile(data) {
        return http.post("/complete-profile", data);
    }

    update(id, data) {
        return http.put(`/workers/${id}`, data);
    }

    delete(id) {
        return http.delete(`/workers/${id}`);
    }

    deleteAll() {
        return http.delete(`/workers`);
    }

    findByFirstName(firstName) {
        return http.get(`/workers?firstName=${firstName}`);
    }
    // New method to check if a phone number exists
    checkPhoneNumberExists(phoneNumber) {
        return http.get(`/workers/${phoneNumber}`);
    }
    login(data) {
        return http.post("/login",data);
    }

    workersByCategory(category) {
        return http.get(`/profiles/category/${category}`);
    }

    // Get sorted workers by category
    sortedWorkers(categoryName) {
        return http.get(`/workers/sorted-by-rate/${categoryName}`);
    }

    getjobs(){
        return http.get("/jobs");
    }

    getlocations(){
        return http.get("/locations");
    }
    resetPassword(phoneNumber, password) {
        return http.put("/reset-password", { phoneNumber, password });
    }

    resetPasswordUnauth(phoneNumber, password) {
        return http.put("/reset-password-unauth", { phoneNumber, password });
    }

    submitRequest(data) {
        return http.post("/createRequest", data);
    }


}

export default new WorkerDataService();
