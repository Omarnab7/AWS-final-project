const jwt = require('jsonwebtoken');
const db = require("../db/models");
const Worker = db.worker;
const Profile = db.profile;
const WorkerJobs =db.workerjob;
const WorkerLocation = db.workerLocation;
const Location = db.location;

const currentUser = async (req, res, next) => {
    console.log('auth begin', req);
    const token = req.header('Authorization')?.replace('Bearer ', '');

    if (!token) {
        return res.status(401).send({ error: 'Authentication required' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Retrieve the worker along with their profile data (rate, description)
        const worker = await Worker.findOne({
            where: { phoneNumber: decoded.phoneNumber },
            attributes: ['firstName', 'lastName', 'phoneNumber', 'email', 'profilePicture'], // Exclude the password
            include: [{
                model: Profile, // Include Profile data related to the worker
                attributes: ['rate', 'description','specificLocation','images','schedule'], // Select the rate and description from the Profile
                required: false, // Optional, if the worker might not have a profile
            },
                {
                    model:WorkerJobs,
                    attributes:['jobName'],
                    required:false,
                },

                {
                    model: Location, // Use Location model directly through WorkerLocation join table
                    through: WorkerLocation, // Use WorkerLocation as the join table
                    attributes: ['name'], // Fetch the location name
                    required: false,
                }
        ]
        });

        if (!worker) {
            return res.status(404).send({ error: 'Worker not found - auth' });
        }
        // Attach worker and profile data to the request object
        req.user = worker;
        console.log('auth', req.user);
        next(); // Proceed to the next middleware or route handler
    } catch (error) {
        console.error('Authentication error:', error);
        return res.status(401).send({ error: 'Please authenticate' });
    }
};

module.exports = currentUser;

