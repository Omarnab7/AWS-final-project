const AWS = require('aws-sdk');
const multer = require('multer');
const multerS3 = require('multer-s3');
const path = require('path');

// AWS S3 configuration
const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION,
    //bucket: process.env.AWS_S3_BUCKET_NAME
});

// Multer S3 upload middleware
const uploadToS3 = multer({
    storage: multerS3({
        s3: s3,
        //bucket: process.env.AWS_S3_BUCKET_NAME, // S3 bucket name
	bucket: 'forworkerbucket',
      //  acl: 'public-read', // Make uploaded files publicly readable
        key: (req, file, cb) => {
            const fileName = `${Date.now()}_${path.basename(file.originalname)}`;
            cb(null, fileName); // File will be saved in S3 with this name
        },
    }),
    limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB file size limit
    fileFilter: (req, file, cb) => {
        const allowedFileTypes = /jpeg|jpg|png/;
        const extname = allowedFileTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedFileTypes.test(file.mimetype);

        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed!'));
        }
    },
});

module.exports = { uploadToS3 };

