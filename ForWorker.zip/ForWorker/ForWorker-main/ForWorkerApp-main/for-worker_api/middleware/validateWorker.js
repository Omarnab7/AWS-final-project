// middleware/validateWorker.js
const validateWorker = (req, res, next) => {
    const { phoneNumber, email } = req.body;

    // Check if phoneNumber is 10 digits
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phoneNumber)) {
        return res.status(400).send({
            message: "Phone number must be exactly 10 digits."
        });
    }

    // Check if email is valid
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("format is incorrect!")
        return res.status(400).send({
            message: "Invalid email format."
        });
    }
    
    // If both checks pass, proceed to the next middleware/controller
    next();
};

module.exports = validateWorker;
