// middleware/validationMiddleware.js

const validateSignupData = (req, res, next) => {
    const { firstName, lastName, email, password, confirmPassword } = req.body;
    const errors = {};
    if (!firstName) errors.firstName = 'First Name is required';
    if (!lastName) errors.lastName = 'Last Name is required';
    if (!email) errors.email = 'Email is required';
    if (!password) errors.password = 'Password is required';
    if (password !== confirmPassword) errors.confirmPassword = 'Passwords do not match';
    if (Object.keys(errors).length > 0) {
        return res.status(400).json({ errors });
    }
    next();
};
module.exports = {
    validateSignupData
};
