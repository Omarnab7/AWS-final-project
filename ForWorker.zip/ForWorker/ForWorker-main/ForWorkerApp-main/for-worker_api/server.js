const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express(); // Init the server
const uploadS3Route = require('./routes/uploadS3Route');
require('dotenv').config();

const db = require("./db/models");
const workerRoutes = require("./routes/workerRoutes");
const dataRoutes = require('./routes/dataRoutes');  // Import the new route

const PORT = 8080;

// Configure CORS to allow requests from your frontend
app.use(cors({
    origin: `${process.env.API_URL}:3000`, // Replace with your frontend's origin
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true, // Allow credentials (e.g., cookies, authorization headers)
}));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Use the worker routes
app.use('/api', workerRoutes);
// Use the data routes
app.use('/api', dataRoutes);

app.use('/uploads3', uploadS3Route);


db.sequelize.sync().then(() => {
    app.listen(PORT, () => {
        console.log(`server running on port ${PORT}.`);
    });
});
