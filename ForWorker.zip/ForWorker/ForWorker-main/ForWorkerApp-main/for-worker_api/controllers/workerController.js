const db = require("../db/models");
const Worker = db.worker;
const Profile = db.profile;
const WorkerJob = db.workerjob;
const Customer = db.Customer;
const JobCategory = db.jobCategory;
const Category = db.category;
const WorkerLocation = db.workerLocation;
const OrderService =db.OrderService;
const Review=db.review;
const Job = db.job;
const Location = db.location;
const notification = db.notification;
const Op = db.Sequelize.Op;
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid'); // Import UUID generator

// Import the validation middleware
const validateWorker = require('../middleware/validateWorker');
const {Sequelize} = require("sequelize");


exports.editNotificationDate = async(req,res)=> {
    try {
        const { editNotificationId } = req.params;  // Get the ID from the URL params
        const { date } = req.body;
        console.log("editNotificationId",editNotificationId);
        const notifications = await notification.findOne({
            where: {id: editNotificationId}
            , attributes: ['id','startDate'],
        });
        notifications.startDate = date;
        await notifications.save();


    }catch (error) {
        console.error('Error fetching notificationUpdateDate:', error);
        res.status(500).json({ message: 'Server error. Unable to update on  Notification.' });
    }




};

exports.updateWorkerRate= async (req, res) => {
    try {
        const { phoneNumber } = req.body;
        // Fetch reviews associated with the worker's phone number

        const reviews = await Review.findAll({
            where: { workerPhoneNumber:phoneNumber ,reviewed:1 }, // Filter by worker's phone number
            attributes: ['description', 'professionalism', 'reliability', 'availability','showName'], // Review details
        });
        let x= 0;
        let avg = 0;

        reviews.forEach(review => {
            x = x + (review.dataValues.professionalism + review.dataValues.reliability + review.dataValues.availability)/3 ;
        });

        avg = (x/reviews.length);

            const profile = await Profile.findOne({
            where:{workerPhoneNumber:phoneNumber },
        });

        profile.rate = avg;

        await profile.save();




        // Log for debugging purpose
        // Return the reviews as a JSON response
        res.status(200).json(reviews);
    } catch (error) {
        console.error('Error fetching reviews:', error);
        res.status(500).json({ message: 'Server error. Unable to fetch reviews.' });
    }
};

exports.updateRate = async(req,res)=>{
    const { phoneNumber, averageRank } = req.body;

    try {
        // Find the profile by workerPhoneNumber (phoneNumber)
        const profile = await Profile.findOne({
            where: { workerPhoneNumber: phoneNumber },
        });

        if (!profile) {
            return res.status(404).json({ message: "Profile not found" });
        }

        // Update the rate field with the average rank
        profile.rate = averageRank;

        // Save the updated profile
        await profile.save();

        return res.status(200).json({ message: 'Rate updated successfully' });
    } catch (error) {
        console.error('Error updating rate:', error);
        return res.status(500).json({ message: 'Server error' });
    }


};
//##################################### new
exports.getWorkersByCategoryAndJob = async (req, res) => {
    const { categoryName } = req.params; // Get category from URL params
    const { jobName } = req.query; // Get job name from query params

    try {
        // Filter workers based on category and job
        const workers = await Worker.findAll({
            include: [
                {
                    model: Profile,
                    as: 'profile', // Ensure alias matches your setup
                    attributes: ['description', 'rate', 'slug', 'profilePicture']
                },
                {
                    model: Job,
                    as: 'jobs', // Ensure alias matches your setup
                    where: jobName
                        ? { name: { [Op.like]: `%${jobName}%` } } // Match job name if provided
                        : {},
                    through: { attributes: [] } // Exclude junction table attributes
                },
                {
                    model: Category,
                    as: 'categories', // Ensure alias matches your setup
                    where: { name: { [Op.like]: `%${categoryName}%` } }, // Match category name
                    through: { attributes: [] }
                }
            ]
        });

        if (!workers || workers.length === 0) {
            return res.status(404).json({ message: 'No workers found matching your criteria.' });
        }

        res.status(200).json({ workers });
    } catch (error) {
        console.error('Error fetching workers:', error);
        res.status(500).json({ message: 'An error occurred while fetching workers.', error });
    }
};




exports.getWorkersByLocationAndCategory = async (req, res) => {
    try {
        const { locationName } = req.query;
        const { categoryName } = req.params;

        if (!locationName || !categoryName) {
            return res.status(400).json({ message: "Location and category are required." });
        }

        const workers = await Worker.findAll({
            include: [
                {
                    model: Profile,
                    attributes: ['slug', 'rate', 'description', 'profilePicture'], // Include necessary fields
                },
                {
                    model: Location,
                    through: WorkerLocation,
                    where: { name: locationName }, // Filter by location
                    attributes: ['name'],
                },
                {
                    model: Job,
                    through: WorkerJob,
                    where: { categoryName }, // Filter by category
                    attributes: ['name'],
                },
            ],
        });

        if (workers.length === 0) {
            return res.status(404).json({ message: "No workers found for the given location and category." });
        }

        res.status(200).json({ workers });
    } catch (error) {
        console.error("Error fetching workers by location and category:", error);
        res.status(500).json({ message: "An error occurred while fetching workers." });
    }
};


//##################################### new






exports.SortingWorkersByReview = async (req, res) => {
    try {
        const { categoryName } = req.params;
        console.log('Category Name:', req.params.categoryName);

        const category = await Category.findOne({
            where: { name: categoryName }, // Find the specific category by name
            include: [{
                model: Job,
                include: [{
                    model: WorkerJob, // WorkerJob is the junction table
                    include: [{
                        model: Worker,
                        include: [{
                            model: Profile, // Include the Profile model where rate is located
                        }],
                    }],
                }],
            }],
        });

        if (!category) {
            return res.status(404).json({ message: 'Category not found' });
        }

        const workers = category?.jobs?.flatMap(job =>
            job.workerJobs?.map(workerJob => ({
                worker: workerJob.worker,
                profile: workerJob.worker?.profile, // Ensure worker and profile exist
                rate: workerJob.worker?.profile?.rate || 0, // Ensure rate exists or default to 0
                jobs: workerJob.worker?.workerJobs?.map(wj => ({
                    job: wj.job?.name || 'Unknown Job', // Ensure job name exists or fallback
                    categories: wj.job?.categories?.map(category => category.name) || [] // Safely access categories, fallback to empty array
                })) || [] // Default to empty array if workerJobs is not defined
            })) || [] // Default to empty array if workerJobs is not defined
        );

        console.log(workers);



      //  console.log(workers);


        const sortedWorkers = workers
            .filter(worker => worker.profile) // Ensure only workers with profiles are included
            .sort((a, b) => b.rate - a.rate);

        console.log('Sorted worker profiles:', sortedWorkers);

        if (!sortedWorkers || sortedWorkers.length === 0) {
            return res.status(404).json({ message: 'No profiles found for this category.' });
        }

        return res.json({ workers: sortedWorkers });
    } catch (error) {
        console.error('Error fetching profiles by category with sorting:', error);
        res.status(500).json({ message: 'Server error' });
    }
};



exports.getWorkerReview = async (req, res) => {
    try {
        const { phoneNumber } = req.query;  // Get phone number from query parameters
        console.log("Worker's phone number:", phoneNumber);

        // Fetch reviews associated with the worker's phone number
        const workerReviews = await Review.findAll({
            where: { workerPhoneNumber:phoneNumber },
            reviewed: 1, // Add the condition to check if reviewed is 1
            attributes: ['description', 'professionalism','reliability','availability'], // Fetch only needed fields

        });

        const reviews = await Review.findAll({
            where: { workerPhoneNumber:phoneNumber ,reviewed:1 }, // Filter by worker's phone number
            attributes: ['description', 'professionalism', 'reliability', 'availability','showName','createdAt','updatedAt'], // Review details
            include: [
                {
                    model: notification, // Join with Notification table
                    as: 'notification',
                    attributes: [], // No additional fields from Notification needed

                    include: [
                        {
                            model:OrderService , // Join with Customer table
                            as: 'orderService',
                            attributes: [], // Fetch customer details
                            required: true, // Ensures only reviews with customer data are returned
                            include: [
                                {
                                    model: Customer, // Join with Customer table
                                    as:'Customer',
                                    attributes: ['CustomerFirstName', 'CustomerLastName'], // Fetch customer details
                                    required: true, // Ensures only reviews with customer data are returned
                                },
                            ],
                        },
                    ],
                },
            ],
            raw: true, // Flatten results
            nest: true, // Keep nested structure
        });




        // Log for debugging purposes
        console.log("reviewssArray",reviews);
        // Return the reviews as a JSON response
        res.status(200).json(reviews);
    } catch (error) {
        console.error('Error fetching reviews:', error);
        res.status(500).json({ message: 'Server error. Unable to fetch reviews.' });
    }
};

// Fetch review by serialNumber
exports.getReview = async (req, res) => {
    try {
        const { serialNumber } = req.params;
        const review = await Review.findOne({ where: { serialNumber } });

        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }

        // Retrieve the worker's phone number from the review
        const workerPhoneNumber = review.workerPhoneNumber;

        // Find the worker's details using the phone number
        const worker = await Worker.findOne({ where: { phoneNumber: workerPhoneNumber } });
        const customernotification = await notification.findOne({ where: { id:review.notificationId} });

        const customerFullname= await Customer.findOne({where:{customerPhoneNumber:customernotification.customerPhoneNumber}});
        console.log("customerFullname",customerFullname);
        if (!worker) {
            return res.status(404).json({ message: 'Worker not found' });
        }

        const workerfullname = `${worker.firstName} ${worker.lastName}`;
        const customerfullname = `${customerFullname.CustomerFirstName} ${customerFullname.CustomerLastName}`;

        console.log("workerfullname:", workerfullname);



        // Create a response object that combines review and worker fullname
        const reviewWithWorkerName = {
            ...review.toJSON(),  // Convert review to plain object if it's a Sequelize instance
            workerfullname,
            customerfullname
        };

        res.status(200).json(reviewWithWorkerName);
    } catch (error) {
        console.error('Error fetching review:', error);
        res.status(500).json({ message: 'Server error' });
    }
};


// Update review by serialNumber


// reviewController.js

exports.updateReview = async (req, res) => {
    const { serialNumber } = req.params;
    const { professionalism, availability, reliability, description,showName } = req.body;

    console.log("description",description);

    try {
        await Review.update(
            {
                professionalism,
                availability,
                reliability,
                description,
                reviewed: 1,
                showName,
            },
            { where: { serialNumber:serialNumber } }
        );

        res.json({ success: true, message: "Review updated successfully" });
    } catch (error) {
        console.error("Error updating review:", error);
        res.status(500).json({ success: false, message: "Failed to update review" });
    }
};



exports.getAcceptedNotificationsByPhoneNumber = async (req, res) => {
    const { phoneNumber } = req.params;
    try {
        const acceptedNotifications = await notification.findAll({
            where: {
                status: '1',
                phoneNumber: phoneNumber,
            },
        });

        console.log('Accepted Notifications:', acceptedNotifications); // Add this line to debug

        if (acceptedNotifications.length > 0) {
            res.status(200).json(acceptedNotifications);
        } else {
            res.status(404).json({ message: 'No accepted notifications found for this phone number' });
        }
    } catch (error) {
        console.error('Error retrieving accepted notifications:', error);
        res.status(500).json({ message: 'Error retrieving accepted notifications', error });
    }
};

// Helper function to create a review




exports.updateNotificationStatus = async (req, res) => {
    const { id } = req.params;
    console.log("this is the id:", id);

    try {

        // Directly update using `update` method
        const [updated] = await notification.update(
            { status: '1' }, // Set the new status
            { where: { id } } // Specify the condition
        );
        if (updated) {
            // Find the updated notification record
            const foundNotification = await notification.findOne({ where: { id } });


            // Check if the status is 1, then create a review
            if (foundNotification.status === '1') {
                const reviewLink = await createReviewForNotification(foundNotification);
                res.status(200).json({
                    message: 'Status updated and review sent',
                    reviewLink: reviewLink  // Send the review link in the response
                });
            } else {
                res.status(200).json({ message: 'Status updated successfully' });
            }
        } else {
            res.status(404).json({ message: 'Notification not found or status unchanged' });
        }
    } catch (error) {
        console.error("Error updating notification status:", error);
        res.status(500).json({ message: 'Error updating status', error });
    }
};

function generateNumericToken() {
    return Math.floor(1000000000 + Math.random() * 9000000000).toString();
}
const createReviewForNotification = async (notification) => {
    const uniqueToken = generateNumericToken();

    await Review.create({
        serialNumber:uniqueToken,
        workerPhoneNumber: notification.workerPhoneNumber,
        notificationId: notification.id,
        professionalism: 1,  // Default or placeholder value; adjust as needed
        reliability: 1,      // Default or placeholder value; adjust as needed
        availability: 1,     // Default or placeholder value; adjust as needed
        description: '',     // Default or placeholder value; adjust as needed
        showName:0,
    });
    // Generate a unique token for the review link

    // Generate the review URL (assuming the review page route is /review/:token)
    const reviewLink = `http://localhost:3000/review/${uniqueToken}`;
    console.log("reviewLink",reviewLink);
    // Optionally, store the unique token in the review record
    //review.update({ uniqueToken });

    // Return the review link
    return reviewLink;
};


// Controller to get notification data for the logged-in worker


// In workerController.js

exports.getWorkerNotifications = async (req, res) => {
    try {
        const workerPhoneNumber = req.user.phoneNumber;
        // Fetch notifications logic
        const notifications = await notification.findAll({
            where: { workerPhoneNumber },
            include: [
                {
                    model: OrderService,
                    as: 'orderService',
                    include: [
                        {
                            model: Customer,
                            attributes: ['customerPhoneNumber', 'CustomerFirstName', 'CustomerLastName']
                        }
                    ]
                }
            ],
            logging: console.log // Debug SQL

        });
        console.log("notificationss",notifications);
        res.status(200).json(notifications);
    } catch (error) {
        console.error('Error fetching notifications:', error);
        res.status(500).json({ message: 'Server error' });
    }
};



//===========================================
exports.createRequest = async (req, res) => {
    try {
        const { slug, firstName, lastName, phoneNumber, requestType, requestDate, requestDetails } = req.body.requestFormData;

        //const {slug, firstName, lastName, phoneNumber, requestType, requestDate, requestDetails } = req.body;


        const customerExists = await Customer.findOne({ where: { customerPhoneNumber: phoneNumber } });

        const workerphonenumber = slug.split('-')[0];


        if (!customerExists) {

            // If customer does not exist, create a new customer entry
            await Customer.create({
                customerPhoneNumber: phoneNumber,
                CustomerFirstName: firstName,
                CustomerLastName: lastName
            });
        }

        const orderData = {
            workerPhoneNumber: workerphonenumber,
            customerPhoneNumber: phoneNumber,
            serviceType: requestType,
            serviceDate: requestDate, // Add this line if it's required
            description: requestDetails
        };


       

        console.log("OrderService data:", orderData); // Log data before creation

        const neworderService = await OrderService.create(orderData);

        const notificationData={
            workerPhoneNumber: workerphonenumber,
            customerPhoneNumber : phoneNumber ,
            serviceId : neworderService.id,
          //  status : 'not started',
            description : 'i need help',
            startDate : neworderService.serviceDate,
            endDate:'2024-11-11'
        };
        console.log("notificationData",notificationData);

        await notification.create(notificationData);


        // Save the request data to the database, or process it as needed
        // Example with Sequelize (if you're using Sequelize ORM):
        // await Request.create({ firstName, lastName, phoneNumber, requestType, requestDate, requestDetails });

        res.status(201).json({ message: 'Request created successfully' });
    } catch (error) {
        res.status(500).json({ message: 'An error occurred while processing the request' });
    }
};
//=========== reset password unauth

exports.resetPasswordUnauth = async (req, res) => {
    try {
        const { phoneNumber, password } = req.body;

        // Verify that both phone number and password are provided
        if (!phoneNumber || !password) {
            return res.status(400).send({ message: 'Phone number and password are required' });
        }

        // Hash the new password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Update the user's password in the database using the phone number
        const [updated] = await Worker.update(
            { password: hashedPassword },
            { where: { phoneNumber } }
        );

        if (updated) {
            res.send({ message: 'Password reset successfully!' });
        } else {
            res.status(404).send({ message: 'Phone number not found' });
        }
    } catch (error) {
        console.error('Error resetting password:', error);
        res.status(500).send({ message: 'Error resetting password.' });
    }
};


//============ reset password with auth
exports.resetPassword = async (req, res) => {
    try {

        const {password} = req.body;

        if (!req.user) {
            return res.status(401).send({message: 'User not authenticated'});
        }

        // Hash the new password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Update the user's password in the database
        await Worker.update({password: hashedPassword}, {where: {phoneNumber: req.user.phoneNumber}});

        res.send({message: 'Password reset successfully!'});
    } catch (error) {
        console.error('Error resetting password:', error);
        res.status(500).send({message: 'Error resetting password.'});
    }
};

//=============================

exports.getPublicProfile = async (req, res) => {
    try {
        const { slug } = req.params;

        // Find the profile by slug and retrieve rate, description, and workerPhoneNumber
        const profile = await Profile.findOne({
            where: { slug },
            attributes: ['description', 'rate', 'workerPhoneNumber','specificLocation', 'images','schedule'],
        });

        if (!profile) {
            return res.status(404).json({ message: 'Profile not found' });
        }

        const phoneNumber = profile.workerPhoneNumber;

        // Find the worker by phone number, include jobs from WorkerJob and locations
        const workerProfile = await Worker.findOne({
            where: { phoneNumber },
            attributes: ['firstName', 'lastName', 'profilePicture','email'],
            include: [
                {
                    model: WorkerJob, // Include the worker's jobs from WorkerJob
                    attributes: ['jobName'], // Get job names directly from WorkerJob
                },
                {
                    model: Location, // Include worker's locations
                    through: WorkerLocation, // Through the WorkerLocation join table
                    attributes: ['name'] // Get location names
                }
            ]
        });

        if (!workerProfile) {
            return res.status(404).json({ message: 'Worker not found' });
        }

        // Map the job names from WorkerJob and locations
        const jobs = workerProfile.workerJobs.map(workerJob => workerJob.jobName);
        const locations = workerProfile.locations.map(location => location.name);

        // Construct the public profile data
        const publicData = {
            phoneNumber: phoneNumber,
            firstName: workerProfile.firstName,
            lastName: workerProfile.lastName,
            email:workerProfile.email,
            rate: profile.rate,
            description: profile.description,
            jobs: jobs,
            locations: locations,
            profilePicture: workerProfile.profilePicture || null, // Default to null if no profile picture
            specificLocation:profile.specificLocation,
            schedule:profile.schedule,
            images:profile.images,
        };

        res.json(publicData);
    } catch (error) {
        console.error('Error fetching public profile:', error);
        res.status(500).json({ message: 'Server error' });
    }
};



// Assuming this route exists in your workerController.js
exports.getProfilenotfull = async (req, res) => {
    const workerPhoneNumber = req.user.phoneNumber; // Correct reference
    try {
        // Fetch worker details including associated jobs and locations
        const worker = await Worker.findOne({
            where: { phoneNumber: workerPhoneNumber },
            include: [
                { model:Profile,
                    attributes:['description']

                },
                {
                    model: WorkerJob,
                    attributes: ['jobName'] // Specify the fields you want from the Job model
                },
                {
                    model: Location,
                    through: WorkerLocation, // Through the WorkerLocation join table
                    attributes: ['name'] // Specify the fields you want from the Location model
                }
            ]
        });

        // If the worker is not found, return 404
        if (!worker) {
            return res.status(404).send({ message: 'Worker not found' });
        }

        // Send the worker data as the response
        return res.status(200).send(worker);

    } catch (error) {
        // Log the error for debugging
        console.error('Error fetching profile:', error);

        // Send back a 500 error response with the error message
        return res.status(500).send({
            message: 'Error fetching profile',
            error: error.message
        });
    }
};



//-------------------------------------------
exports.editProfile = async (req, res) => {
    const { firstName, lastName, description, jobs, locations } = req.body;
    const workerPhoneNumber = req.user.phoneNumber; // Assuming currentUser stores phoneNumber

    try {
        // Find the worker by phone number
        const worker = await Worker.findOne({
            where: { phoneNumber: workerPhoneNumber },
            include: [{ model:Profile }] // Include the related profile
        });

        if (!worker) {
            return res.status(404).send({ message: 'Worker not found' });
        }

        console.log("Updating worker:", firstName, lastName, description);

        // Update worker profile details
        worker.firstName = firstName;
        worker.lastName = lastName;

        // Update profile description if exists
        if (worker.profile) {
            worker.profile.description = description;
            await worker.profile.save(); // Save the profile updates
        } else {
            // If no profile exists, create a new one (optional)
            await models.profile.create({
                workerPhoneNumber: worker.phoneNumber,
                description,
            });
        }

        // Save the updated worker profile
        await worker.save();

        // Update jobs (many-to-many relationship)
        if (jobs && jobs.length > 0) {
            const jobRecords = await models.job.findAll({ where: { name: jobs } });
            await worker.setJobs(jobRecords);
        }

        // Update locations (many-to-many relationship)
        if (locations && locations.length > 0) {
            const locationRecords = await models.location.findAll({ where: { name: locations } });
            await worker.setLocations(locationRecords);
        }

        return res.status(200).send({ message: 'Profile updated successfully' });
    } catch (error) {
        console.error('Error updating profile:', error);
        return res.status(500).send({ message: 'An error occurred while updating the profile' });
    }
};

exports.updateProfile = async (req, res) => {
    try {
        const { firstName, lastName, profilePicture,description, selectedJobs, selectedLocations,specificLocation,schedule } = req.body;

       console.log("specificLocationspecificLocation",specificLocation);
        const simplifiedData = schedule.map(item => ({
            day: item.day,
            time: (item.start && item.end) ? item.start + ' to ' + item.end : item.time, // Use item.time if start/end are missing
        }));
        console.log("simplifiedData",simplifiedData);

        const profile = await Profile.findOne({ where: { workerPhoneNumber: req.user.phoneNumber } });

        const isScheduleSame = simplifiedData.every(newScheduleItem => {
            const profileScheduleItem = profile.schedule.find(item => item.day === newScheduleItem.day);

            // Check if both day and time are the same
            return profileScheduleItem && profileScheduleItem.time === newScheduleItem.time;
        });
        console.log("isScheduleSame",isScheduleSame);

        if (!isScheduleSame) {
            if (profile) {
                console.log("mmohmmmmod");
                await profile.update({ schedule: [] });
                await profile.update({schedule:simplifiedData});

            }

        }



        // Ensure the user is authenticated
        if (!req.user) {
            return res.status(401).send({ message: 'User not authenticated' });
        }
        let profilePictureUrl = null;
        if (req.file) {
            // Upload the new profile picture to S3
            profilePictureUrl = req.file.location;  // The location field contains the S3 URL
        } else {
            profilePictureUrl = profilePicture;  // If no new file, keep the existing URL
        }

        // Update worker information (First Name, Last Name, and Profile Picture)
        await Worker.update(
            { firstName, lastName, profilePicture: profilePictureUrl },
            { where: { phoneNumber: req.user.phoneNumber } }
        );

        // Update description in the Profile model
        if (profile) {
            await profile.update({ description ,specificLocation});
        }

        // Handle jobs: If selectedJobs is not empty, update them
        if (selectedJobs && selectedJobs.length > 0 && selectedJobs[0] !== 'No jobs available') {
            // Clear existing jobs for this worker
            await WorkerJob.destroy({ where: { workerPhoneNumber: req.user.phoneNumber } });

            for (const jobName of selectedJobs) {
                // Check if the job already exists
                const jobCategory = await JobCategory.findOne({ where: { jobName } });

                // Create job if it doesn't exist
                if (!jobCategory) {
                    console.warn(`Job not found, creating a new one: ${jobName}`);
                    await JobCategory.create({ jobName, categoryName: getCategoryByJob(jobName) });
                }

                // Link job to the worker in WorkerJob table
                await WorkerJob.create({
                    workerPhoneNumber: req.user.phoneNumber,
                    jobName // Assuming jobName is the unique identifier in the WorkerJob table
                });
            }
        }

        // Handle locations (no changes needed, as it works correctly)
        if (selectedLocations && selectedLocations.length > 0) {
            await WorkerLocation.destroy({ where: { workerPhoneNumber: req.user.phoneNumber } });

            for (const locationName of selectedLocations) {
                const location = await Location.findOne({ where: { name: locationName } });
                if (location) {
                    await WorkerLocation.create({
                        workerPhoneNumber: req.user.phoneNumber,
                        locationId: location.id
                    });
                }
            }
        }

        res.send({ message: 'Profile updated successfully!' });
    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).send({ message: 'Error updating profile.' });
    }
};
//-------------------------------------------
// In your controller (workerController.js)
exports.findProfilesByCategory = async (req, res) => {
    try {
        const { categoryName } = req.params;
        console.log('Category Name:', categoryName);

        const category = await Category.findOne({
            where: { name: categoryName }, // Find the specific category by name
            include: [{
                model: Job,
                include: [{
                    model: WorkerJob,
                    include: [{
                        model: Worker,
                        include: [{
                            model: WorkerJob,
                            include: [{
                                model: Job,
                                include: [Category],
                            }],
                        }, {
                            model: Profile,
                        }, {
                            model: Location,
                            through: { attributes: [] }
                        }],
                    }],
                }],
            }],
        });

        // Check if category exists
        if (!category) {
            return res.status(404).json({ message: 'Category not found' });
        }

        // Log the category to see if jobs are being returned correctly
        console.log('Category data:', JSON.stringify(category, null, 2));

        const workers = category?.jobs?.flatMap(job =>
            job.workerJobs.map(workerJob => ({
                worker: workerJob.worker,
                profile: workerJob.worker.profile, // Include the profile data
                jobs: workerJob.worker.workerJobs.map(wj => ({
                    job: wj.job.name,
                    categories: wj.job.categories.map(category => category.name),
                })), // Access categories for each worker's job
                locations: workerJob.worker.locations.map(location => location.name), // Include worker's locations
            }))
        );

        // Log the final profiles list to verify if it's being populated correctly
        console.log('Unique worker profiles:', workers);

        if (!workers || workers.length === 0) {
            return res.status(404).json({ message: 'No profiles found for this category.' });
        }

        return res.json({ workers });
    } catch (error) {
        console.error('Error fetching profiles by category:', error);
        res.status(500).json({ message: 'Server error' });
    }
};




//-------------------------------------------


exports.findProfileBySlug = async (req, res) => {
    try {
        const {slug} = req.params;

        // Find the profile by slug
        const profile = await Profile.findOne({
            where: {slug}, include: [{
                model: Worker,  // Include the associated worker details
                attributes: ['firstName', 'lastName', 'phoneNumber', 'email'], include: [{
                    model: WorkerJob,  // Include associated jobs
                    include: [{
                        model: Job,  // Assuming you have a Job model
                        attributes: ['jobName']  // Fetch the job name
                    }]
                }, {
                    model: WorkerLocation,  // Include associated locations
                    include: [{
                        model: Location,  // Assuming you have a Location model
                        attributes: ['name']  // Fetch the location name
                    }]
                },{
                    model: Profile,
                    
                }
            ]
            }]
        });

        // If no profile is found, return 404
        if (!profile) {
            return res.status(404).json({message: 'Profile not found'});
        }

        // Send the profile data along with worker, job, and location info
        res.status(200).json(profile);
    } catch (error) {
        console.error('Error fetching profile by slug:', error);
        res.status(500).json({message: 'Server error'});
    }
};


//------------------------------------------- on the new way

exports.login = async (req, res) => {
    console.log("JWT_SECRET:", process.env.JWT_SECRET);

    const {phoneNumber, password} = req.body;

    // Ensure both phoneNumber and password are provided
    if (!phoneNumber || !password) {
        return res.status(400).json({message: "Phone number and password are required"});
    }

    try {
// Fetch the worker and include the associated profile with the slug
        const worker = await Worker.findOne({
            where: {phoneNumber: phoneNumber}, include: [{
                model: Profile,   // Include the Profile model
                attributes: ['slug'],  // Only select the slug field from Profile
            }]
        });
        if (!worker) {
            return res.status(404).json({message: "Worker not found"});
        }

        const passwordIsValid = await bcrypt.compare(password, worker.password);

        if (!passwordIsValid) {
            return res.status(401).json({message: "Invalid password"});
        }

        // Generate the JWT using phoneNumber instead of id
        const token = jwt.sign({phoneNumber: worker.phoneNumber}, process.env.JWT_SECRET, {
            expiresIn: 86400, // 24 hours
        });

        console.log('Worker slug moew:', worker.profile.slug);


        res.status(200).json({
            phoneNumber: worker.phoneNumber, token: token, slug: worker.profile.slug,  // Ensure slug is sent back in the response

        });
    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({message: "Error logging in worker", error: error.message});
    }
};

exports.findProfileByPhoneNumber = async (req, res) => {
    try {
        const {phoneNumber} = req.params;

        // Find the worker by phone number
        const worker = await Worker.findOne({
            where: {phoneNumber}
        });

        // If worker is not found, return a 404 status with an appropriate message
        if (!worker) {
            return res.status(404).json({message: 'Worker not found'});
        }

        // Return only the slug of the worker
        res.json({slug: worker.slug});
    } catch (error) {
        res.status(500).json({error: 'Server error'});
    }
};


exports.getDashboard = (req, res) => {
    // Assuming req.user contains both worker and profile data
    res.send({
        firstName: req.user.firstName,
        lastName: req.user.lastName,
        phoneNumber: req.user.phoneNumber,
        email: req.user.email,
        rate: req.user.profile.Rate,
        description: req.user.profile.description,
    });
};

exports.getProfile = (req, res) => {
    console.log("req.user.profile.schedule",req.user.profile.schedule);
    const jobs = req.user.workerJobs ? req.user.workerJobs.map(job => job.jobName) : [];
    // Map the location names from workerLocations
    const locations = req.user.locations ? req.user.locations.map(location => location.name) : [];
    // Assuming req.user contains both worker and profile data
    
    res.send({
        firstName: req.user.firstName,
        lastName: req.user.lastName,
        phoneNumber: req.user.phoneNumber,
        email: req.user.email,
        rate: req.user.profile.rate,
        description: req.user.profile.description,
        jobs: jobs.length ? jobs : ['No jobs available'], // Return job names or fallback message
        locations: locations.length ? locations : ['No locations available'], // Return location names or fallback message
        profilePicture: req.user.profilePicture || null, // Default to null if no profile picture
        images: req.user.profile.images,
        specificLocation:req.user.profile.specificLocation,
        schedule:req.user.profile.schedule,
        
        
    });
};
// In workerController.js
exports.updateUser = async (req, res) => {
    try {
        const {firstName, lastName, email} = req.body;

        // Update the user details in the database, excluding the phone number
        await Worker.update({firstName, lastName, email}, {where: {phoneNumber: req.user.phoneNumber}} // Use phone number as the identifier
        );

        res.send({message: 'User details updated successfully'});
    } catch (error) {
        console.error('Error updating user details:', error);
        res.status(500).send({message: 'Error updating user details'});
    }
};


//====================================================================
// categoriesWithJobs definition
const categoriesWithJobs = {
    house: ["Plumbing", "Electrical Work", "Painting", "Cleaning"],
    car: ["Car Repair", "Car Wash", "Tire Change", "Oil Change"],
    tech: ["Computer Repair", "Phone Repair", "Networking", "Software Development"],
    weddings: ["Wedding Planning", "Catering", "Photography", "Decoration"],
    garden: ["Lawn Mowing", "Tree Trimming", "Landscaping", "Garden Maintenance"],
};

// Function to get category by job name
function getCategoryByJob(jobName) {
    for (const [category, jobs] of Object.entries(categoriesWithJobs)) {
        if (jobs.includes(jobName)) {
            return category;
        }
    }
    return null; // Return null if job not found in any category
}

exports.completeProfile = async (req, res) => {
    try {
        const {workerPhoneNumber, profilePicture, workPictures, jobs, locations, description,specificLocation,schedule} = req.body;

        const worker = await Worker.findByPk(workerPhoneNumber);
        if (!worker) {
            return res.status(404).json({message: 'Worker not found'});
        }

        // Update profile details
        await worker.update({profilePicture});


        const profile = await Profile.findOrCreate({
            where: {workerPhoneNumber: worker.phoneNumber}, defaults: {description, slug: workerPhoneNumber,specificLocation:specificLocation || null}  // Ensure a default slug
        });
        await profile[0].update({description, images: JSON.stringify(workPictures),schedule});

        // Handle job categories
        if (jobs && jobs.length > 0) {
            await WorkerJob.destroy({where: {workerPhoneNumber: worker.phoneNumber}});

            for (const jobName of jobs) {
                const categoryName = getCategoryByJob(jobName); // Get the category for the job
                if (categoryName) {
                    await WorkerJob.create({workerPhoneNumber: worker.phoneNumber, jobName});

                    // Check if the JobCategory entry already exists
                    const existingJobCategory = await JobCategory.findOne({
                        where: {jobName, categoryName}
                    });

                    // Only create a new JobCategory entry if it doesn't already exist
                    if (!existingJobCategory) {
                        await JobCategory.create({jobName, categoryName});
                    }
                } else {
                    console.warn(`Category not found for job: ${jobName}`);
                }
            }
        }

        // Handle locations
        if (locations && locations.length > 0) {
            await WorkerLocation.destroy({where: {workerPhoneNumber: worker.phoneNumber}});
            for (const locationName of locations) {
                const location = await Location.findOne({where: {name: locationName}});
                if (location) {
                    await WorkerLocation.create({workerPhoneNumber: worker.phoneNumber, locationId: location.id});
                }
            }
        }

        res.status(200).json({message: 'Profile completed successfully'});
    } catch (error) {
        console.error('Error completing profile:', error);
        res.status(500).json({message: 'Error completing profile'});
    }
};
//====================================================================


//------------------------------------------- on the new way
// Create and Save a new Worker with validation middleware
/*---- READ ----
Yes, in the code line router.post('/workers', validateSignupData, workers.create);,
the validateSignupData middleware function is executed first.
If validateSignupData completes successfully (i.e., it calls next() without any errors),
the request then proceeds to the workers.create function.
*/
exports.create = [validateWorker, async (req, res) => {
    // Validate request
    if (!req.body.firstName && !req.body.lastName && !req.body.phoneNumber && !req.body.email && !req.body.password) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
        return;
    }
    const {phoneNumber} = req.body;

    // Check if the phone number already exists
    const existingWorker = await Worker.findOne({where: {phoneNumber}});
    if (existingWorker) {
        return res.status(400).json({message: 'Phone number is already registered.'});
    }

    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        // Create a Worker
        const worker = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            phoneNumber: req.body.phoneNumber,
            email: req.body.email,
            password: hashedPassword
        };
        const data = await Worker.create(worker);
        res.send(data);

    } catch (err) {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Worker."
        });
    }
}];

// Save Worker in the database
//-----------------------------------------------------------------------------------------------------

// Retrieve all Workers from the database.
exports.findAll = (req, res) => {
    const firstName = req.query.firstName;
    var condition = firstName ? {firstName: {[Op.iLike]: `%${firstName}%`}} : null;

    Worker.findAll({where: condition})
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving workers."
            });
        });
};

//====================================================================

// Find worker by phone number
exports.findOne = (req, res) => {
    const phoneNumber = req.params.phoneNumber;
    console.log(`Searching for worker with phoneNumber: ${phoneNumber}`);

    Worker.findOne({where: {phoneNumber: phoneNumber}})
        .then(data => {
            if (data) {
                res.send({exists: true, message: "Phone number is registered."});
            } else {
                res.status(404).send({exists: false, message: "Phone number is not registered."});
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Error retrieving Worker with phoneNumber=" + phoneNumber
            });
        });
};

//====================================================================

// Update a Worker by the id in the request
exports.update = (req, res) => {
    const id = req.params.id;

    Worker.update(req.body, {
        where: {id: id}
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Worker was updated successfully."
                });
            } else {
                res.send({
                    message: `Cannot update Worker with id=${id}. Maybe Worker was not found or req.body is empty!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Error updating Worker with id=" + id
            });
        });
};

// Delete a Worker with the specified id in the request
exports.delete = (req, res) => {
    const id = req.params.id;

    Worker.destroy({
        where: {id: id}
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Worker was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete Worker with id=${id}. Maybe Worker was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Worker with id=" + id
            });
        });
};

// Delete all Workers from the database.
exports.deleteAll = (req, res) => {
    Worker.destroy({
        where: {}, truncate: false
    })
        .then(nums => {
            res.send({message: `${nums} Workers were deleted successfully!`});
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while removing all workers."
            });
        });
};

// Find all published Workers
exports.findAllPublished = (req, res) => {
    Worker.findAll({where: {published: true}})
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving workers."
            });
        });
};
