const express = require('express');
const router = express.Router();
const workers = require('../controllers/workerController');
const { validateSignupData } = require('../middleware/validationMiddleware');
const currentUser = require('../middleware/currentUser');

const authenticateToken = require('../middleware/authMiddleware');


/*
const express = require('express');
const { validateSignupData } = require('../middleware/validationMiddleware');
const workerController = require('../controllers/workerController');

const router = express.Router();

router.post('/signup', validateSignupData, workerController.signupWorker);
*/
//module.exports = router;

//--------new way

//--------new way
// Create a new Worker
// before // router.post('/workers', workers.create);
// Create a new Worker with validation
router.post('/workers', validateSignupData, workers.create);
// Retrieve all Workers
router.get('/workers', workers.findAll);

// Retrieve all published Workers
router.get('/workers/published', workers.findAllPublished);

router.post('/complete-profile', workers.completeProfile);

// Retrieve a single Worker with phone number
router.get('/workers/:phoneNumber', workers.findOne);

// Update a Worker with id
router.put('/workers/:id', workers.update);

// Delete a Worker with id
router.delete('/workers/:id', workers.delete);

// Delete all Workers
router.delete('/workers', workers.deleteAll);

router.post('/login', workers.login);

// Route to get the profile of the **current authenticated user**

router.get('/Profile', currentUser, workers.getProfile);



// Route to retrieve **any worker's profile by phone number**
// This does not require the current user to be logged in.
router.get('/Profile/:slug', currentUser,workers.getProfile,workers.findProfileByPhoneNumber);




//router.get('/Profile/:phoneNumber', workers.getProfile);


router.put('/reset-password', currentUser, workers.resetPassword);

// Add this route to handle user updates
router.put('/updateUser', currentUser, workers.updateUser);

router.get('/profiles/category/:categoryName',workers.findProfilesByCategory);

//--------
router.put('/edit-profile', currentUser, workers.updateProfile);

router.get('/ProfileNotFull', currentUser, workers.getProfilenotfull);


router.put('/notifications/:id/status', currentUser, workers.updateNotificationStatus);


/// this one added new 24/12 ##############################
router.put('/notifications/:editNotificationId',currentUser,workers.editNotificationDate);
/// this one added new 24/12 ##############################


//await axios.put(`http://localhost:8080/api/notifications/${id}/status`, {}, {


router.get('/notifications/accepted/:phoneNumber', workers.getAcceptedNotificationsByPhoneNumber);

router.put('/updateRate', workers.updateRate);


router.put('/review/:serialNumber', workers.updateReview);

//for public note ###

// Route to retrieve **any worker's profile by slug**
// router.get('/Profile/:slug', workers.findProfileBySlug); // This is for guest access or anyone else


// this for public
// Route for public access (guests)
router.get('/publicProfile/:slug', workers.getPublicProfile);

router.put('/reset-password-unauth', workers.resetPasswordUnauth);


router.post('/createRequest', workers.createRequest);

router.get('/notifications',currentUser, workers.getWorkerNotifications);


// Get review by serialNumber
router.get('/review/:serialNumber', workers.getReview);


// getting the reviews of the
router.get('/publicProfile/:slug/reviews',workers.getWorkerReview);
// Update review by serialNumber
///// new here
router.put('/review', workers.updateWorkerRate);

//router.get('/review',workers.getReviewProfile);



router.get('/workers/sorted-by-rate/:categoryName', workers.SortingWorkersByReview);


//##################################### new

router.get('/workers/workers-by-location-category', workers.getWorkersByLocationAndCategory);

router.get('/workers/workers-by-category-job/:categoryName', workers.getWorkersByCategoryAndJob);



module.exports = router;
