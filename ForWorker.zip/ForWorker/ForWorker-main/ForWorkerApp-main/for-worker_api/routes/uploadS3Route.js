const express = require('express');
const { uploadToS3 } = require('../middleware/s3UploadMiddleware');

const router = express.Router();

// Route to handle file upload
router.post('/', uploadToS3.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'Please upload a file.' });
    }

    res.status(200).json({
        message: 'File uploaded successfully',
        fileUrl: req.file.location // S3 file URL
    });
});

module.exports = router;

