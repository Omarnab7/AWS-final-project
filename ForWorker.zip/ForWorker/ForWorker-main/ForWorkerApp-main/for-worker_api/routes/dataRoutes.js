const express = require('express');
const router = express.Router();
const db = require('../db/models');
//const upload = require('../middleware/s3UploadMiddleware'); // Import the S3 upload middleware
const workerController = require('../controllers/workerController');

// Get all jobs
router.get('/jobs', async (req, res) => {
    try {
        const jobs = await db.job.findAll();
        res.json(jobs);
    } catch (error) {
        console.error('Failed to fetch jobs:', error);
        res.status(500).json({ error: 'Failed to fetch jobs' });
    }
});

// Get all locations
router.get('/locations', async (req, res) => {
    try {
        const locations = await db.location.findAll();
        res.json(locations);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch locations' });
    }
});

//router.post('/complete-profile', upload.fields([
//    { name: 'profilePicture', maxCount: 1 }, // Single profile picture
//    { name: 'workPictures', maxCount: 5 },  // Multiple work pictures
//]), workerController.completeProfile);
module.exports = router;
