// src/models/category.model.js
module.exports = (sequelize, DataTypes) => {
    const Category = sequelize.define("category", {
        name: {
            type: DataTypes.STRING(255),
            primaryKey: true,
            allowNull: false,
        },
    });

    Category.associate = function(models) {
        Category.belongsToMany(models.job, {
            through: 'jobCategory',
            foreignKey: 'categoryName',
            otherKey: 'jobName'

        });
    };

    return Category;
};
