// location.model.js
module.exports = (sequelize, DataTypes) => {
    const Location = sequelize.define("location", {
        name: {
            type: DataTypes.STRING(255),
            allowNull: false
        }
    });

    Location.associate = function(models) {
        // Many-to-many relationship with Worker through WorkerLocation
        Location.belongsToMany(models.worker, {
            through: models.workerLocation,
            foreignKey: 'locationId',
            otherKey: 'workerPhoneNumber',
        });
    };

    return Location;
};
