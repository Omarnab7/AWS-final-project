

module.exports = (sequelize, DataTypes) => {
    const Notification = sequelize.define("notification", {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        workerPhoneNumber: {
            type: DataTypes.STRING(50),
            allowNull: false,
            references: {
                model: 'profile',
                key: 'workerPhoneNumber',
            }
        },
        customerPhoneNumber: {
            type: DataTypes.STRING(50),
            allowNull: false,
            references: {
                model: 'customer',
                key: 'customerPhoneNumber',
            }
        },
        serviceId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'order_service',  // Now this references the `id` of the OrderService
                key: 'id',
            }
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        startDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        endDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        SentAt: {
                type: DataTypes.DATE,
                allowNull: true,
                defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
        },
            status: {
                type: DataTypes.STRING(255),
                allowNull: false,
                defaultValue: '0',
            }
    }, {
        tableName: 'notifications',
        timestamps: false
    }
    );

    Notification.associate = function(models) {
        Notification.belongsTo(models.OrderService, { foreignKey: 'serviceId', as: 'orderService' });

    };

    return Notification;
};
