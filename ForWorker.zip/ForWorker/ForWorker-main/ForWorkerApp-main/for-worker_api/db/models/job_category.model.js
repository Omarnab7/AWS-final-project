const workers = require('./Worker.model.js');
const Category =require('./Category.model.js');


// src/models/jobCategory.model.js
module.exports = (sequelize, DataTypes) => {
    const JobCategory = sequelize.define("jobCategory", {
        jobName: {
            type: DataTypes.STRING(255),
            primaryKey: true,
            references: {
                model: 'jobs',
                key: 'name'
            }
        },
        categoryName: {
            type: DataTypes.STRING(255),
            primaryKey: true,
            references: {
                model: 'category',
                key: 'name'
            }
        }
    });

    JobCategory.associate = function(models) {
        JobCategory.belongsTo(models.job, { foreignKey: 'jobName' });
        JobCategory.belongsTo(models.category, { foreignKey: 'categoryName' });
    };

    return JobCategory;
};
