// worker.model.js
module.exports = (sequelize, DataTypes) => {
    const Worker = sequelize.define("worker", {
        firstName: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        lastName: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        phoneNumber: {
            type: DataTypes.STRING(50),
            primaryKey: true
        },
        email: {
            type: DataTypes.STRING(100),
            allowNull: false
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false
        },
        profilePicture: {
            type: DataTypes.STRING
        },
    });

    Worker.associate = function(models) {
        Worker.hasOne(models.profile, { foreignKey: 'workerPhoneNumber' });
        models.profile.belongsTo(Worker, { foreignKey: 'workerPhoneNumber' });
        Worker.hasMany(models.workerjob, { foreignKey: 'workerPhoneNumber' });

        // Many-to-many relationship with Location through WorkerLocation
        Worker.belongsToMany(models.location, {
            through: models.workerLocation,
            foreignKey: 'workerPhoneNumber',
            otherKey: 'locationId',
        });

        Worker.belongsToMany(models.Customer, {
            through: models.OrderService,
            foreignKey: 'workerPhoneNumber',
        });

    };

    return Worker;
};
