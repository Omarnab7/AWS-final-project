const dbConfig = require("../config/db.config.js")['development'];

const Sequelize = require("sequelize");
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
    host: dbConfig.HOST,
    dialect: dbConfig.dialect,
    operatorsAliases: 0,
    /*pool: {
        max: dbConfig.pool.max,
        min: dbConfig.pool.min,
        acquire: dbConfig.pool.acquire,
        idle: dbConfig.pool.idle
    }*/
});

const db = {};

db.Sequelize = Sequelize;  // Sequelize class
db.sequelize = sequelize;  // Sequelize instance

// Import models
db.worker = require("./Worker.model.js")(sequelize, Sequelize);
db.profile = require("./Profile.model.js")(sequelize, Sequelize);
db.job = require("./Job.model.js")(sequelize, Sequelize);
db.workerjob = require("./WorkerJob.model")(sequelize, Sequelize);
db.category = require("./Category.model.js")(sequelize, Sequelize);
db.jobCategory = require("./Job_category.model.js")(sequelize, Sequelize);
db.location = require("./Location.model.js")(sequelize, Sequelize);
db.workerLocation = require("./WorkerLocation.model.js")(sequelize, Sequelize);
db.review = require("./Review.model.js")(sequelize, Sequelize);
db.Customer = require("./Customer.model.js")(sequelize, Sequelize);
db.OrderService = require("./OrderService.model.js")(sequelize, Sequelize);
db.notification = require("./Notification.model.js")(sequelize, Sequelize);


// Define associations
Object.keys(db).forEach(modelName => {
    if (db[modelName].associate) {
        db[modelName].associate(db);
    }
});

console.log('Sequelize instance:', db.sequelize);  // Debugging line

// Function to initialize categories if the table is empty
async function initializeCategories() {
    const categories = [
        { name: "house" },
        { name: "car" },
        { name: "tech" },
        { name: "weddings" },
        { name: "garden" },
    ];

    const count = await db.category.count();

    if (count === 0) {
        await db.category.bulkCreate(categories);
        console.log("Categories initialized.");
    } else {
        console.log("Categories already exist.");
    }
}


async function initializeJobs() {
    const categoriesWithJobs = {
        house: ["Plumbing", "Electrical Work", "Painting", "Cleaning"],
        car: ["Car Repair", "Car Wash", "Tire Change", "Oil Change"],
        tech: ["Computer Repair", "Phone Repair", "Networking", "Software Development"],
        weddings: ["Wedding Planning", "Catering", "Photography", "Decoration"],
        garden: ["Lawn Mowing", "Tree Trimming", "Landscaping", "Garden Maintenance"],
    };

    const count = await db.job.count();

    if (count === 0) {
        for (const categoryName in categoriesWithJobs) {
            const category = await db.category.findOne({ where: { name: categoryName } });
            const jobs = categoriesWithJobs[categoryName].map(jobName => ({
                name: jobName,
                categoryId: category.id  // Associate job with the category
            }));

            await db.job.bulkCreate(jobs);
            console.log(`Jobs for category '${categoryName}' initialized.`);
        }
    } else {
        console.log("Jobs already exist in the database.");
    }
}




// Function to initialize locations if the table is empty
async function initializeLocations() {
    const locations = [
        { name: "Haifa" },
        { name: "Nazareth" },
        { name: "Nahariya" },
        { name: "Tel-Aviv" },
        { name: "Furiedes" },
        { name: "Kafr Qara" },
        { name: "Tayba" },
        { name: "Eilat" },
        { name: "Jerusalem" },
        { name: "Be'er Sheva" },
        { name: "Ashdod" },
        { name: "Rishon LeZion" },
        { name: "Petah Tikva" },
        { name: "Netanya" },
        { name: "Holon" },
        { name: "Bnei Brak" },
        { name: "Bat Yam" },
        { name: "Acre" },
        { name: "Herzliya" },
        { name: "Kfar Saba" },
        { name: "Ramat Gan" },
        { name: "Rehovot" },
        { name: "Lod" },
        { name: "Ramla" },
        { name: "Hadera" },
        { name: "Tiberias" },
        { name: "Safed" },
        { name: "Rosh HaAyin" },
        { name: "Modiin" },
        { name: "Afula" },
        { name: "Kiryat Gat" },
        { name: "Kiryat Shmona" },
        { name: "Sderot" },
        { name: "Arad" },
        { name: "Dimona" },
        { name: "Yavne" },
        { name: "Rahat" },
        { name: "Kiryat Malakhi" }
    ];

    const count = await db.location.count();

    if (count === 0) {
        await db.location.bulkCreate(locations);
        console.log("Locations initialized.");
    } else {
        console.log("Locations already exist.");
    }
}



// Sync database and initialize categories and locations
db.sequelize.sync().then(async () => {
    await initializeCategories();
    await initializeJobs();
    await initializeLocations();
}).catch((error) => {
    console.error("Unable to connect to the database:", error);
});

module.exports = db;
