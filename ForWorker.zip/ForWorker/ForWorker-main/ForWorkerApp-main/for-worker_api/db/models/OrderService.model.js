module.exports = (sequelize, DataTypes) => {
    const OrderService = sequelize.define("orderService", {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,  // This is important to uniquely identify each service
        },
        workerPhoneNumber: {
            type: DataTypes.STRING(50),
            allowNull: false,
            references: {
                model: 'worker',
                key: 'phoneNumber',
            }
        },
        customerPhoneNumber: {
            type: DataTypes.STRING(50),
            allowNull: false,
            references: {
                model: 'Customer',
                key: 'customerPhoneNumber',
            }
        },
        serviceType: {
            type: DataTypes.STRING(255),
            allowNull: true
        },
        serviceDate: {
            type: DataTypes.DATE,
            allowNull: true
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
    }, {
        tableName: 'order_service',
        timestamps: false
    });

    OrderService.associate = function(models) {
        // Associations with Worker and Customer
        OrderService.belongsTo(models.worker, { foreignKey: 'workerPhoneNumber' });
        OrderService.belongsTo(models.Customer, { foreignKey: 'customerPhoneNumber' });

        // One-to-one association with Notification
        OrderService.hasOne(models.notification, { foreignKey: 'serviceId', as: 'notification' });

       // models.notification.belongsTo(OrderService, { foreignKey: 'serviceId', as: 'orderService' });

    };

    return OrderService;
};
