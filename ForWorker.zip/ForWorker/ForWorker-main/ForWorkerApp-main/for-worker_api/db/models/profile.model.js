const workers = require('./Worker.model.js');
const models =require('./index.js');
const crypto = require('crypto'); // Import the crypto module
const slugify = require('slugify'); // Import slugify if you need it for other purposes

module.exports = (sequelize, DataTypes) => {
    const Profile = sequelize.define('profile', {
        description: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        images: {
            type: DataTypes.JSON,
            allowNull: true,
        },
        rate: {
            type: DataTypes.FLOAT,
            allowNull: false,
            defaultValue: 5,
        },
        workerPhoneNumber: {
            type: DataTypes.STRING,
            primaryKey: true,
            unique: true,
            references: {
                model: 'workers',
                key: 'phoneNumber',
            },
        },
        slug: {
            type: DataTypes.STRING,
            allowNull: false, // Ensure slug is required
            unique: true,
        },
        specificLocation: {
            type: DataTypes.STRING(255),
            allowNull: true, // Optional field
            
        },
        // Add days and working hours
        schedule: {
            type: DataTypes.JSON,
            allowNull: true,
            defaultValue: [], // Default to an empty array
            validate: {
                isValidSchedule(value) {
                    if (!Array.isArray(value)) {
                        throw new Error("Schedule must be an array of days and working hours.");
                    }
                    value.forEach(day => {
                        if (!day.day || typeof day.day !== 'string') {
                            throw new Error("Each schedule entry must have a valid day.");
                        }
                        if (!day.time || typeof day.time !== 'string') {
                            throw new Error("Each schedule entry must have a valid time.");
                        }
                    });
                },
            },
        },
    }, {
        freezeTableName: true,
        hooks: {
            beforeCreate: (profile, options) => {
                // Generate a 3-letter random string
                const randomString = crypto.randomBytes(3).toString('hex').toUpperCase().substring(0, 3);
                // Create the slug combining phone number and random string
                profile.slug = `${profile.workerPhoneNumber}-${randomString}`;
            },
        },
    });

    return Profile;
};
