const workers = require('./worker.model.js');
const models =require('../models');
module.exports = (sequelize, DataTypes) => {
    const workerJob = sequelize.define("workerJob", {
        workerPhoneNumber: {
            type: DataTypes.STRING(255),primaryKey: true,
            allowNull: false
        },
        jobName: {
            type: DataTypes.STRING(255),primaryKey:true,
            allowNull: false
        }

    });
    workerJob.associate = function(models) {
        workerJob.belongsTo(models.worker, { foreignKey: 'workerPhoneNumber' });
        workerJob.belongsTo(models.job,{foreignKey:'jobName'});
    }
    return workerJob;
};