module.exports = (sequelize, DataTypes) => {
    const Review = sequelize.define('review', {
        serialNumber: {
            type: DataTypes.STRING(255),
            primaryKey: true,
        },
        workerPhoneNumber: {
            type: DataTypes.STRING,
            allowNull: false,
            references: {
                model: 'workers',
                key: 'phoneNumber',
            },
        },
        notificationId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'notifications',
                key: 'id',
            },
        },
        description: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        professionalism: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                min: 1,
                max: 5,
            },
        },
        reliability: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                min: 1,
                max: 5,
            },
        },
        availability: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                min: 1,
                max: 5,
            },
        },
        showName:{
            type: DataTypes.INTEGER,
            defaultValue: 0,
        },
        reviewed: {  // Moved `status` outside `availability`
            type: DataTypes.INTEGER,
            defaultValue: 0,
        },
    }, {
        tableName: 'reviews',  // Explicitly define the table name
        timestamps: true, // Add this line to enable createdAt and updatedAt
    });
    Review.associate = (models) => {
        Review.belongsTo(models.notification, {
            foreignKey: 'notificationId',
            as: 'notification',
        });
    };

    return Review;
};
