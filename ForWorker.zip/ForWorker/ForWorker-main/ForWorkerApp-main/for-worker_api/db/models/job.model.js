// src/models/job.model.js
module.exports = (sequelize, DataTypes) => {
    const Job = sequelize.define("job", {
        name: {
            type: DataTypes.STRING(255),
            primaryKey: true,
            allowNull: false
        }
    });

    Job.associate = function(models) {
        // Association with Worker through WorkerJob
        Job.belongsToMany(models.worker, {
            through: models.workerjob,  // Use the WorkerJob model for the association
            foreignKey: 'jobName',
            otherKey: 'workerPhoneNumber'

        });

        // Association with Category through JobCategory
        Job.belongsToMany(models.category, {
            through: models.jobCategory,  // Use the JobCategory model for the association
            foreignKey: 'jobName',
            otherKey: 'categoryName',

        });

        // Ensure Job can have multiple workers and categories linked via WorkerJob and JobCategory
        Job.hasMany(models.workerjob, { foreignKey: 'jobName' });
        // Job.hasMany(models.workerjob, { foreignKey: 'jobName', as: 'WorkerJobs' });

        Job.hasMany(models.jobCategory, { foreignKey: 'jobName' });
    };

    return Job;
};
