// workerLocation.model.js
module.exports = (sequelize, DataTypes) => {
    const WorkerLocation = sequelize.define("workerLocation", {
        workerPhoneNumber: {
            type: DataTypes.STRING(50),
            primaryKey: true,
            references: {
                model: 'workers',  // Reference the workers table
                key: 'phoneNumber'
            }
        },
        locationId: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            references: {
                model: 'locations', // Reference the locations table
                key: 'id'
            }
        }
    });

    WorkerLocation.associate = function(models) {
        WorkerLocation.belongsTo(models.worker, { foreignKey: 'workerPhoneNumber' });
        WorkerLocation.belongsTo(models.location, { foreignKey: 'locationId' });
    };

    return WorkerLocation;
};
