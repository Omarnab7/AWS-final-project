
const { DataTypes } = require('sequelize');
module.exports = (sequelize, DataTypes)=> {
    const Customer = sequelize.define('Customer', {
        customerPhoneNumber: {
            type: DataTypes.STRING,
            primaryKey: true,
            allowNull: false,
        },
        CustomerFirstName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        CustomerLastName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    }, {
        tableName: 'customer',
        timestamps: false, // if you don't want createdAt and updatedAt fields
    });

    Customer.associate = function(models) {
        Customer.belongsToMany(models.worker, {
            through: models.OrderService,
            foreignKey: 'customerPhoneNumber', // Make sure this matches
        });
    };

    return Customer;
};

