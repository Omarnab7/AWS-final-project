import smtplib
from email.message import EmailMessage

def send_simple_email(s, b, recipient):
    # recipient = "neev.penkar@gmail.com"
    sender = "work.aws@threemusketeers.shop"  # Your Gmail
    password = "Orel1997#omar2001"  # Use App Password (not main password)
    
    msg = EmailMessage()
    msg.set_content(b)
    msg["Subject"] = s    
    msg["From"] = sender
    msg["To"] = recipient
    
    with smtplib.SMTP_SSL("smtp.hostinger.com", 465) as smtp:
        smtp.login(sender, password)
        smtp.send_message(msg)
    return "Email sent, no AWS nonsense!"

def lambda_handler(event, context):
    print(event)
    subject = event.get('subject', 'No Subject')
    message = event.get('message', 'No Message')
    rec     = event.get('recipient', None)
    
    if message is None:
        return ValueError("No message provided")
    
    return send_simple_email(subject, message, rec)