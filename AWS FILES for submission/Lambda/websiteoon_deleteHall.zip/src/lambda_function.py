import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('halls')

def lambda_handler(event, context):
    try:
        # Extract serial_number from path parameters
        serial_number = event['pathParameters']['serial_number']
        
        # Convert to integer (assuming serial_number is numeric)
        serial_number = int(serial_number)
        
        # First check if item exists
        response = table.get_item(
            Key={
                'serial_number': serial_number
            }
        )
        
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Hall not found'})
            }
        
        # Delete the item
        table.delete_item(
            Key={
                'serial_number': serial_number
            }
        )
        
        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'Hall deleted successfully'})
        }
        
    except ValueError:
        return {
            'statusCode': 400,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'serial_number must be a number'})
        }
    except ClientError as e:
        print(f"DynamoDB error: {e.response['Error']['Message']}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'Database operation failed'})
        }
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'Internal server error'})
        }