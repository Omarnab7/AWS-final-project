import json
import boto3
import uuid
import random

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('halls')  # ודא שהטבלה בשם הזה קיימת ב-DynamoDB

def lambda_handler(event, context):
    try:
        data = event['body']
        data = json.loads(data)
        item = {
            'serial_number': random.randint(0,100000000),  # מזהה ייחודי במקום int אוטומטי
            'name': data['name'],
            'address': data['address'],
            'capacity': int(data['capacity']),
            'purpose': data['purpose'],
            'city': data['city'],
            'pricePerGuest': int(data['pricePerGuest']),
            'image1': data.get('image1', '')  # שדות תמונה כ-base64 string
            # 'image2': data.get('image2', ''),
            # 'image3': data.get('image3', ''),
            # 'image4': data.get('image4', ''),
            # 'image5': data.get('image5', '')  # השדה היחיד שהיה Checked
        }

        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'headers': { 'Access-Control-Allow-Origin': '*' },
            'body': json.dumps({'message': '✅ Hall added successfully'})
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': { 'Access-Control-Allow-Origin': '*' },
            'body': json.dumps({'error': str(e)})
        }
