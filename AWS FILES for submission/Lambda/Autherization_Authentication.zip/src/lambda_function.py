import boto3

def lambda_handler(event, context):
    user_id = event.get('pathParameters', {}).get('user_id') # name or id
    print("User ID:", user_id)
    print("event: ", event['pathParameters'])

    client = boto3.client('cognito-idp')
    try:
        response = client.admin_delete_user(
            UserPoolId='us-east-2_OCgiO6S6U',  # Your Cognito User Pool ID
            Username=user_id  # The username to delete
        )
        return {'status': 'success'}
    
    except Exception as e:
        return {'error': str(e)}