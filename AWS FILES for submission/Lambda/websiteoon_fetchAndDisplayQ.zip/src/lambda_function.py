import json
import boto3
from decimal import Decimal  # DynamoDB uses Decimal for numbers

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('pricing')

def lambda_handler(event, context):
    try:
        response = table.scan()
        pricings = response.get('Items', [])
        print(pricings)

        # Convert all DynamoDB Decimals to int/float
        def convert_decimals(obj):
            if isinstance(obj, Decimal):
                return int(obj)  # or float(obj) if you need decimals
            elif isinstance(obj, list):
                return [convert_decimals(item) for item in obj]
            elif isinstance(obj, dict):
                return {key: convert_decimals(value) for key, value in obj.items()}
            return obj

        pricings_converted = convert_decimals(pricings)
        print(pricings_converted)

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps(pricings_converted)
            # 'body': json.dumps({
            #     'message': '✅ Successfully retrieved all pricings',
            #     'data': pricings_converted  # Now contains ints instead of Decimals
            # })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': '❌ Failed to fetch halls',
                'details': str(e)
            })
        }