import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('halls')

def lambda_handler(event, context):
    try:
        # To this:
        body = event.get('body', '{}')  # Handle missing body
        if type(body) == str:
            data = json.loads(body)    # Handle string body
        else:
            data = body
            pass
        # data = json.loads(body)         # Parse the JSON string
        
        serial_number = int(data['serial_number'])

        # Step 1: Fetch the existing item
        response = table.get_item(Key={'serial_number': serial_number})
        item = response.get('Item')
        
        if not item:
            return {
                'statusCode': 404,
                'headers': { 'Access-Control-Allow-Origin': '*' },
                'body': json.dumps({'error': 'Hall not found'})
            }

        # Step 2: Update only the provided fields
        for key in ['name', 'address', 'capacity', 'purpose', 'city', 'pricePerGuest']:
            if key in data:
                item[key] = int(data[key]) if key in ['capacity', 'pricePerGuest'] else data[key]

        # Step 3: Write the updated item back
        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'headers': { 'Access-Control-Allow-Origin': '*' },
            'body': json.dumps({'message': '✅ Hall updated successfully'})
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': { 'Access-Control-Allow-Origin': '*' },
            'body': json.dumps({'error': str(e)})
        }
