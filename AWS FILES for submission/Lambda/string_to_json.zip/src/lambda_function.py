import json

def lambda_handler(event, context):
    print("Type of event: " , type(event))
    if type(event) == str:
        event = json.loads(event)
    elif type(event) == dict:
        event = event    # TODO implement
    return event
