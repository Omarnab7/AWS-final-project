import boto3
import json

def lambda_handler(event, context):
    user_pool_id = 'us-east-2_OCgiO6S6U'  # Replace with your actual user pool ID
    region = 'us-east-2'  # Replace with your actual region

    client = boto3.client('cognito-idp', region_name=region)

    users = []
    pagination_token = None

    while True:
        params = {
            'UserPoolId': user_pool_id,
            'Limit': 60  # Max per call
        }
        if pagination_token:
            params['PaginationToken'] = pagination_token

        response = client.list_users(**params)
        users.extend(response['Users'])

        pagination_token = response.get('PaginationToken')
        if not pagination_token:
            break

    print(users)
    cleaned_users = []

    for user in users:
        username = user['Username']
        email = user['Attributes'][0]['Value']
        
        groups_resp = client.admin_list_groups_for_user(
            Username=username,
            UserPoolId=user_pool_id
        )
        group_names = [g['GroupName'] for g in groups_resp.get('Groups', [])]
        if 'websiteoon_admins' in group_names:
            cleaned_users.append({"email":email})

    print(cleaned_users)

    # return {'statusCode': 200, 'body': json.dumps(cleaned_users) }
    return cleaned_users #{'statusCode': 200, 'body': cleaned_users }
