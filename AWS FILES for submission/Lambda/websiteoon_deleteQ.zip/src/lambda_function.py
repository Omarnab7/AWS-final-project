import json
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('pricing')

def lambda_handler(event, context):
    try:
        
        # Extract quotationNumber from path parameters
        quotationNumber = event['pathParameters']['quotation_id']
        
        print(quotationNumber)
        # Convert to integer (assuming quotationNumber is numeric)
        quotationNumber = Decimal(quotationNumber)
        
        # First check if item exists
        response = table.get_item(
            Key={
                'quotationNumber': quotationNumber
            }
        )
        
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Menu not found'})
            }
        
        # Delete the item
        table.delete_item(
            Key={
                'quotationNumber': quotationNumber
            }
        )
        
        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'Menu deleted successfully'})
        }
        
    except ValueError:
        return {
            'statusCode': 400,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'quotationNumber must be a number'})
        }
    except ClientError as e:
        print(f"DynamoDB error: {e.response['Error']['Message']}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'Database operation failed'})
        }
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'Internal server error'})
        }