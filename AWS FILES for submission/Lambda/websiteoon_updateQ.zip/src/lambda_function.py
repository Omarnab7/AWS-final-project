import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('pricing')  # Make sure this table exists with quotationNumber as the key

def lambda_handler(event, context):
    try:
        # Handle missing or string body
        body = event.get('body', '{}')
        data = json.loads(body) if isinstance(body, str) else body

        print("item", data)


        quotationNumber = Decimal(data['quotationNumber'])

        # Step 1: Fetch the existing menu item
        response = table.get_item(Key={'quotationNumber': quotationNumber})
        item = response.get('Item')
        
        if not item:
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'PUT, OPTIONS'},
                'body': json.dumps({'error': 'Menu not found'})
            }

        # Step 2: Update only the fields provided in the request
        # item = {
        #     "quotationNumber" = quotationNumber,
        #     "guestName" = data['guestName'],
        #     "guestId" = data['guestId'],
        #     "date" = data['date'],
        #     "nameOfEvent" = data['nameOfEvent'],
        #     "menuNumber" = Decimal(data['menuNumber']),
        #     "hallNumber" = Decimal(data['hallNumber']),
        #     "numberOfGuests" = Decimal(data['numberOfGuests']),
        #     "totalPrice" = Decimal(data['totalPrice']),
        # }

        item = {
            "quotationNumber" : quotationNumber,
            "guestName" : data['guestName'],
            "guestId" : data['guestId'],
            "date" : data['date'],
            "nameOfEvent" : data['nameOfEvent'],
            "menuNumber" : Decimal(data['menuNumber']),
            "hallNumber" : Decimal(data['hallNumber']),
            "numberOfGuests" : Decimal(data['numberOfGuests']),
            "totalPrice" : Decimal(data['totalPrice']),
        }

        # Step 3: Write updated item back to the table
        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'PUT, OPTIONS'},
            'body': json.dumps({'message': '✅ Menu updated successfully'})
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'PUT, OPTIONS'},
            'body': json.dumps({'error': str(e)})
        }
