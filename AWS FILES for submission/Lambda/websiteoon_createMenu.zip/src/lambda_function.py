import json
import boto3
from decimal import Decimal
import random, datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('menus2')  # Make sure this table exists in DynamoDB

def lambda_handler(event, context):
    try:
        # Parse incoming data
        data = json.loads(event['body'])
        print(data)
        
        # Create menu item
        item = {
            'SerialNumber': random.randint(0,100000000),  # Unique identifier
            'Name': data['Name'],
            'FirstCourse': data['FirstCourse'],
            'SecondCourse': data['SecondCourse'],
            'Dessert': data['Dessert'],
            'PricePerGuest': Decimal(data['PricePerGuest']),  # Proper decimal handling
            # 'created_at': datetime.now().isoformat()  # Timestamp
        }

        # Insert into DynamoDB
        table.put_item(Item=item)

        # Send Email to admins
        message = "A new menu has been created"
        subject = "New Menu Created"

        # Invoke step function
        stepfunctions = boto3.client('stepfunctions')
        stepfunctions.start_execution(
            stateMachineArn='arn:aws:states:us-east-2:979182475859:stateMachine:HelloWorldStateMachine',
            input=json.dumps({
                'message': message,
                'subject': subject
            })
        )

        return {
            'statusCode': 200,
            'headers': { 
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': '✅ Menu added successfully',
                'menu_id': item['SerialNumber']  # Return the generated ID
            })
        }

    except json.JSONDecodeError:
        return {
            'statusCode': 401,
            'body': json.dumps({'error': 'Invalid JSON format'})
        }
    except KeyError as e:
        print(e)
        return {
            'statusCode': 402,
            'body': json.dumps({'error': f'Missing required field: {str(e)}'})
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error'})
        }