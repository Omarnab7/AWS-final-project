import json
import boto3
from decimal import Decimal
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('menus2')  # Make sure this table exists with serial_number as the key

def lambda_handler(event, context):
    try:
        # Handle missing or string body
        body = event.get('body', '{}')
        data = json.loads(body) if isinstance(body, str) else body

        serial_number = Decimal(data['SerialNumber'])

        # Step 1: Fetch the existing menu item
        response = table.get_item(Key={'SerialNumber': serial_number})
        item = response.get('Item')
        
        if not item:
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'PUT, OPTIONS'},
                'body': json.dumps({'error': 'Menu not found'})
            }

        # Step 2: Update only the fields provided in the request
        for key in ['Name', 'FirstCourse', 'SecondCourse', 'Dessert', 'PricePerGuest']:
            if key in data:
                item[key] = Decimal(data[key]) if key == 'PricePerGuest' else data[key]

        # Step 3: Write updated item back to the table
        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'PUT, OPTIONS'},
            'body': json.dumps({'message': '✅ Menu updated successfully'})
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'PUT, OPTIONS'},
            'body': json.dumps({'error': str(e)})
        }
