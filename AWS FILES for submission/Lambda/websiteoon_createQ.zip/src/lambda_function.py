import json
import boto3
from decimal import Decimal
import random, datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('pricing')  # Make sure this table exists in DynamoDB

def lambda_handler(event, context):
    try:
        # Parse incoming data
        data = json.loads(event['body'])
        print(data)
        
        # Create menu item
        item = {
            'quotationNumber': random.randint(0,100000000),  # Unique identifier
            'guestName': data['guestName'],
            'totalPrice': Decimal(data['totalPrice']),
            'hallNumber': Decimal(data['hallNumber']),
            'nameOfEvent': data['nameOfEvent'],
            'numberOfGuests': Decimal(data['numberOfGuests']),
            'menuNumber': Decimal(data['menuNumber']),  # Proper decimal handling
            'guestId': data['guestId'],
            'date': data['date'],  # Assuming 'menu' is a list of dictionaries
        }

        # Insert into DynamoDB
        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'headers': { 
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': '✅ Menu added successfully',
                # 'menu_id': item['SerialNumber']  # Return the generated ID
            })
        }

    except json.JSONDecodeError:
        return {
            'statusCode': 401,
            'body': json.dumps({'error': 'Invalid JSON format'})
        }
    except KeyError as e:
        print(e)
        return {
            'statusCode': 402,
            'body': json.dumps({'error': f'Missing required field: {str(e)}'})
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error'})
        }