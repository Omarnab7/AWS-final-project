import json
import boto3

def lambda_handler(event, context):
    # Extract parameters from the event
    source_email = event.get('src')
    subject = event.get('subject')
    message = event.get('message')

    # Fetch admins = Admins
    user_pool_id = 'us-east-2_OCgiO6S6U'  # Replace with your actual user pool ID
    region = 'us-east-2'  # Replace with your actual region

    client = boto3.client('cognito-idp', region_name=region)

    users = []
    pagination_token = None

    while True:
        params = {
            'UserPoolId': user_pool_id,
            'Limit': 60  # Max per call
        }
        if pagination_token:
            params['PaginationToken'] = pagination_token

        response = client.list_users(**params)
        users.extend(response['Users'])

        pagination_token = response.get('PaginationToken')
        if not pagination_token:
            break

    print(users)
    cleaned_users = []

    for user in users:
        username = user['Username']
        email = user['Attributes'][0]['Value']
        
        groups_resp = client.admin_list_groups_for_user(
            Username=username,
            UserPoolId=user_pool_id
        )
        group_names = [g['GroupName'] for g in groups_resp.get('Groups', [])]
        if 'websiteoon_admins' in group_names:
            cleaned_users.append(email)

    print(cleaned_users)

    # For admin in admin
    for admin in cleaned_users:
        # Send email to admin
        ses_client = boto3.client('ses', region_name=region)
        response = ses_client.send_email(
            Source=source_email,
            Destination={'ToAddresses': [admin]},
            Message={
                'Subject': {'Data': subject},
                'Body': {'Text': {'Data': message}}
            }
        )

    #   # Send Mail

    # # TODO implement
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }


    # # Payload to send to the target Lambda
    # payload = {
    #     "src": "sender@example.com",
    #     "dest": "recipient@example.com",
    #     "subject": "Hello from Lambda!",
    #     "message": "This was sent via Lambda invocation"
    # }